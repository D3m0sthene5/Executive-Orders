# Pinned family work package

Research preparation. No family approval, legal status or human certification.
Read each common source independently, then record every member-specific check.
Full lossless evidence and metadata: PACKET.json. Missing/overflow records are retained below.

## Source catalogue

- **S00a48b4dd9bdccb3744e21bd**: https://www.govinfo.gov/bulkdata/ECFR/title-5/ECFR-title5.xml
  {"page_or_item":"5 CFR 307.102 (section_text; GovInfo eCFR XML title 5, amended through 2026-10-15; NODE 5:1.0.1.2.38.0.14.2)","sha256":"d0b85cb99762ee3117c673c30a95c6847c5f15e9d4a9b1401616030827721c91","url":"https://www.govinfo.gov/bulkdata/ECFR/title-5/ECFR-title5.xml"}
- **S1158d412557edddef4fbe3bf**: https://uscode.house.gov/download/releasepoints/us/pl/119/121/xml_uscAll@119-121.zip
  {"page_or_item":"10 U.S.C. subtitle A, pt. II, ch. 57 note; note 'Ex. Ord. No. 11448. Meritorious Service Medal' [USLM note id ida8989a54-3a6f-11f1-a58a-d8db54b14ab5]; usc10.xml (sha256 f6b1a4f0897cd19431abb8af52cf3aafb02cf6e1870f0f6b5d1992c37fe128b6) in xml_uscAll@119-121.zip","sha256":"c6122974e951003437ece5a998aa7c0b2cdc0f5703dfc78d6135e1fc9e729142","url":"https://uscode.house.gov/download/releasepoints/us/pl/119/121/xml_uscAll@119-121.zip"}
- **S134d196bd44a7e2cf36d00f9**: https://www.presidency.ucsb.edu/documents/executive-order-12793-continuing-the-presidential-service-certificate-and-the-presidential
  {"acceptable_as_original":false,"filing_date":null,"grade":"mirror_transcription","instrument_id":"EO:12793","page_or_item":"American Presidency Project web page (transcription; not an official edition); APP node 268891; common-crawl capture 2024-10-04T21:20:28Z","requires_page_check":false,"sha256":"3b461f28e9ffaf3381b2b91bf89428135a0f639f8b35ea941066cc76a05f1413","signing_date":"1992-03-20","text_path":"jobs/clause-drafts/output/texts/cd-job-app-executive-orders-12793-3b461f28e9.txt","text_sha256":"6ef768f38f8da6ddbee5ccb215b53c6880c2252aa46b0f6cde76ec2d99f476d4","url":"https://www.presidency.ucsb.edu/documents/executive-order-12793-continuing-the-presidential-service-certificate-and-the-presidential"}
- **S1e9f3455cede37effbfa53f3**: https://www.govinfo.gov/bulkdata/ECFR/title-48/ECFR-title48.xml
  {"page_or_item":"48 CFR 22.1301 (section_text; GovInfo eCFR XML title 48, amended through 2026-10-09; NODE 48:1.0.1.4.21.13.1.2)","sha256":"acf22f7e7bcfa3dc6201a8383cc5d917175ba82a857bd770112df21d299181c6","url":"https://www.govinfo.gov/bulkdata/ECFR/title-48/ECFR-title48.xml"}
- **S213e25bdd3a31c76a3d7df90**: https://www.govinfo.gov/content/pkg/FR-2003-03-14/pdf/03-6445.pdf
  {"filing_date":null,"location_confidence":"high","location_verified":false,"page_or_item":"68 FR 12567, PDF pages 1-2","requires_page_check":false,"sha256":"6670f509054733a97662c450aa98b59747e76b5653f4da0849f7260aa953419e","signing_date":"2003-03-12","text_path":"jobs/fr-originals/data/full_run/texts/EO_13289.txt","text_sha256":"ecb02a85811a087a17f9103ded2a6f86486d62d83e226f50b05697acac0132ff","url":"https://www.govinfo.gov/content/pkg/FR-2003-03-14/pdf/03-6445.pdf"}
- **S21bf5d51c2cf14496f91f27c**: https://uscode.house.gov/download/releasepoints/us/pl/119/121/xml_uscAll@119-121.zip
  {"page_or_item":"10 U.S.C. subtitle A, pt. II, ch. 57 note; note 'Ex. Ord. No. 12985. Establishing Armed Forces Service Medal' [USLM note id ida8989a5c-3a6f-11f1-a58a-d8db54b14ab5]; usc10.xml (sha256 f6b1a4f0897cd19431abb8af52cf3aafb02cf6e1870f0f6b5d1992c37fe128b6) in xml_uscAll@119-121.zip","sha256":"c6122974e951003437ece5a998aa7c0b2cdc0f5703dfc78d6135e1fc9e729142","url":"https://uscode.house.gov/download/releasepoints/us/pl/119/121/xml_uscAll@119-121.zip"}
- **S3373d4e962942d893f47ef46**: https://uscode.house.gov/download/releasepoints/us/pl/119/121/xml_uscAll@119-121.zip
  {"page_or_item":"10 U.S.C. subtitle A, pt. II, ch. 57 note; note 'Ex. Ord. No. 12830. Military Outstanding Volunteer Service Medal' [USLM note id ida8989a5b-3a6f-11f1-a58a-d8db54b14ab5]; usc10.xml (sha256 f6b1a4f0897cd19431abb8af52cf3aafb02cf6e1870f0f6b5d1992c37fe128b6) in xml_uscAll@119-121.zip","sha256":"c6122974e951003437ece5a998aa7c0b2cdc0f5703dfc78d6135e1fc9e729142","url":"https://uscode.house.gov/download/releasepoints/us/pl/119/121/xml_uscAll@119-121.zip"}
- **S358ae0f0add704ca9237d781**: https://www.govinfo.gov/content/pkg/FR-2024-12-27/pdf/2024-31355.pdf
  {"filing_date":null,"location_confidence":"high","page_or_item":"89 FR 105377, PDF pages 1-3","requires_page_check":false,"sha256":"0cc709cf35c2ed46523e8c88e6d0d26596377ea945d7c3ed458c7dd3c48db88f","signing_date":"2024-12-20","text_path":"jobs/fr-originals/output/texts/EO_14131.txt","text_sha256":"40d6973a87db31e3fd2361307980b3248abd3b76dfcf1a74a34b57732042648c","url":"https://www.govinfo.gov/content/pkg/FR-2024-12-27/pdf/2024-31355.pdf"}
- **S36c1f245954f1176438ebcb0**: https://www.govinfo.gov/content/pkg/FR-1992-03-25/pdf/FR-1992-03-25.pdf
  {"filing_date":null,"location_confidence":"high","location_verified":false,"page_or_item":"57 FR 10281, PDF pages 11-16","requires_page_check":false,"sha256":"177bb2a72d99588b007092bda114812034f8b8a95afc7d79ccb7992d0c1876f1","signing_date":"1992-03-20","text_path":"jobs/fr-originals/data/full_run/texts/EO_12793.txt","text_sha256":"7f0a7b05ae4d296e75eb23cc4c90e93ff9735a80adae5215dc5c54099bd32956","url":"https://www.govinfo.gov/content/pkg/FR-1992-03-25/pdf/FR-1992-03-25.pdf"}
- **S3d775115a695f2af4fd1dcb8**: https://www.govinfo.gov/content/pkg/FR-1981-07-08/pdf/FR-1981-07-08.pdf
  {"filing_date":null,"location_confidence":"high","location_verified":false,"page_or_item":"46 FR 35251, PDF pages 9-9","requires_page_check":false,"sha256":"ba9413ef05ba76ffdff3ced429da8b556200450df8971c629a9e85f5e98d2326","signing_date":"1981-07-02","text_path":"jobs/fr-originals/data/full_run/texts/EO_12312.txt","text_sha256":"85559fb3efa04a012e456f0f1e7f401756b7f1ae3d3f3a795b70d7e3933b939f","url":"https://www.govinfo.gov/content/pkg/FR-1981-07-08/pdf/FR-1981-07-08.pdf"}
- **S602f6a5e5287bd9c420ba094**: https://www.govinfo.gov/content/pkg/FR-2005-03-14/pdf/05-5097.pdf
  {"acceptable_as_original":false,"filing_date":null,"grade":"held_text_lead","instrument_id":"EO:13373","page_or_item":"70 FR 12579-12580 (PDF pp. 1-2)","requires_page_check":false,"sha256":"4a783e7a5b00b9fd4ee8db2b8c13b5627b0df63f71ff06a8a52d610085491c4f","signing_date":"2005-03-10","text_path":"jobs/clause-drafts/output/texts/cd-stage21-13373-4a783e7a5b.txt","text_sha256":"aa80ac087135016c837e0b9ef11791f91f60c1e316533272cdb74044a0a45c97","url":"https://www.govinfo.gov/content/pkg/FR-2005-03-14/pdf/05-5097.pdf"}
- **S639260cb4c22eda960847445**: https://www.presidency.ucsb.edu/documents/executive-order-13286-amendment-executive-orders-and-other-actions-connection-with-the
  {"acceptable_as_original":false,"filing_date":null,"grade":"mirror_transcription","instrument_id":"EO:13286","page_or_item":"American Presidency Project web page (transcription; not an official edition)","requires_page_check":false,"sha256":"1cc5a2464dfefbfe34c2fb3dd1551ffbf485c56517e12c18fee9cca979bde697","signing_date":"2003-02-28","text_path":"jobs/clause-drafts/output/texts/cd-opus_zip-13286-1cc5a2464d.txt","text_sha256":"b2730b05d3a5bc0d94149b6f1fb9659432a24c1f27320d2cb3d52c4862955475","url":"https://www.presidency.ucsb.edu/documents/executive-order-13286-amendment-executive-orders-and-other-actions-connection-with-the"}
- **S67326156efbb0f72450f03ba**: https://www.presidency.ucsb.edu/documents/executive-order-14131-amendments-executive-orders-relating-certain-certificates-and-badges
  {"acceptable_as_original":false,"archival_id":"app:node/375423","filing_date":null,"grade":"mirror_transcription","instrument_id":"EO:14131","location_confidence":"medium","location_verified":false,"page_or_item":"Executive Order 14131—Amendments to Executive Orders Relating to Certain Certificates and Badges; December 20, 2024; APP node 375423; common-crawl capture 2025-11-09T01:14:36Z","requires_page_check":true,"sha256":"f886dc0c6e658cd1e85a59d962dc45099fd8e6072bc53f2bfb821ba76162beb1","signing_date":"2024-12-20","text_path":"jobs/app-executive-orders/output/texts/executive-order-14131-amendments-executive-orders-relating-certain-certificates-and-badges.txt","text_sha256":"3f91196fbfb8ec779ccb78305b021a8ebff6c78c4f9b3cb94880266cdd32170f","url":"https://www.presidency.ucsb.edu/documents/executive-order-14131-amendments-executive-orders-relating-certain-certificates-and-badges"}
- **S687694cb310a0c16d272f3ec**: https://www.govinfo.gov/bulkdata/ECFR/title-41/ECFR-title41.xml
  {"page_or_item":"41 CFR 60-300.2 (section_text; GovInfo eCFR XML title 41, amended through 2026-09-22; NODE 41:1.2.3.1.9.1.11.2)","sha256":"f4463cdd577d7d092b31c47a32b67fbb47d628beffbbb689c52d26fbd1a012b3","url":"https://www.govinfo.gov/bulkdata/ECFR/title-41/ECFR-title41.xml"}
- **S6f2c42debd60c69743e6ef81**: https://www.ecfr.gov/api/search/v1/results?query=%22Executive+Order%22&date=2026-10-14&per_page=1000&page=3
  {"page_or_item":"41 CFR part 60-300, Appendix B to Part 60-300 (eCFR search API result, query \"Executive Order\", date=2026-10-14, page 3)","sha256":"6edecd5d7d179bd77a1c39561c12105cf4842032c11a19706bb4e0a40f39dd58","url":"https://www.ecfr.gov/api/search/v1/results?query=%22Executive+Order%22&date=2026-10-14&per_page=1000&page=3"}
- **S757db9e803bf5ea90af93e43**: https://www.govinfo.gov/content/pkg/FR-2000-05-05/pdf/00-11532.pdf
  {"filing_date":null,"location_confidence":"high","location_verified":false,"page_or_item":"65 FR 26479, PDF pages 1-1","requires_page_check":false,"sha256":"a5170c1411a028a314a45bf54308229e46a796661a70174d2fa389671f068f5d","signing_date":"2000-05-03","text_path":"jobs/fr-originals/data/full_run/texts/EO_13154.txt","text_sha256":"837d8c92bcb98b825e2cad83504ffc18dd64fd15935bd9c0177fd092e36beb45","url":"https://www.govinfo.gov/content/pkg/FR-2000-05-05/pdf/00-11532.pdf"}
- **S786f3ec252835cd535dd2153**: https://www.presidency.ucsb.edu/documents/executive-order-12793-continuing-the-presidential-service-certificate-and-the-presidential
  {"acceptable_as_original":false,"archival_id":"app:node/268891","filing_date":null,"grade":"mirror_transcription","instrument_id":"EO:12793","location_confidence":"medium","location_verified":false,"page_or_item":"Executive Order 12793—Continuing the Presidential Service Certificate and the Presidential Service Badge; March 20, 1992; APP node 268891; common-crawl capture 2024-10-04T21:20:28Z","requires_page_check":true,"sha256":"3b461f28e9ffaf3381b2b91bf89428135a0f639f8b35ea941066cc76a05f1413","signing_date":"1992-03-20","text_path":"jobs/app-executive-orders/output/texts/executive-order-12793-continuing-the-presidential-service-certificate-and-the-presidential.txt","text_sha256":"edbd6b17be579a265eb3f99f7504b8306a1e44236ad67d69fb39493261e62d2d","url":"https://www.presidency.ucsb.edu/documents/executive-order-12793-continuing-the-presidential-service-certificate-and-the-presidential"}
- **S78f233520d7580454cd2a865**: https://uscode.house.gov/download/releasepoints/us/pl/119/121/xml_uscAll@119-121.zip
  {"page_or_item":"10 U.S.C. subtitle A, pt. II, ch. 57 note; note 'Ex. Ord. No. 12793. Presidential Service Certificate and Presidential Service Badge' [USLM note id ida8989a5a-3a6f-11f1-a58a-d8db54b14ab5]; usc10.xml (sha256 f6b1a4f0897cd19431abb8af52cf3aafb02cf6e1870f0f6b5d1992c37fe128b6) in xml_uscAll@119-121.zip","sha256":"c6122974e951003437ece5a998aa7c0b2cdc0f5703dfc78d6135e1fc9e729142","url":"https://uscode.house.gov/download/releasepoints/us/pl/119/121/xml_uscAll@119-121.zip"}
- **S80a00f7f9eb9fff406ce1f50**: https://www.govinfo.gov/content/pkg/FR-2024-12-27/pdf/2024-31355.pdf
  {"filing_date":null,"location_confidence":"high","location_verified":false,"page_or_item":"89 FR 105377, PDF pages 1-3","requires_page_check":false,"sha256":"0cc709cf35c2ed46523e8c88e6d0d26596377ea945d7c3ed458c7dd3c48db88f","signing_date":"2024-12-20","text_path":"jobs/fr-originals/data/full_run/texts/EO_14131.txt","text_sha256":"40d6973a87db31e3fd2361307980b3248abd3b76dfcf1a74a34b57732042648c","url":"https://www.govinfo.gov/content/pkg/FR-2024-12-27/pdf/2024-31355.pdf"}
- **S9b3b45f29833e6fa2a935389**: https://www.govinfo.gov/content/pkg/FR-1992-03-25/pdf/FR-1992-03-25.pdf
  {"filing_date":null,"location_confidence":"high","page_or_item":"57 FR 10281, PDF pages 11-16","requires_page_check":false,"sha256":"177bb2a72d99588b007092bda114812034f8b8a95afc7d79ccb7992d0c1876f1","signing_date":"1992-03-20","text_path":"jobs/fr-originals/output/texts/EO_12793.txt","text_sha256":"7f0a7b05ae4d296e75eb23cc4c90e93ff9735a80adae5215dc5c54099bd32956","url":"https://www.govinfo.gov/content/pkg/FR-1992-03-25/pdf/FR-1992-03-25.pdf"}
- **S9d3becb814615b7a8224402c**: https://www.govinfo.gov/content/pkg/FR-2024-12-27/pdf/2024-31355.pdf
  {"acceptable_as_original":false,"filing_date":null,"grade":"held_text_lead","instrument_id":"EO:14131","page_or_item":"89 FR 105377, PDF pages 1-3","requires_page_check":false,"sha256":"0cc709cf35c2ed46523e8c88e6d0d26596377ea945d7c3ed458c7dd3c48db88f","signing_date":"2024-12-20","text_path":"jobs/clause-drafts/output/texts/cd-job-fr-originals-14131-0cc709cf35.txt","text_sha256":"09e9144a67e4a92dde84e83eb530278cb5adb5c617b68138f2d46ffacb0029b9","url":"https://www.govinfo.gov/content/pkg/FR-2024-12-27/pdf/2024-31355.pdf"}
- **Sa57fe65445c4a745520f4e1c**: https://uscode.house.gov/download/releasepoints/us/pl/119/121/xml_uscAll@119-121.zip
  {"page_or_item":"38 U.S.C. 4212 note; note 'References in Text' [USLM note id idf8cc606d-ac5f-11f1-867f-e0c61e4ce6af]; usc38.xml (sha256 812bcb4dab911d8d4b503a86de786adf53c7e6815b2667fcfe1dad79b63658b6) in xml_uscAll@119-121.zip","sha256":"c6122974e951003437ece5a998aa7c0b2cdc0f5703dfc78d6135e1fc9e729142","url":"https://uscode.house.gov/download/releasepoints/us/pl/119/121/xml_uscAll@119-121.zip"}
- **Sa70460732e6d93e8ba86693a**: https://www.govinfo.gov/bulkdata/ECFR/title-41/ECFR-title41.xml
  {"page_or_item":"41 CFR 61-300.2 (section_text; GovInfo eCFR XML title 41, amended through 2026-09-22; NODE 41:1.2.4.1.2.0.11.2)","sha256":"f4463cdd577d7d092b31c47a32b67fbb47d628beffbbb689c52d26fbd1a012b3","url":"https://www.govinfo.gov/bulkdata/ECFR/title-41/ECFR-title41.xml"}
- **Saf271e12bf1b180038a81230**: https://uscode.house.gov/download/releasepoints/us/pl/119/121/xml_uscAll@119-121.zip
  {"page_or_item":"38 U.S.C. 4212; usc38.xml (sha256 812bcb4dab911d8d4b503a86de786adf53c7e6815b2667fcfe1dad79b63658b6) in xml_uscAll@119-121.zip","sha256":"c6122974e951003437ece5a998aa7c0b2cdc0f5703dfc78d6135e1fc9e729142","url":"https://uscode.house.gov/download/releasepoints/us/pl/119/121/xml_uscAll@119-121.zip"}
- **Sbf0d20d958916f234babd443**: https://www.govinfo.gov/content/pkg/FR-2005-03-14/pdf/05-5097.pdf
  {"filing_date":null,"location_confidence":"high","location_verified":false,"page_or_item":"70 FR 12579, PDF pages 1-2","requires_page_check":false,"sha256":"4a783e7a5b00b9fd4ee8db2b8c13b5627b0df63f71ff06a8a52d610085491c4f","signing_date":"2005-03-10","text_path":"jobs/fr-originals/data/full_run/texts/EO_13373.txt","text_sha256":"b93d23e0bb50c539234a7ebb7febee5bd63e9a584274c71fd2d7a498bc163fe8","url":"https://www.govinfo.gov/content/pkg/FR-2005-03-14/pdf/05-5097.pdf"}
- **Sc63997dc1f2d3b6770717b06**: https://www.govinfo.gov/content/pkg/FR-2005-03-14/pdf/05-5097.pdf
  {"filing_date":null,"location_confidence":"high","page_or_item":"70 FR 12579, PDF pages 1-2","requires_page_check":false,"sha256":"4a783e7a5b00b9fd4ee8db2b8c13b5627b0df63f71ff06a8a52d610085491c4f","signing_date":"2005-03-10","text_path":"jobs/fr-originals/output/texts/EO_13373.txt","text_sha256":"b93d23e0bb50c539234a7ebb7febee5bd63e9a584274c71fd2d7a498bc163fe8","url":"https://www.govinfo.gov/content/pkg/FR-2005-03-14/pdf/05-5097.pdf"}
- **Sd3145c7b44424f882132e4cb**: https://www.presidency.ucsb.edu/documents/executive-order-13286-amendment-executive-orders-and-other-actions-connection-with-the
  {"acceptable_as_original":false,"archival_id":"app:node/217113","filing_date":null,"grade":"mirror_transcription","instrument_id":"EO:13286","location_confidence":"medium","location_verified":false,"page_or_item":"Executive Order 13286—Amendment of Executive Orders, and Other Actions, in Connection With the Transfer of Certain Functions to the Secretary of Homeland Security; February 28, 2003; APP node 217113; common-crawl capture 2025-10-06T18:03:47Z","requires_page_check":true,"sha256":"c1a2aff53be0c95cb97e0871e389a3b185ae165f6dd9a539722ed1c45f135c34","signing_date":"2003-02-28","text_path":"jobs/app-executive-orders/output/texts/executive-order-13286-amendment-executive-orders-and-other-actions-connection-with-the.txt","text_sha256":"d24268c163cd19e82bda1102e745709657d237c65d627f55716beebc42ba94f0","url":"https://www.presidency.ucsb.edu/documents/executive-order-13286-amendment-executive-orders-and-other-actions-connection-with-the"}
- **Sdedf324fd1688262034dc811**: https://www.govinfo.gov/content/pkg/FR-1993-01-13/pdf/FR-1993-01-13.pdf
  {"filing_date":null,"location_confidence":"high","location_verified":false,"page_or_item":"58 FR 4061, PDF pages 13-17","requires_page_check":false,"sha256":"c96e10693967f7cf75325225add4bb42925b2ab9d6ebdfee397dad865fe39348","signing_date":"1993-01-09","text_path":"jobs/fr-originals/data/full_run/texts/EO_12830.txt","text_sha256":"d6b7d63e64087aa7cde884e5e6a83fa124c0e771aaaaf71f920985ce63be944f","url":"https://www.govinfo.gov/content/pkg/FR-1993-01-13/pdf/FR-1993-01-13.pdf"}
- **Sfc03d9f9782df3f4e95d50a0**: https://www.govinfo.gov/content/pkg/FR-1996-01-18/pdf/96-622.pdf
  {"filing_date":null,"location_confidence":"high","location_verified":false,"page_or_item":"61 FR 1209, PDF pages 1-1","requires_page_check":false,"sha256":"eece26bfc0809ebfef4b097a78abfcfe4e59788c977ae20b07ab24ab82428023","signing_date":"1996-01-11","text_path":"jobs/fr-originals/data/full_run/texts/EO_12985.txt","text_sha256":"76f891cde9ad452e56d7c4eaa3b216c1b3ff68bcd54e29825e55be3709c3a6f3","url":"https://www.govinfo.gov/content/pkg/FR-1996-01-18/pdf/96-622.pdf"}
- **Sfe3e595d4ec3c7a60d3b0f10**: https://www.govinfo.gov/bulkdata/ECFR/title-41/ECFR-title41.xml
  {"page_or_item":"41 CFR part 60, Appendix B to Part 60-300 (appendix_text; GovInfo eCFR XML title 41, amended through 2026-09-22; NODE 41:1.2.3.1.9.5.11.7.3)","sha256":"f4463cdd577d7d092b31c47a32b67fbb47d628beffbbb689c52d26fbd1a012b3","url":"https://www.govinfo.gov/bulkdata/ECFR/title-41/ECFR-title41.xml"}

## Shared source texts

### T1f161e57f49a0d32d2cf1557

Text hash 7f0a7b05ae4d296e75eb23cc4c90e93ff9735a80adae5215dc5c54099bd32956; absolute characters 0–17080; files: jobs/fr-originals/data/full_run/texts/EO_12793.txt

```text
Instrument: EO:12793
Source: https://www.govinfo.gov/content/pkg/FR-1992-03-25/pdf/FR-1992-03-25.pdf
SHA-256 of the downloaded file: 177bb2a72d99588b007092bda114812034f8b8a95afc7d79ccb7992d0c1876f1
Location: 57 FR 10281, PDF pages 11-16 (confidence high)
Machine-extracted text layer of the official PDF (OCR for 1936-1994 scans). May contain recognition errors and parts of neighbouring documents on the same pages. Not an authenticated transcription: check the PDF pages.

=== PDF page 11 of 154 ===
10281
Federal Register 
Vol. 57, No. 58
Presidential Documents
Wednesday, March 25, 1992
Title 3— Executive Order 12793 of March 20, 1992
T h e Presid ent Continuing the P resid ential Serv ice C ertificate and the 
Presid ential S erv ice Bad ge
By the authority vested in me as President by the Constitution and the laws  
of the United States of America, and as Commander in Chief of the Armed  
Forces of the United States, it is ordered as follows:
Section 1 . P residential S erv ice Certificate. The Presidential Service Certifi­
cate ( Certificate”) is hereby continued, the design of which accompanies  
and is hereby made a part of this order. The Certificate shall be awarded in  
the name of the President of the United States by the Secretary of the Army,  
the Secretary of the Navy, the Secretary of the Air Force, or, when the Coast  
Guard is not operating as a service in the Navy, the Secretary of Transporta­
tion. It shall be awarded by the appropriate Secretary to members of the  
Army, Navy, Marine Corps, Air Force, and Coast Guard, respectively, who  
have been assigned to the White House Office; to military units and support  
facilities under the administration of the White House Military Office; or to  
other direct support positions within the Executive Office of the President  
(“EOP”). The Certificate shall not be issued to any member who is issued a  
Vice Presidential Certificate, or similar EOP Certificate, for the same period  
of service. Such assignment must be for a period of at least one year,  
subsequent to January 21,1989.
Sec. 2. P residential S erv ice Badge. The Presidential Service Badge (“Badge”)  
is hereby continued, the design of which accompanies and is hereby made a  
part of this order. The Badge shall be awarded to those members of the  
Armed Forces who have been granted the Certificate and shall be awarded  
in the same manner in which the Certificate has been given. The Badge shall  
be worn as a part of the uniform of those individuals under such regulations  
as their respective Secretaries may severally prescribe.
Sec. 3. Only one Certificate may be awarded to an individual.
Sec. 4. The Certificate and the Badge may be granted posthumously.
Sec. 5. This order shall supersede Executive Order No. 1 0 8 7 9  of June 1 , 1960, 
as amended.
Billing code 3195-01-M
Cs
THE WHITE HOUSE,
M arch 20, 1992.

=== PDF page 12 of 154 ===
10282 Fed eral R egister / Vol. 57, No. 58 / Wednesday, March 25,1992 /  Presidential Documents
^ U n t i e J L  S i x t i e s  o f  ^ i n t e r u M
y ^ e t / e n p .'
£ 7 & 4  ¿ 0  / ¿ e jt / y f y  S Ç f f la / e i
^ \ S & n e * c c a  ¿ a i  ¿ u a a m / e < /
tf&fte ^ Ù c e s ifle iv iiftL  S e r v ic e  G e v t if t c c t ie
¿ >
Ç fo r  ÎH o n o e a J ïle  S e r v ic e  U t i/ te  fy & itlé e  0 Ì a iu s e
M t u / e *  ¿ n y ^ a n t / j k  ¿ î e x i t y x ^  Ç M Îa i& n ÿ / U *
President (Name)
¿ f a  x / a y A ^  ¿ 0
DIRECTOR
WHITE HOUSE MILITARY OFFICE
PRESIDENTIAL SERVICE CERTIFICATE  
ACTUAL SIZE - 10 X 13

=== PDF page 13 of 154 ===
10283Federal Register /  Vol. 57, No. 58 /  Wednesday, March 25, !992 /  Presidential Documents
PRESIDENTIAL SERVICE BADGE 
ACTUAL SIZE - 1  Vs
tFR Doc. 92-6943 
Filed 3-20-92; 2:06 pm] 
Billing code 3195-01-C

=== PDF page 14 of 154 ===
■ — i — — —

=== PDF page 15 of 154 ===
10285
Rules and Regulations Federal Register
Vol. 57, No. 58 
Wednesday, March 25, 1992
This section of the FEDERAL REGISTER 
contains regulatory documents having 
general applicability and legal effect, most 
of which are keyed to and codified in 
the Code of Federal Regulations, which is 
published under 50 titles pursuant to 44 
U.S.C. 1510.
The Code of Federal Regulations is sold 
by the Superintendent of Documents.
Prices of new books are listed in the 
first FEDERAL REGISTER issue of each 
week.
DEPARTMENT OF TRANSPORTATION  
Federal Aviation Administration  
14 CFR Part 39
[Docket No. 92-ASW -02; Arndt. 39-8204; 
AD 92-07-08]
Airworthiness Directives; Bell  
Helicopter Textron, Inc. (BHTI), Model  
204B, 205A, 205A-1,205B and 212  
Helicopters
AGENCY: Federal Aviation 
Administration, DOT.
ACTION: Final rule; request for 
comments.
s u m m a r y: This amendment adopts a 
new airworthiness directive (AD) that is 
applicable to Bell Model 204B, 205A, 
205A-1, 205B and 212 helicopters. This 
action requires a review of maintenance 
records, a one-time inspection, and 
replacement, if necessary, of certain 
swashplate support assemblies 
purchased after June 1990. This 
amendment is prompted by concern that 
unapproved and possibly unsafe 
swashplate support assemblies may 
have been installed on certain 
helicopters. The actions specified in this 
AD are intended to prevent possible loss 
of main rotor control and possible loss 
of the helicopter.
DATED: Effective on March 25,1992.
Comments for inclusion in the Rules 
Docket must be received by May 11, 
1992.
ADDRESSES: The applicable service 
information may be obtained from Bell 
Helicopter Textron, Inc., P.O. Box 482, 
Fort Worth, Texas 76101. This 
information may be examined at the 
FAA, Office of the Assistant Chief 
Counsel, 4400 Blue Mound Road, room 
158, Building 3B, Fort Worth, Texas.
Submit comments in triplicate to the 
Federal Aviation Administration, Office 
of the Assistant Chief Counsel,
Attention: Rules Docket No, 92-A SW - 
02,4400 Blue Mound Road, Fort Worth, 
Texas 76193-0007.
FOR FURTHER INFORMATION CONTACT: 
Mr. Tom K. Henry, Federal Aviation 
Administration, Rotorcraft Certification 
Office, ASW-170, Fort Worth, Texas 
76193-6170, telephone (817) 624-5168.
SUPPLEMENTARY INFORMATION: The FAA 
has determined that approximately 156 
swashplate support assemblies, part 
number (P/N) 204-011^104-125, were 
machined by a vendor with oversize 
holes in the two outboard lugs. The 
vendor attempted to repair this mistake 
by installing oversize bushings in the 
lugs. This repair method was rejected by 
the type design owner who declared the 
swashplate support assemblies 
unacceptable for use. The vendor was 
also informed by the FAA in June 1990, 
that the 156 swashplate support 
assemblies were unacceptable and not 
approved for use on the Bell Model 
204B, 205A, 205A-1, 205B and 212 
helicopters. The FAA received a report 
on December 10,1991, that two of the 
unapproved swashplate support 
assemblies were discovered in 
Colombia, South America. On January 7, 
1992, two more unapproved swashplate 
support assemblies were reportedly 
found in Saudi Arabia. These parts were 
allegedly shipped from two supply 
houses in the United States.
Since these swashplate support 
assemblies may be installed on other 
helicopters of this same type design, this 
AD is being issued to identify and, if 
necessary, to require replacement of 
unairworthy assemblies to prevent 
possible failure of the swashplate 
support assembly and the subsequent 
loss of main rotor control. This AD 
requires a review of maintenance 
records to determine if a swashplate 
support assembly, P/N 204-011-404-125, 
installed on a helicopter was purchased 
after June 1990. This AD also requires a 
one-time inspection of the swashplate 
support assembly for oversize bushings 
on either outboard lug of any assembly 
purchased after June 1990. Any 
unapproved assembly must be removed 
and replaced with an airworthy 
assembly prior to further flight.
Since a situation exists that requires 
the immediate adoption of this 
regulation, it is found that notice and 
public procedure hereon are 
impracticable, and good cause exists for
making this amendment effective in less 
than 30 days.
Comments Invited
Although this action is in the form of a 
final rule that involves requirements 
affecting flight safety and, thus, was not 
preceded by notice and an opportunity 
for public comment, comments are 
invited on this rule. Interested persons 
are invited to comment on this rule by 
submitting such written data, views, or 
arguments as they may desire. 
Communications should identify the 
Rules Docket number and be submitted 
in triplicate to the address specified 
under the caption “ADDRESSES” . All 
communications received on or before 
the closing date for comments will be 
considered, and the rule may be 
changed in light of the comments 
received. Factual information that 
supports the commenter’s ideas and 
suggestions is extremely helpful in 
evaluating the effectiveness of the AD 
action and determining whether 
additional rulemaking action would be 
needed.
Comments are specifically invited on 
the overall regulatory, economic, 
environmental, and energy aspects of 
the rule that might suggest a need to 
modify the rule. All comments submitted 
will be available, both before and after 
the closing date for comments, in the 
Rules Docket for examination by 
interested persons. A report 
summarizing each FAA-public contact 
concerned with the substance of the AD 
will be filed in the Rules Docket.
Commenters wishing the FAA to 
acknowledge receipt of their comments 
submitted in response to this 
amendment must submit a self- 
addressed, stamped postcard on which 
the following statement is made: 
“Comments to Docket Number 92- 
ASW -02.” The postcard will be date 
stamped and returned to the commenter.
The regulations adopted herein will 
not have substantial direct effects on the 
States, on the relationship between the 
national government and the States, or 
the distribution of power and 
responsibilities among the various levels 
of government. Therefore, in accordance 
with Executive Order 12612, it is 
determined that this final rule does not 
have sufficient federalism implications 
to warrant the preparation of a 
Federalism Assessment.

=== PDF page 16 of 154 ===
10286 Federal Register / Vol. 57, No. 58 / Wednesday, March 25, 1992 /  Rules and Regulations
The FAA has determined that this 
regulation is an emergency regulation 
and that it is not considered to be major 
under Executive Order 12291. It is 
impracticable for the agency to follow 
the procedures of Executive Order 12291 
with respect to this rule since the rule 
must be issued immediately to correct 
an unsafe condition in aircraft. It has 
been further determined that this action 
involves an emergency regulation under 
DOT Regulatory Policies and Procedures 
(44 F R 11034, February 26,1979). If it is 
determined that this emergency 
regulation otherwise would be 
significant under DOT Regulatory 
Policies and Procedures, a final 
regulatory evaluation will be prepared 
and placed in the Rules Docket. A copy 
of it, if filed, may be obtained from the 
Rules Docket at the location provided 
under the caption “ ADDRESSES".
List o f Subjects in 14 CFR Part 39
Air transportation, Aircraft, Aviation 
safety, and Safety.
Adoption o f the Amendment
Accordingly, pursuant to the authority 
delegated to me by the Administrator, 
the Federal Aviation Administration 
amends 14 CFR part 39 of the Federal 
Aviation Regulations as follows:
PART 39— AIRWORTHINESS  
DIRECTIVES
1. The authority citation for part 39 
continues to read as follows:
Authority: 49 U.S.C. 1354(a), 1421 and 1423; 
49 U.S.C. 106(g); and 14 CFR 11.89,
§ 39.13 [Amended]
2. Section 39.13 is amended by adding 
the following new airworthiness 
directive.
AD 92-07-08 BoD Helicopter Textron,
Inc., (BHTI): Amendment 39-8204 Docket No. 
92-ASW -02.
Applicability: Model 204B, 205A. 205A-1. 
205B and 212 helicopters, certificated in any 
category, equipped with swashplate support 
assembly, part number (P/N) 204-011-404- 
125.
Compliance: Required as indicated, unless 
already accomplished.
To prevent possible failure of the 
swashplate support assembly that could 
result in loss of the helicopter, accomplish the 
following:
(a) Within the next 25 hours' time in service 
after the effective date of this AD, determine 
the purchase date of the swashplate support 
assembly, P/N 204-011-404-125, by reviewing 
the maintenance records. If the assembly was 
purchased prior to June 1990. no further 
action is required. If the swashplate support 
assembly was purchased after June 1990, 
accomplish the requirements of paragraph
(b).
(b) Perform the following:
(1) Disassemble the swashplate support 
assembly in accordance with the applicable 
component overhaul manual to the point 
necessary to allow an inspection of the 
outboard gimbal ring support lug and 
shoulder bushing.
(2) Measure the outside diameters (OD) of 
the bushing flange on each outboard bushing.
(i) If each outboard bushing has a flange 
OD of 0.61 to 0.64 inches, no further 
inspections are required.
(ii) If either bushing has a flange OD in 
excess of 0.64 inches, replace the swashplate 
support assembly with an airworthy part 
before further flight
Note: Unapproved bushings with OD's of 
approximately 0.81 inches have been 
reported.
(c) Prior to the installation of any 
swashplate support assembly, P/N 204-011- 
404-125, comply with this AD.
(d) Special flight permits may be issued in 
accordance with FAR 21.197 and 21.199 to 
operate the helicopter to a location where the 
requirements of this AD can be 
accomplished.
(e) An alternative method of compliance or 
adjustment of the compliance times, which 
provides an acceptable level of safety, may 
be used when approved by the Manager, 
Rotorcraft Certification Office, ASW -170, 
Rotorcraft Directorate, Aircraft Certification 
Service, FAA, Southwest Region, 4400 Blue 
Mound Road, Fort Worth, Texas 76193-0170. 
The request shall be forwarded through an 
FAA Airworthiness Inspector, who may 
concur or comment and then sent it to the 
Manager of the Rotorcraft Certification 
Office.
(f) Bell Helicopter Textron, Inc., Alert 
Service Bulletins 204-91-32, 205-91-45, 205B- 
91-10, and 212-91-72, all dated December 13,
1991, provide an acceptable, alternate means 
of compliance with this AD.
(g) This amendment becomes effective on 
March 25,1992.
Issued in Forth Worth, Texas, on March 5,
1992.
Henry A. Armstrong,
Acting Manager, Rotorcraft Directorate, 
A ircraft Certification Service.
[FR Doc. 92-6893 Filed 3-24-92; 8:45 am]
BILLING CODE 4S10-13-M
DEPARTMENT OF HEALTH AND  
HUMAN SERVICES
Social Security Administration
20 CFR Part 416
[Regulation No. 16]
RIN 0960-AD09
Supplemental Security Income;  
Determining Disability for a Child 
Under Age 16; Correction
a g e n c y; Social Security Administration, 
HHS,.
ACTION: Correcting amendments.
SUMMARY: This document contains a 
correction to the final regulations which 
were published Monday, February IT 
1991, at 56 FR 5534. The regulations 
revised the disability evaluation and 
determination process for supplemental 
security income (SSI) claims of children 
based on disability.
EFFECTIVE DATE: February 11,1991.
FOR FURTHER INFORMATION CONTACT: 
Martin Sussman, Legal Assistant, Office 
of Regulations, Social Security 
Administration, 6401 Security 
Boulevard, Baltimore, Maryland 21235, 
telephone (410) 985-1758.
SUPPLEMENTARY INFORMATION:
Background
On February 11,1991, we published in 
the Federal Register a final rule with 
request for comments which revised the 
process for determining SSI claims 
based on disability for a child under age
18. The revisions were designed to 
comply with the February 20,1990, U.S. 
Supreme Court ruling in the case of 
S u lliv a n v. Z e b le y, 493 U.S. 521,110 S. 
Ct. 885 (1990). In Z e b le y, the Supreme 
Court required the use of an 
individualized functional assessment of 
children whose impairments did not 
meet or equal the severity of listed 
impairments.
Although the revised regulations were 
issued as a final rule, we asked for 
comments concerning these rules from 
members of the public. We are carefully 
considering the comments we received 
in order to determine whether any 
changes are necessary.
Need for Correction
The final regulations published in the 
Code of Federal Regulations (April 1, 
1991 edition) inadvertently deleted a 
sentence in § 416.994(b)(4)(ii) which we 
did not amend when we revised the 
section effective February 11,1991. This 
document corrects the sentence in the 
regulations.
(Catalog of Federal Domestic Assistance 
Program No. 93.807 Supplemental Security 
Income.)
List of Subjects in 20 CFR Part 416
Administrative practice and 
procedure, Aged, Blind, Disability 
benefits, Public Assistance programs, 
Supplemental Security Income.
PART 416— SUPPLEMENT AL  
SECURITY INCOME FOR TH E AGED,  
BLIND, AND DISABLED
Accordingly, 20 CFR part 416, subpart 
I is corrected by making the following 
correcting amendments:

```

### T58ac3fe191d5fa167a4c07bb

Text hash 85559fb3efa04a012e456f0f1e7f401756b7f1ae3d3f3a795b70d7e3933b939f; absolute characters 0–1772; files: jobs/fr-originals/data/full_run/texts/EO_12312.txt

```text
Instrument: EO:12312
Source: https://www.govinfo.gov/content/pkg/FR-1981-07-08/pdf/FR-1981-07-08.pdf
SHA-256 of the downloaded file: ba9413ef05ba76ffdff3ced429da8b556200450df8971c629a9e85f5e98d2326
Location: 46 FR 35251, PDF pages 9-9 (confidence high)
Machine-extracted text layer of the official PDF (OCR for 1936-1994 scans). May contain recognition errors and parts of neighbouring documents on the same pages. Not an authenticated transcription: check the PDF pages.

=== PDF page 9 of 200 ===
Federal Register 
Vol. 46, No. 130 
Wednesday, July 8, 1981
Presidential Documents
3 5251
The President
Executive Order 12312 of July 2, 1981
The Meritorious Service Medal
By the authority vested in me as President of the United States of A m erica and 
as C om m ander-in-Chief of the Armed Forces, and to permit the aw ard of the 
M eritorious Service M ed al to m em bers of the armed forces of friendly foreign 
nations, it is hereby ordered that section 1 of E xecutive O rder Number 11448 
of January 16,1969, is am ended to read as follow s:
“Section 1. There is hereby established  a M eritorious Service M edal, with 
accom panying ribbons and appurtenances, for aw ard by the Secretary  o f a 
M ilitary D epartm ent or th e Secretary  of Transportation with regard to the 
C oast Guard w hen not operating as a service in the Navy, or by such m ilitary 
com m anders or other appropriate officers as the Secretary  concerned m ay 
designate, to any m em ber of the arm ed forces of the United States, or to any 
m em ber of the arm ed forces of a friendly foreign nation, who has distin­
guished him self by outstanding m eritorious achievem ent or service.”.
THE W H ITE HOUSE, 
J u ly  2, 1981
(FR Doc. 81-20114 
Filed 7-6-81; 2:29 pm] 
Billing code 3195-01-M

```

### T6afd383918d43b1cc512e86f

Text hash 76f891cde9ad452e56d7c4eaa3b216c1b3ff68bcd54e29825e55be3709c3a6f3; absolute characters 0–2895; files: jobs/fr-originals/data/full_run/texts/EO_12985.txt

```text
Instrument: EO:12985
Source: https://www.govinfo.gov/content/pkg/FR-1996-01-18/pdf/96-622.pdf
SHA-256 of the downloaded file: eece26bfc0809ebfef4b097a78abfcfe4e59788c977ae20b07ab24ab82428023
Location: 61 FR 1209, PDF pages 1-1 (confidence high)
Machine-extracted text layer of the official PDF (OCR for 1936-1994 scans). May contain recognition errors and parts of neighbouring documents on the same pages. Not an authenticated transcription: check the PDF pages.

=== PDF page 1 of 1 ===
Presidential Documents
1209Federal Register / Vol. 61, No. 12 / Thursday, January 18, 1996 / Presidential Documents
Executive Order 12985 of January 11, 1996
Establishing the Armed Forces Service Medal
By the authority vested in me as President by the Constitution and the
laws of the United States of America, including my authority as Commander
in Chief of the Armed Forces of the United States, it is hereby ordered
as follows:
Section 1. Establishment. There is hereby established the Armed Forces
Service Medal with accompanying ribbons and appurtenances, for award
to members of the Armed Forces of the United States who, on or after
June 1, 1992, in the opinion of the Joint Chiefs of Staff: (a) Participate,
or have participated, as members of United States military units in a United
States military operation in which personnel of any Armed Force participate
that is deemed to be significant activity; and
(b) Encounter no foreign armed opposition or imminent hostile action.
Sec. 2. Approval and Award. The medal, with ribbons and appurtenances,
shall be of an appropriate design approved by the Secretary of Defense
and shall be awarded by the Secretary of Defense and the Secretary of
Transportation with respect to the Coast Guard when it is not operating
as a service in the Navy, under uniform regulations, as prescribed by the
Secretary of Defense. The regulations shall place the Armed Forces Service
Medal in an order of precedence immediately before the Humanitarian Serv-
ice Medal.
Sec. 3. Criteria. The medal shall be awarded only for operations for which
no other United States service medal is approved. For operations in which
personnel of only one Military Department or the Coast Guard participate,
the medal shall be awarded only if there is no other suitable award available
to the department or the Coast Guard. No more than one medal shall be
awarded to any one person, but for each succeeding operation justifying
such award a suitable device may be awarded to be worn on the medal
or ribbon as prescribed by appropriate regulations.
Sec. 4. Posthumous Provision. The medal may be awarded posthumously
and, when so awarded, may be presented to such representative of the
deceased as may be deemed appropriate by the Secretary of Defense or
the Secretary of Transportation.
œ–
THE WHITE HOUSE,
January 11, 1996.
[FR Doc. 96–622
Filed 1–17–96; 8:45 am]
Billing code 3195–01–P
```

### Tf97c5d91a174aceeb9030e68

Text hash d6b7d63e64087aa7cde884e5e6a83fa124c0e771aaaaf71f920985ce63be944f; absolute characters 0–22312; files: jobs/fr-originals/data/full_run/texts/EO_12830.txt

```text
Instrument: EO:12830
Source: https://www.govinfo.gov/content/pkg/FR-1993-01-13/pdf/FR-1993-01-13.pdf
SHA-256 of the downloaded file: c96e10693967f7cf75325225add4bb42925b2ab9d6ebdfee397dad865fe39348
Location: 58 FR 4061, PDF pages 13-17 (confidence high)
Machine-extracted text layer of the official PDF (OCR for 1936-1994 scans). May contain recognition errors and parts of neighbouring documents on the same pages. Not an authenticated transcription: check the PDF pages.

=== PDF page 13 of 252 ===
Federal Register /  Vol. 58, No. 8 /  Wednesday, January 13, 1993 /  Presidential Documents 4061
Presidential Documents
| F R  Doc. 93-947 
Filed 1-11-93; 2:11 pm] 
Billing code 3195-01-M
E xecu tiv e O rd er 1 2 8 3 0  o f Ja n u a ry  9 , 1 9 9 3
Establishing the Military Outstanding Volunteer 
Service Medal
By the authority vested in me as President by the Constitution and the 
laws of the United States of America, and as Commander in C hief o f the 
Armed Forces, it is hereby ordered as follows:
Section 1. There is hereby established a M ilitary Outstanding Volunteer 
Service Medal, with accompanying ribbons and appurtenances, for award 
by the Secretary of Defense or, with respect to the Coast Guard when 
it is not operating as a service in the Navy, the Secretary of Transportation. 
Members of the Armed Forces of the United States (including Reserve compo­
nents) who perform outstanding volunteer service to the civilian community 
of a sustained, direct, and consequential nature are eligible for the medal.
Sec. 2 >  The Military Outstanding Volunteer Service Medal and ribbons and 
appurtenances thereto shall be of appropriate design approved by the Sec­
retary of Defense. The Secretary of Defense shall prescribe regulations to 
govern the award and wear of the Military Outstanding Volunteer Service 
Medal. The regulations shall place the Military Outstanding Volunteer Service 
Medal in order of precedence immediately after the Humanitarian Service 
Medal.
Sec. 3. No more than one award of the M ilitary Outstanding Volunteer 
Service Medal may be made to any one person, but for each subsequent 
act justifying such an award, a suitable device may be awarded to be worn 
with that medal as prescribed by appropriate regulations issued by the 
Secretary of Defense.
Sec. 4. The Military Outstanding Volunteer Service Medal may be awarded 
posthumously, and when so awarded, may be presented to such representa­
tives of the deceased as may be deemed appropriate by the Secretary of 
Defense or, in the case of a member of the Coast Guard when it is not 
operating as a service in the Navy, the Secretary of Transportation.
THE WHITE HOUSE, 
J a n u a r y  9 , 1 9 9 3 .

=== PDF page 14 of 252 ===

=== PDF page 15 of 252 ===
4063
Rules and Regulations Federal Register  
Vol. 58, No. 8
Wednesday, January 13, 1993
Th is  section of the F E D E R A L  R E G IS T E R  
contains regulatory docum ents havin g general 
applicability and legal effect, m ost of w hich 
are keyed to a n d  codified in the C o d e  of 
Federal R egulations, w hich is published unde r 
50 titles pursuant to  4 4  U .S .C . 1510.
T h e  C o d e  of Fe d e ra l R egulations is sold b y 
the Superintendent of D ocum en ts. P rice s of 
new books are listed in the first F E D E R A L  
R E G IS T E R  issue of each w eek.
DEPARTMENT O F AGRICULTURE
Commodity Credit Corporation
7 CFR Part 1410
BINS 0560-AC66 and 0560-AC93
Amendments to the Conservation  
Reserve Program Regulations  
Regarding Small Wetlands and Other  
Statutory Requirements
A GEN CY: Commodity Credit Corporation, 
USDA.
A C T IO N : Final rule.
SU M M A R Y : This action covers four 
general areas. First, the final rule 
adopts, with changes, the proposed rule 
published on June 25,1992, at 57 FR 
28468 concerning the eligibility of small 
farmed wetlands to be enrolled in the 
Conservation Reserve Program (CRP). 
This allows producers greater flexibility 
in both enrolling and achieving 
enhanced environmental benefits under 
CRP. Second, the regulations are 
amended to incorporate certain 
nondiscretionary changes regarding 
limited grazing and easement 
requirements of the CRP, as required by 
the Food, Agriculture, Conservation, 
and Trade Act Amendments of 1991 
(the 1991 Act) (Pub. L. 102-237) and 
legislation entitled “To Amend the Food 
Security Act of 1985 To. Remove Certain 
Easement Requirements Under the 
Conservation Reserve Program and for 
Other Purposes“ (the 1992 Act) (Pub. L. 
102-324). Third, the regulations are 
amended to be consistent with the 
Wetlands Reserve Program (WRP) 
provisions relative to CRP participants 
offering eligible wetlands for enrollment 
into the WRP. The WRP final rule was 
published on June 4,1992 (57 FR 
23908). Fourth, the regulations are 
amended to ensure clarity and accuracy. 
EFFECTIVE DATE: January 13,1993.
FO R  FU RTH ER IN FO R M A T IO N  CO N TA CT:
James R. McMullen, Director, 
Conservation and Environmental 
Protection Division, ASCS, USDA, P.O. 
Box 2415, Washington, DC 20013-2415; 
phone 202-720-6221.
SUPPLEM ENTARY IN FO R M A T IO N : This final 
rule has been reviewed under USDA 
procedures established in accordance 
with Executive Order 12291 and 
provisions of Departmental Regulation 
1512-1 and has been classified as 
“nonmajor.“ It has been determined that 
these provisions will not result in: (1)
An annual effect on the national 
economy of $100 million or more; (2) a 
major increase in costs or prices for 
consumers, individual industries, State 
or local agencies, or geographic regions; 
or (3) significant adverse effects on 
competition, employment, investment, 
productivity, innovation, or on the 
ability of United States-based 
enterprises to compete with foreign- 
based enterprises in domestic or export 
markets.
It has been determined by an 
environmental evaluation that this 
action will not adversely affect the 
environmental, historical, social, or 
economic resources of the Nation. 
Therefore, it has been determined that 
these actions will not require an 
Environmental Assessment nor an 
Environmental Impact Statement.
This program/activity is not subject to 
the provisions of Executive Order 12372 
which requires intergovernmental 
consultation with State and local 
officials. See notice related to 7 CFR 
part 3015, subpart V, published at 48 FR 
29115 (June 24,1983).
This final rule has been reviewed in 
accordance with Executive Order 12778. 
The provisions of this final rule are not 
retroactive and do not preempt State 
laws. Before any judicial action may be 
taken with respect to the provisions of 
this final rule, administrative remedies 
at 7 CFR part 780 must be exhausted.
The title and number of the Federal 
Domestic Assistance Program, as found 
in the Catalog of Federal Domestic 
Assistance, to which this rule applies 
are Conservation Reserve Program— 
10.069.
The information and collection 
requirements of this final rule at 7 CFR 
part 1410 have been submitted to the 
Office of Management and Budget for 
review and approval in accordance with 
the Paperwork Reduction Act of 1980. A 
response from OMB regarding the
information collection approval is 
forthcoming.
The public reporting burden for the 
information collections required by this 
final rule is estimated to be 7 minutes 
per response, including the time for 
reviewing instructions, searching 
existing data sources, gathering and 
maintaining the data needed, and 
completing and reviewing the collection 
of information.
Current Regulations
The current regulations in 7 CFR part 
1410, published as a final rule on April 
19,1991 (56 FR 15980), implemented 
the Environmental Conservation 
Acreage Reserve Program, which 
consists of CRP and WRP.
The intent of CRP is to permit the 
Commodity Credit Corporation (CCC) to 
enter into contracts with owners and 
operators of highly erodible and other 
environmentally sensitive cropland to 
assist such owners and operators in 
conserving and improving the Nation’s 
soil and water resources. By entering 
into a contract, the owner or operator 
agrees to implement a conservation plan 
approved by the local Conservation 
District for converting highly erodible 
cropland normally devoted to the 
production of an agricultural 
commodity to a less intensive use. CCC 
provides (1) technical assistance by way 
of a conservation plan, (2) financial 
assistance for the costs of establishing 
the conservation practices required by 
the conservation plan, and (3) annual 
land rental payments to compensate the 
owner or operator for taking the 
cropland out of production.
The current regulations address the 
following terms and conditions of the 
CRP for enrollment during 1991 through 
1995: (1) eligibility of land; (2) duration 
of contracts; (3) obligations of 
participants and CCC; (4) eligible 
practices; (5) levels of cost-share for 
establishing practices; (6) provisions for 
annual rental payments; (7) handling of 
violations; and (8) other program 
matters.
With respect to land eligibility,
§ 1410.103 provides that the Secretary of 
Agriculture (Secretary) may consider 
certain lands to be eligible for CRP if a 
useful life easement is created for the 
practice. Further, § 1410.103 prohibits 
the enrollment of farmed wetlands 
otherwise eligible for CRP.
Section 1410.108 permits, if approved 
by CCC, land subject to an existing CRP

=== PDF page 16 of 252 ===
4 0 6 4 Federal Register /  Vol. 58, No. 8 /  Wednesday, January 13, 1993 /  Rules and Regulations
contract to be enrolled into WRP, 
provided that (1) the application for 
transfer into WRP is made during the 
first or second available signup for 
intention period under the WRP for the 
State, and (2) all funds and benefits paid 
under the CRP contract were refunded 
with interest.
Section 1410.110 generally prohibits 
any harvesting, or grazing, or other 
commercial use of the forage on land 
subject to a CRP contract, except that 
the Secretary could permit fall and 
winter grazing of grass waterways where 
the grazing is incidental to the gleaning 
of crop residue on the fields in which 
the grass waterways are located for an 
applicable reduction in rental payment.
Statutory Changes
Title XII of the Food, Agriculture, 
Conservation, and Trade Act of 1990 
(the*199G Act) (Pub. L. 101-624) enacted 
on November 28,1990, amended the 
Food Security Act of 1985 (the 1985 
Act) (Pub. L. 99-198) with respect to 
CRP. Section 1232(a)(7) of the 1990 Act 
was amended on December 13,1991, by 
the 1991 Act to specify that the 
Secretary may permit incidental grazing 
of CRP (1) during the 7-month period in 
which grazing of conserving use acreage 
is allowed in a State under the price 
support programs, or (2) after the 
producer harvests the grain crop of the 
surrounding field. In either case, the 
CRP rental payment must be reduced 
commensurate with the limited 
economic value of such incidental 
grazing. J J
The 1992 Act amended section 
1231(b)(4)(C) and section 1235A(a)(2) of 
the 1985 Act, as amended, to remove 
certain easement requirements under 
CRP.
Other Changes
This rule also (1) amends the 
regulations in 7 CFR 1410.108 to reflect 
consistency with the final rule for WRP 
published at 7 CFR part 703 on June 4, 
1992, (2) corrects a typographical error, 
(3) includes minor editorial changes for 
clarity, and (4) due to further review of 
statutory authority, removes the 
provision that payments made under 
part 1410 are subject to the regulations 
under 7 CFR part 796—Denial of 
Program Eligibility for Controlled 
Substance Violation.
CRP will continue to be implemented 
by CCC through the Agricultural 
Stabilization and Conservation Service 
(ASCS) using ASCS’s State and county 
offices.
Discussion of Comments
CCC received five comments ,  
concerning the proposed rule published
on June 25,1992, at 57 FR 28468.
Entities responding included a State 
farm organization, a national farm 
organization, two national wildlife 
organizations, and a member of 
Congress. The discussion of comments 
that follows is organized in the same 
sequence as the final rule.
Thus, all the changes made by this 
final rule are based on a combination of 
the public comments to the proposed 
rule, recent legislative changes and 
other statutory requirements, CCC’s 
experience in administering CRP since 
inception, and the need for clear, 
current, and consistent regulations.
S ection  1410.103 E lig ible L an d
Three comments supported the 
inclusion of small farmed wetlands as 
land eligible to be enrolled in CRP, 
stating that the proposal would not 
interfere with the enrollment of eligible 
land into WRP, and this expansion of 
cropland eligibility would further 
enhance the improvement of soil and, 
water resources. Two additional 
comments supported the concept and 
recommended that the approved plan 
provide for the continued protection of 
the eligible small wetland areas and that 
these areas be contained in fields that 
are otherwise eligible for CRP. Although 
this was the intent of the proposed rule, 
the final rule has been clarified to 
ensure that the small farmed wetlands 
to be enrolled are (1) limited to small 
areas included in otherwise eligible 
fields, and (2) guaranteed enduring 
protection under the approved 
conservation plan.
List of Subjects in 7 CFR Part 1410
Administrative practices and 
procedures, Conservation plan. 
Contracts, Easements, Environmental 
indicators, Natural resources, and 
Technical assistance.
Accordingly, 7 CFR part 1410 is 
amended as follows:
PART 1410-1991-95 CONSERVATION  
RESERVE PROGRAM
1. The authority citation for 7 CFR 
part 1410 continues to read as follows:
Authority: 15 U.S.C. 714b and 714c; 16 
U.S.C. 3831-3847.
§1410.13 [Amended]
2. Section 1410.13 is amended by 
removing paragraph (a) and designating 
paragraphs (b), (c), and (d) as paragraphs 
(a), (b), and (c).
3. Section 1410.103 is amended bv:
A. Revising paragraphs (d)(2), (d)(3), 
and (d)(4); and
B. Revising paragraph (f)(2) to read as 
follows:
§1410.103 Eligible land.
*  *  *  *  *
(d) * * *
(2) Land devoted to living 
snowfences, windbreaks, wildlife 
habitat, shelterbelts or filterstrips with 
trees or shrubs;
(3) Land devoted to newly created 
permanent grass waterways or contour 
grass sod strips created after November 
28,1990, which are established and 
maintained according to an approved 
conservation plan;
(4) Non-irrigated or irrigated cropland 
which produce, as determined by the 
Deputy Administrator, saline seeps or 
which are functionally related to such 
saline seeps, or where a rising water 
table contributes to increased levels of 
salinity at or near the ground surface.
* * * * *
( f ) *  * *
(2) Farmed wetlands which may be 
eligible for the Wetlands Reserve 
Program (WRP) under 7 CFR part 703, 
except this restriction shall not apply to 
small farmed wetlands contained in, 
and are a part of, fields that are 
otherwise eligible for CRP as 
determined by CCC.
§1410.108 [Amended]
4. Section 1410.108 is amended as 
follows:
A. The introductory sentence is 
amended by removing the phrase 
“provided that" and all that follows to 
and including "prior to October 1, 
1992;" and inserting in lieu thereof the 
following: "provided that such offer for 
transfer occurs during the first or second 
available signup for intention period 
under the WRP for the State and agreed 
to by ASCS. Transfers on offers 
submitted after the second available 
WRP signup period within a State will 
only be permitted if the owner agrees to 
refund all payments received under CRP 
since the close of the second available 
WRP signup period within the State”; 
and
B. Paragraph (b) is amended by 
removing the word "letter" and 
inserting the word "title" in its place.
5. Section 1410.110 is amended by 
revising paragraph (d) to read as 
follows:
§1410.110 Obligations of the Commodity  
Credit Corporation. 
* * * * *
(d) Permit grazing of grassed 
waterways on CRP land where the 
grazing is incidental to the gleaning of 
crop residues on fields where the 
contracted land is located, such 
incidental grazing is limited to the 7- 
month period in which grazing of 
conservation use acreage is allowed, as

=== PDF page 17 of 252 ===
F e d e ra l R egister /  Vol. 58, No. 8 /  Wednesday, January 13. 1993 /  Rules and Regulations 4 0 6 5
determined by CCC, in a State under the 
Agricultural Act of 1949 (7 U.S.C. 1421 
et seq .), or after the producer harvests 
the grain crop of the surrounding field. 
Further, CCC must provide prior 
approval of the incidental grazing of the 
CRP in exchange for an applicable 
reduction in the annual rental payment, 
as determined appropriate by the 
Deputy Administrator.
Signed at Washington, DC on January 5, 
1993.
John A. Stevenson,
A cting E x ecu tiv e V ice P resid en t, C om m od ity 
C redit C orp oration .
[FR Doc. 93-759 Filed 1-12-93; 8:45 am] 
B IL U N Q  C O D E  3 4 1 0 -0 8 -»*
Farmers Home Administration  
7 CFR Part 1900
Reporting Authorities for Internal  
Processing of Appeals Cases
AGENCY: Farmers Home Administration, 
USDA.
ACTION: Final rule. _______
SU M M A R Y : The Farmers Home 
Administration (FmHA) amends its 
regulations regarding designated 
reporting authorities for internal 
processing of appeals cases. This action 
is necessary due to Agency provisions 
which require certain Agency officials 
to make decisions for cases in the 
appeal process. The intended effect is to 
ensure correct processing of appeals. 
EFFECTIVE DATE: January 1 3 ,1 9 9 3 .
FO R  FU RTH ER IN FO R M A T IO N  CO N TA CT: 
Jennifer Barton, Community Facilities 
Division, Farmers Home 
Administration, room 6 314, South 
Agriculture Building, Washington, DC 
20250, telephone (202) 7 2 0 -1 5 0 4 .
SUPPLEM ENTARY IN FO R M A T IO N : This 
action has been reviewed under USDA 
procedures established in Departmental 
Regulation 1512-1, which implements 
Executive Order 12291. Since this 
action has no impact on FmHA 
borrowers or other members of the 
public, it has been determined to be 
exempt from those requirements 
because it involves only internal Agency 
management. It is the policy of this 
Department to publish, for comment, 
rules relating to public property, loans, 
grants, benefits, or contracts, 
notwithstanding the exemption in 5 
U.S.C. 553 with respect to such rules. 
This action, however, is not published 
for proposed rule making since it 
involves only internal Agency 
management and publication for 
comment is unnecessary. Community 
and Business Programs have been 
assigned to the Rural Development 
Adm inistration (RDA), and RDA is now 
administering this program. RDA is 
utilizing FmHA regulations which 
makes it necessary to establish the 
organizational structure of RDA's 
reporting authorities for its Regional 
Office operations. Specifically, Exhibit 
D of subpart B of part 1900 is amended 
to include RDA personnel as decision 
makers for RDA cases involved in 
appeals.
Environmental Impact Statement
This document has been reviewed in 
accordance with 7 CFR part 1940, 
subpart G, “Environmental Program.” 
FmHA has determined that this action 
does not constitute a major Federal 
action significantly affecting the quality 
of the human environment, and, in 
accordance with the National 
Environmental Policy Act of 1969, 
Public Law 91-190, an Environmental 
Impact Statement is not required.
Intergovernmental Review
T h e  programs adm inistered w ill be
listed in the Catalog of Federal Domestic 
Assistance and will be subject to the 
provisions of Executive Order 12372 
which requires intergovernmental 
consultation with State and local 
officials. This action affects the 
following programs:
10.414 Resource Conservation and 
Development Loans;
10.418 Water and Waste Disposal Systems 
for rural communities;
10.419 Watershed Protection and Flood 
Prevention;
10.422 Business and Industrial Loans;
10.423 Community Facilities Loans;
10.424 Rural Development Grants;
10.434 Nonprofit National Corporation; 
10.436 Technical Assistance and Training
Grants;
10.438 Intermediary Relending Program; 
10.440 Emergency Community Water 
Assistance Grants.
FmHA conducts intergovernmental 
consultation in the manner delineated 
in FmHA Instruction 1940-J. Programs 
10.414,10.418,10.419,10.422,10.423, 
and 10.438 are subject to the provisions 
of E .0 .12372; the remaining programs 
affected are not subject to this provision.
List of Subjects in 7 CFR part 1900
Appeals, Credit, Loan programs— 
Housing and community development.
Accordingly, part 1900 of chapter 
XVIII, title 7, Code of Federal 
Regulations is amended as follows:
PART 1900— GENERAL
1. The authority citation for part 1900 
continues to read as follows:
Authority: 7 U.S.C. 1989; 42 U.S.C. 1480;
5 U.S.C 301; 7 CFR 2.23; 7 CFR 2.70.
2. Exhibit D of subpart B is revised to 
read as follows:
Exhibit D of Subpart B—Hearinga/Review Officer Designations
Hearing/Review  O fficer  D esignations
Decisionmaker or decision Hearing officer Review officer
State Director and/or Director, National Appeals Staff. 
State Director anchor Director, National Appeals Staff. 
"State Director and/or Director, National Appeals 
Staff.
Director, National Appeals Staff.
Director, National Appeals Staff.
Director, National Appeals Staff.
Director, National Appeals Staff.
'District Director, 'State Program Chief. 'District Spe­
cialist. As appointed by Director, National Appeals Staff------
As appointed by Director, National Appeals Staff------
As appointed by Director, National Appeals Staff------
As appointed by Director, National Appeals Staff.......Deputy or Associate Administrator------------------------—
'Decisionmaker lor Rural Development Administration (R D A ) cases tor Ftef l j o ^ l . O ^  P t ? ? S S P :---------
“ Review officer win be the Regional Director and/or the Director. National Appeals Stall lor R D A  cases.
Notes
1. District Director also means 
Assistant District Director or District 
Loan Specialist.
2. County Supervisor also means 
Assistant County Supervisor with loan 
approval authority.
3. The Director of the National 
Appeals Staff may designate a staff 
member to conduct a hearing or review. 
When the hearing/review is completed,

```

## EO:12312

Fingerprint: b5dad51370d2a4a47b04b3e67dead2dda38e9bb63a205cec72c960d39c4d2787; provisional status: yes
Ownership/routing: {"route":"new_producer_proposal"}
Required member checks: earlier ending; scope; independent commands; savings.

### Evidence index

- **ACT:EO:12312>EO:13286**; Sd3145c7b44424f882132e4cb; {"actor_id":"EO:13286","char_end":36505,"char_start":36258,"confidence":"medium","effective_class":"unknown","effective_date":null,"effective_wording":[{"char_end":2501,"char_start":2411,"text":"Executive Order 13260 of March 19, 2002, is hereby revoked effective as of March 31, 2003."},{"char_end":41701,"char_start":40943,"text":"(a)\nin the case of the Department of Defense, the Secretary of Defense has, after consideration of the authority provided under subtitle G of title VIII of the Homeland Security Act of 2002, determined that the exercise of authority under this order is necessary for the timely and effective conduct of United States military or intelligence activities; and\n(b)\nin the case of any other executive department or agency that has authority under this order, (i) the Secretary of Homeland Security has advised whether the use of the authority provided under subtitle G of title VIII of the Homeland Security Act of 2002 would be appropriate, and (ii) the Director of the Office and Management and Budget has approved the exercise of authority under this order.\"."},{"char_end":49577,"char_start":49526,"text":"This order shall become effective on March 1, 2003."}],"exceptions_text":[],"filing_date":null,"id":"ACT:EO:12312>EO:13286","names_target":false,"notes":"Machine lead only; no legal ending asserted. Effective wording is ambiguous, section-specific, or has no determinable date. Indirect parent membership is an unconfirmed lead.","provision_label":"Sec. 61.","reaches_target_via":"EO:11448 as amended","savings_phrases":["Without prejudice to subsections (a) through (i) of this section, all responsibilities assigned to specific Federal officials pursuant to Executive Order 12656 that are substantially the same as any responsibility assigned to, or function transferred to, the Secretary of Homeland Security pursuant to the Homeland Security Act of 2002 (regardless of whether such responsibility or function is expressly required to be carried out through another official of the Department of Homeland Security or not pursuant to such Act), or intended or required to be carried out by an agency or an agency component transferred to the Department of Homeland Security pursuant to such Act, are hereby reassigned to the Secretary of Homeland Security.","Executive Order 11239 of July 31, 1965 (\"Enforcement of the Convention for Safety of Life at Sea, 1960\"), as amended, is further amended, without prejudice to section 1–106 of Executive Order 12234 of September 3, 1980 (\"Enforcement of the Convention for the Safety of Life at Sea\"), by:","Savings Provision."],"scope":"partial","signing_date":"2003-02-28","target_id":"EO:12312","verb":"amend"}
  Exact retained record text (unshared):
Executive Order 11448 of January 16, 1969 ("Establishing the Meritorious Service Medal"), as amended, is further amended by striking "the Secretary of Transportation" in section 1 and inserting "the Secretary of Homeland Security" in lieu thereof.
- **ACT:EO:12312>EO:13286:effective#0**; Sd3145c7b44424f882132e4cb; {"actor_id":"EO:13286","char_end":2501,"char_start":2411,"id":"ACT:EO:12312>EO:13286:effective#0"}
  Exact retained record text (unshared):
Executive Order 13260 of March 19, 2002, is hereby revoked effective as of March 31, 2003.
- **ACT:EO:12312>EO:13286:effective#1**; Sd3145c7b44424f882132e4cb; {"actor_id":"EO:13286","char_end":41701,"char_start":40943,"id":"ACT:EO:12312>EO:13286:effective#1"}
  Exact retained record text (unshared):
(a)
in the case of the Department of Defense, the Secretary of Defense has, after consideration of the authority provided under subtitle G of title VIII of the Homeland Security Act of 2002, determined that the exercise of authority under this order is necessary for the timely and effective conduct of United States military or intelligence activities; and
(b)
in the case of any other executive department or agency that has authority under this order, (i) the Secretary of Homeland Security has advised whether the use of the authority provided under subtitle G of title VIII of the Homeland Security Act of 2002 would be appropriate, and (ii) the Director of the Office and Management and Budget has approved the exercise of authority under this order.".
- **ACT:EO:12312>EO:13286:effective#2**; Sd3145c7b44424f882132e4cb; {"actor_id":"EO:13286","char_end":49577,"char_start":49526,"id":"ACT:EO:12312>EO:13286:effective#2"}
  Exact retained record text (unshared):
This order shall become effective on March 1, 2003.
- **CLAUSES:EO:12312#whole**; S3d775115a695f2af4fd1dcb8; {"char_end":1669,"char_start":671,"id":"CLAUSES:EO:12312#whole","kind":"whole","label":"sole paragraph","pdf_page":9,"scope_id":"EO:12312#whole"}
  Text: [T58ac3fe191d5fa167a4c07bb](#t58ac3fe191d5fa167a4c07bb); absolute characters 671–1669
- **ORIGINAL:EO:12312**; S3d775115a695f2af4fd1dcb8; {"acceptable_as_original":true,"actor_id":"EO:12312","char_end":1772,"char_start":0,"grade":"original_representation_unverified","id":"ORIGINAL:EO:12312","location_confidence":"high","requires_page_check":false,"role":"original","signing_date":"1981-07-02"}
  Text: [T58ac3fe191d5fa167a4c07bb](#t58ac3fe191d5fa167a4c07bb); absolute characters 0–1772

### Complete operative inventory

- EO:12312#whole → CLAUSES:EO:12312#whole; characters 671–1669

### own_terms

[]

### actor_contexts

[{"actor_id":"EO:13286","overflow":"actor-texts/EO_13286.json","text_sha256":"57b106e01d54e1bcf61065a73a3591003b50eef2d8d0f65b0b54f98ea436e6df"}]

### actor_provisions

["ACT:EO:12312>EO:13286"]

### chain

{"confidence":"medium","events":[{"actor_id":"EO:13286","char_end":36505,"char_start":36258,"confidence":"medium","how_named":"parent_as_amended","id":"CHAIN:EO:12312#1","notes":"Change wording lead; chronology does not decide legal effect.","provision_text":"Executive Order 11448 of January 16, 1969 (\"Establishing the Meritorious Service Medal\"), as amended, is further amended by striking \"the Secretary of Transportation\" in section 1 and inserting \"the Secretary of Homeland Security\" in lieu thereof.","sections_touched":["section 1"],"signing_date":"2003-02-28","source":{"acceptable_as_original":false,"archival_id":"app:node/217113","filing_date":null,"grade":"mirror_transcription","instrument_id":"EO:13286","location_confidence":"medium","location_verified":false,"page_or_item":"Executive Order 13286—Amendment of Executive Orders, and Other Actions, in Connection With the Transfer of Certain Functions to the Secretary of Homeland Security; February 28, 2003; APP node 217113; common-crawl capture 2025-10-06T18:03:47Z","requires_page_check":true,"sha256":"c1a2aff53be0c95cb97e0871e389a3b185ae165f6dd9a539722ed1c45f135c34","signing_date":"2003-02-28","text_path":"jobs/app-executive-orders/output/texts/executive-order-13286-amendment-executive-orders-and-other-actions-connection-with-the.txt","text_sha256":"d24268c163cd19e82bda1102e745709657d237c65d627f55716beebc42ba94f0","url":"https://www.presidency.ucsb.edu/documents/executive-order-13286-amendment-executive-orders-and-other-actions-connection-with-the"},"verb":"amend"}],"generic_refs_excluded":221,"id":"CHAIN:EO:12312","notes":"Named, located change provisions only; missing provisions and unheld texts remain dossier gaps. Undated events sort last.","target_id":"EO:12312"}

### current_law_leads

[{"basis_code":"amending_order_in_status_line","checked_through":"2026-10-09","currency_code":"usc_release_point","edition":"U.S. Code release point 119-121","evidence_gap":"No uniquely located attributed legal-text slice is held for this current-law pointer; serialized JSON/JSONL, snippets and absent cache artifacts are not legal-text evidence.","fragment_kind":"current_predicate_candidates","input_origin":"jobs/current-law/output/FRAGMENTS.jsonl","instrument_id":"EO:12312","legal_basis_candidate":"order amended a printed order (weak lead) (10 U.S.C. subtitle A, pt. II, ch. 57 note)","machine_lead":true,"mention_id":"usc:e312b40f1545","snippet":"Ex. Ord. No. 11448, Jan. 16, 1969, 34 F.R. 915, as amended by Ex. Ord. No. 12312, July 2, 1981, 46 F.R. 35251; Ex. Ord. No. 13286, § 61, Feb. 28, 2003, 68 F.R. 10629, provided:","source":{"page_or_item":"10 U.S.C. subtitle A, pt. II, ch. 57 note; note 'Ex. Ord. No. 11448. Meritorious Service Medal' [USLM note id ida8989a54-3a6f-11f1-a58a-d8db54b14ab5]; usc10.xml (sha256 f6b1a4f0897cd19431abb8af52cf3aafb02cf6e1870f0f6b5d1992c37fe128b6) in xml_uscAll@119-121.zip","sha256":"c6122974e951003437ece5a998aa7c0b2cdc0f5703dfc78d6135e1fc9e729142","url":"https://uscode.house.gov/download/releasepoints/us/pl/119/121/xml_uscAll@119-121.zip"},"system":"usc","where":"USC 10 U.S.C. subtitle A, pt. II, ch. 57 note"},{"custody_records_in":["current-law"],"evidence_gap":"Current-law lead lacks an original-source sha256.","meta":{"basis_code":"amending_order_in_status_line","caution":"a mention in current law is a LEAD, not by itself a legal basis; read the provision to see whether it keeps the order operating","currency_code":"usc_release_point","edition":"U.S. Code release point 119-121","from":"current-law@jobs/current-law/output","from_job":"current-law","mention_id":"usc:e312b40f1545","snippet":"Ex. Ord. No. 11448, Jan. 16, 1969, 34 F.R. 915, as amended by Ex. Ord. No. 12312, July 2, 1981, 46 F.R. 35251; Ex. Ord. No. 13286, § 61, Feb. 28, 2003, 68 F.R. 10629, provided:","snippet_truncated":false,"system":"usc","where":"USC 10 U.S.C. subtitle A, pt. II, ch. 57 note"},"proposal":{"checked_through":"2026-10-09","legal_basis":"order amended a printed order (weak lead) (10 U.S.C. subtitle A, pt. II, ch. 57 note)","source":{"page_or_item":"10 U.S.C. subtitle A, pt. II, ch. 57 note; note 'Ex. Ord. No. 11448. Meritorious Service Medal' [USLM note id ida8989a54-3a6f-11f1-a58a-d8db54b14ab5]; usc10.xml (sha256 f6b1a4f0897cd19431abb8af52cf3aafb02cf6e1870f0f6b5d1992c37fe128b6) in xml_uscAll@119-121.zip","sha256":"c6122974e951003437ece5a998aa7c0b2cdc0f5703dfc78d6135e1fc9e729142","url":"https://uscode.house.gov/download/releasepoints/us/pl/119/121/xml_uscAll@119-121.zip"}}}]

### machine_searches

[{"complete":true,"entry":{"checked_on":"2026-10-17","query_or_scope":"every citation of this order by number (forms 'Executive Order', 'Ex. Ord.', 'E.O.') in the text and notes of the titles read; edition current through 2026-10-09 (laws enacted after that date and on or before 2026-10-14 are not reflected)","repository":"U.S. Code, Office of the Law Revision Counsel release point 119-121 (USLM XML, 58 title files), statute text and editorial notes","searched_by":"jobs/current-law (machine search)"},"machine_hits_for_this_order":1,"scope_note":"","search_id":"current-law:usc"},{"complete":true,"entry":{"checked_on":"2026-10-17","query_or_scope":"full-text search for 'Executive Order', 'Executive Orders', 'E.O.', 'Ex. Ord.', 'Exec. Order' and regulation text, authority and source citations naming this order","repository":"eCFR point-in-time search as of 2026-10-14 and GovInfo CFR bulk XML (49 titles read)","searched_by":"jobs/current-law (machine search)"},"machine_hits_for_this_order":1,"scope_note":"","search_id":"current-law:ecfr"},{"complete":true,"entry":{"checked_on":"2026-10-19","query_or_scope":"disposition notes of 6938 catalog records (1937 onward) naming this order as amended, revoked, superseded or otherwise affected, plus operative sentences in 17521 saved order texts","repository":"Federal Register executive-order catalog (federalregister.gov API v1, include_pre_1994_docs=true): Office of the Federal Register disposition notes","searched_by":"jobs/later-events (machine search)"},"machine_hits_for_this_order":0,"scope_note":"","search_id":"later-events:ofr_catalog"}]

### draft_gate_errors

["clause_0_state","yes_without_continuing_clause","savings_residuals_evidence","bounded_later_search","unresolved_material_gaps","research_rationale"]

### conflicts

[]

### draft_material_gaps

["DRAFT: state_at_cutoff not decided for 1 clause(s); clause inventory completeness not confirmed","DRAFT: current legal basis not established","DRAFT: savings and residual effects not closed","DRAFT: later_source_search not recorded (machine searches are proposals only; paste them after judging them adequate and resolving every CONFLICT line)"]

### missing

["Current legal predicate and coverage through 2026-10-14 require judgment; a citation or 1989 snapshot cannot prove continuation.","Current-law lead lacks an original-source sha256.","Large actor context must be read at actor-texts/EO_13286.json before deciding scope/savings.","No uniquely located attributed legal-text slice is held for this current-law pointer; serialized JSON/JSONL, snippets and absent cache artifacts are not legal-text evidence."]

### status_history

{"event_count":0,"fingerprint":"41e487658e60b7edd607b54fa146f47fe6fd1925ceeb5f6aa0f194fa2d73d293","flags":[],"history_path":"jobs/status-history/output/histories/EO_12312.json","history_sha256":"43baec86bf22472095acc3fbb9f829a438fbfae60295aeea4e47074aae2ecfc5","input_origin":"jobs/status-history/output/FRAGMENTS.jsonl","legal_cutoff":"2026-10-14","machine_lead":true,"notice":"Editorial leads, not an original, legal conclusion, provisional-status assignment or human certification.","observation_count":2}

### notice

"MACHINE LEADS ONLY. No segmentation, date, source grade, family or chain is a legal conclusion."

### Additional dossier metadata

{"lifecycle_obligations":[{"clause_sha256":"53e463e27e49e0a0db1637973670ec8ecaf8dad8a66f897d3e1c52db23442639","established_ending":null,"human_certified":false,"instrument_id":"EO:12312","later_actor_evidence_ids":[],"own_term_evidence_ids":[],"questions":["Determine the first cessation or current predicate for this scope; check independent commands and surviving effects."],"schema":"eo-lifecycle-obligation/v1","scope_id":"EO:12312#whole","state":"requires_clause_specific_research","wording_features":[]}]}

### Preflight

{"custody_validation":"required_from_actual_claim_checker","decisions_still_required":["complete original/inventory","earlier ending","partial scope and effective date","independent commands","savings/residuals","contrary evidence and cutoff predicate"],"evidence_preflight":"blocked_or_research","held_text_receipts":{"jobs/fr-originals/data/full_run/texts/EO_12312.txt":{"characters":1772,"raw_custody":"requires_actual_claim_checker","source_sha256":"ba9413ef05ba76ffdff3ced429da8b556200450df8971c629a9e85f5e98d2326","text_sha256":"85559fb3efa04a012e456f0f1e7f401756b7f1ae3d3f3a795b70d7e3933b939f"}},"instrument_id":"EO:12312","lifecycle_obligations":[{"clause_sha256":"53e463e27e49e0a0db1637973670ec8ecaf8dad8a66f897d3e1c52db23442639","established_ending":null,"human_certified":false,"instrument_id":"EO:12312","later_actor_evidence_ids":[],"own_term_evidence_ids":[],"questions":["Determine the first cessation or current predicate for this scope; check independent commands and surviving effects."],"schema":"eo-lifecycle-obligation/v1","scope_id":"EO:12312#whole","state":"requires_clause_specific_research","wording_features":[]}],"mechanical_tasks":[{"availability":"held_not_loaded","instrument_id":"EO:12312","kind":"load_actor_overflow","reason":"Read full overflow before scope/savings decision","shared_key":"EO:13286","task_id":"TASK:84afaf7b7ab986f33b60241f"},{"availability":"citation_or_pointer_only","instrument_id":"EO:12312","kind":"operative_current_law","reason":"No uniquely located attributed legal-text slice is held for this current-law pointer; serialized JSON/JSONL, snippets and absent cache artifacts are not legal-text evidence.","shared_key":"{\"basis_code\":\"amending_order_in_status_line\",\"source\":{\"page_or_item\":\"10 U.S.C. subtitle A, pt. II, ch. 57 note; note 'Ex. Ord. No. 11448. Meritorious Service Medal' [USLM note id ida8989a54-3a6f-11f1-a58a-d8db54b14ab5]; usc10.xml (sha256 f6b1a4f0897cd19431abb8af52cf3aafb02cf6e1870f0f6b5d1992c37fe128b6) in xml_uscAll@119-121.zip\",\"sha256\":\"c6122974e951003437ece5a998aa7c0b2cdc0f5703dfc78d6135e1fc9e729142\",\"url\":\"https://uscode.house.gov/download/releasepoints/us/pl/119/121/xml_uscAll@119-121.zip\"}}","task_id":"TASK:ed8b2928155d7c9542f32153"},{"availability":"citation_or_pointer_only","instrument_id":"EO:12312","kind":"operative_current_law","reason":"Current-law lead lacks an original-source sha256.","shared_key":"{}","task_id":"TASK:1b16444cae50780611b48e39"},{"availability":"absent_or_unreadable","instrument_id":"EO:12312","kind":"held_text_unavailable","reason":"[Errno 2] No such file or directory: '/workspace/scratch/a5be930883fa/eo-readiness/jobs/app-executive-orders/output/texts/executive-order-13286-amendment-executive-orders-and-other-actions-connection-with-the.txt'","shared_key":"jobs/app-executive-orders/output/texts/executive-order-13286-amendment-executive-orders-and-other-actions-connection-with-the.txt","task_id":"TASK:2f0d8690fd95d97958c0569d"}],"notice":"No known gap is not a legal-readiness finding. Review may expose new facts."}

### Prior research and remaining delta

{"conflicting_versions":[],"current_rulings":[{"expected_sha256":null,"path":"research/readiness/owner_rulings/2026-10-29-tiered-delegation.md","sha256":"20a27c48ee4b86711151ed632bcbab14028197e4a3430ad1431c86c004629cd6","state":"unqualified"}],"full_context":"PACKET.json#/prior_research/orders/EO:12312","notice":"Prior producer/reviewer assertions, not new findings or automatic approval. Reuse only after checking the exact version, source, proposition and scope. Rejected versions and contradictory assertions remain visible; whole-case review is still required.","remaining_delta":{"current_reported_gaps":[],"dossier_fingerprint":"b5dad51370d2a4a47b04b3e67dead2dda38e9bb63a205cec72c960d39c4d2787","existing_lifecycle_questions":[{"clause_sha256":"53e463e27e49e0a0db1637973670ec8ecaf8dad8a66f897d3e1c52db23442639","dossier_pointer":"/lifecycle_obligations/0","later_actor_evidence_ids":[],"own_term_evidence_ids":[],"questions":["Determine the first cessation or current predicate for this scope; check independent commands and surviving effects."],"scope_id":"EO:12312#whole","state":"requires_clause_specific_research"}],"existing_lifecycle_questions_notice":"Current dossier research prompts, not new gap findings or overrides of prior claim/review conclusions.","new_legal_gaps_invented":[],"prior_differences_require_scope_source_proposition_review":true},"selection_and_checkpoint_records":[],"state":"no_prior_research_located","status_holds":[],"status_research":[],"unattached_status_reviews":[],"unfinished_work":[],"versions":[]}

## EO:12830

Fingerprint: 014b9e3f3711e5013a17397f2f6e1c22951c8fab921b9e5d30ab42aa0011122c; provisional status: yes
Ownership/routing: {"route":"new_producer_proposal"}
Required member checks: earlier ending; scope; independent commands; savings.

### Evidence index

- **ACT:EO:12830>EO:13286**; Sd3145c7b44424f882132e4cb; {"actor_id":"EO:13286","char_end":21256,"char_start":21004,"confidence":"medium","effective_class":"unknown","effective_date":null,"effective_wording":[{"char_end":2501,"char_start":2411,"text":"Executive Order 13260 of March 19, 2002, is hereby revoked effective as of March 31, 2003."},{"char_end":41701,"char_start":40943,"text":"(a)\nin the case of the Department of Defense, the Secretary of Defense has, after consideration of the authority provided under subtitle G of title VIII of the Homeland Security Act of 2002, determined that the exercise of authority under this order is necessary for the timely and effective conduct of United States military or intelligence activities; and\n(b)\nin the case of any other executive department or agency that has authority under this order, (i) the Secretary of Homeland Security has advised whether the use of the authority provided under subtitle G of title VIII of the Homeland Security Act of 2002 would be appropriate, and (ii) the Director of the Office and Management and Budget has approved the exercise of authority under this order.\"."},{"char_end":49577,"char_start":49526,"text":"This order shall become effective on March 1, 2003."}],"exceptions_text":[],"filing_date":null,"id":"ACT:EO:12830>EO:13286","names_target":true,"notes":"Machine lead only; no legal ending asserted. Effective wording is ambiguous, section-specific, or has no determinable date.","provision_label":"Sec. 28.","reaches_target_via":"","savings_phrases":["Without prejudice to subsections (a) through (i) of this section, all responsibilities assigned to specific Federal officials pursuant to Executive Order 12656 that are substantially the same as any responsibility assigned to, or function transferred to, the Secretary of Homeland Security pursuant to the Homeland Security Act of 2002 (regardless of whether such responsibility or function is expressly required to be carried out through another official of the Department of Homeland Security or not pursuant to such Act), or intended or required to be carried out by an agency or an agency component transferred to the Department of Homeland Security pursuant to such Act, are hereby reassigned to the Secretary of Homeland Security.","Executive Order 11239 of July 31, 1965 (\"Enforcement of the Convention for Safety of Life at Sea, 1960\"), as amended, is further amended, without prejudice to section 1–106 of Executive Order 12234 of September 3, 1980 (\"Enforcement of the Convention for the Safety of Life at Sea\"), by:","Savings Provision."],"scope":"partial","signing_date":"2003-02-28","target_id":"EO:12830","verb":"amend"}
  Exact retained record text (unshared):
Executive Order 12830 of January 9, 1993 ("Establishing the Military Outstanding Volunteer Service Medal"), is amended by striking "the Secretary of Transportation" wherever it appears and inserting "the Secretary of Homeland Security" in lieu thereof.
- **ACT:EO:12830>EO:13286:effective#0**; Sd3145c7b44424f882132e4cb; {"actor_id":"EO:13286","char_end":2501,"char_start":2411,"id":"ACT:EO:12830>EO:13286:effective#0"}
- **ACT:EO:12830>EO:13286:effective#1**; Sd3145c7b44424f882132e4cb; {"actor_id":"EO:13286","char_end":41701,"char_start":40943,"id":"ACT:EO:12830>EO:13286:effective#1"}
- **ACT:EO:12830>EO:13286:effective#2**; Sd3145c7b44424f882132e4cb; {"actor_id":"EO:13286","char_end":49577,"char_start":49526,"id":"ACT:EO:12830>EO:13286:effective#2"}
- **ACT:EO:12830>EO:13286@4641641c9abfa6af**; S639260cb4c22eda960847445; {"actor_id":"EO:13286","char_end":21549,"char_start":21297,"confidence":"medium","effective_class":"unknown","effective_date":null,"effective_wording":[{"char_end":2699,"char_start":2609,"text":"Executive Order 13260 of March 19, 2002, is hereby revoked effective as of March 31, 2003."},{"char_end":41709,"char_start":41356,"text":"in the case of the Department of Defense, the Secretary of Defense has, after consideration of the authority provided under subtitle G of title VIII of the Homeland Security Act of 2002, determined that the exercise of authority under this order is necessary for the timely and effective conduct of United States military or intelligence activities; and"},{"char_end":50009,"char_start":49958,"text":"This order shall become effective on March 1, 2003."}],"exceptions_text":[],"filing_date":null,"id":"ACT:EO:12830>EO:13286@4641641c9abfa6af","names_target":true,"notes":"Machine lead only; no legal ending asserted. Effective wording is ambiguous, section-specific, or has no determinable date.","provision_label":"Sec. 28.","reaches_target_via":"","savings_phrases":["Without prejudice to subsections (a) through (i) of this section, all responsibilities assigned to specific Federal officials pursuant to Executive Order 12656 that are substantially the same as any responsibility assigned to, or function transferred to, the Secretary of Homeland Security pursuant to the Homeland Security Act of 2002 (regardless of whether such responsibility or function is expressly required to be carried out through another official of the Department of Homeland Security or not pursuant to such Act), or intended or required to be carried out by an agency or an agency component transferred to the Department of Homeland Security pursuant to such Act, are hereby reassigned to the Secretary of Homeland Security.","Executive Order 11239 of July 31, 1965 (\"Enforcement of the Convention for Safety of Life at Sea, 1960\"), as amended, is further amended, without prejudice to section 1–106 of Executive Order 12234 of September 3, 1980 (\"Enforcement of the Convention for the Safety of Life at Sea\"), by:","Savings Provision."],"scope":"partial","signing_date":"2003-02-28","target_id":"EO:12830","verb":"amend"}
- **ACT:EO:12830>EO:13286@6f82e43ad8746a33**; Sd3145c7b44424f882132e4cb; {"actor_id":"EO:13286","char_end":21256,"char_start":21004,"confidence":"medium","effective_class":"unknown","effective_date":null,"effective_wording":[{"char_end":2501,"char_start":2411,"text":"Executive Order 13260 of March 19, 2002, is hereby revoked effective as of March 31, 2003."},{"char_end":41701,"char_start":40943,"text":"(a)\nin the case of the Department of Defense, the Secretary of Defense has, after consideration of the authority provided under subtitle G of title VIII of the Homeland Security Act of 2002, determined that the exercise of authority under this order is necessary for the timely and effective conduct of United States military or intelligence activities; and\n(b)\nin the case of any other executive department or agency that has authority under this order, (i) the Secretary of Homeland Security has advised whether the use of the authority provided under subtitle G of title VIII of the Homeland Security Act of 2002 would be appropriate, and (ii) the Director of the Office and Management and Budget has approved the exercise of authority under this order.\"."},{"char_end":49577,"char_start":49526,"text":"This order shall become effective on March 1, 2003."}],"exceptions_text":[],"filing_date":null,"id":"ACT:EO:12830>EO:13286@6f82e43ad8746a33","names_target":true,"notes":"Machine lead only; no legal ending asserted. Effective wording is ambiguous, section-specific, or has no determinable date.","provision_label":"Sec. 28.","reaches_target_via":"","savings_phrases":["Without prejudice to subsections (a) through (i) of this section, all responsibilities assigned to specific Federal officials pursuant to Executive Order 12656 that are substantially the same as any responsibility assigned to, or function transferred to, the Secretary of Homeland Security pursuant to the Homeland Security Act of 2002 (regardless of whether such responsibility or function is expressly required to be carried out through another official of the Department of Homeland Security or not pursuant to such Act), or intended or required to be carried out by an agency or an agency component transferred to the Department of Homeland Security pursuant to such Act, are hereby reassigned to the Secretary of Homeland Security.","Executive Order 11239 of July 31, 1965 (\"Enforcement of the Convention for Safety of Life at Sea, 1960\"), as amended, is further amended, without prejudice to section 1–106 of Executive Order 12234 of September 3, 1980 (\"Enforcement of the Convention for the Safety of Life at Sea\"), by:","Savings Provision."],"scope":"partial","signing_date":"2003-02-28","target_id":"EO:12830","verb":"amend"}
- **CLAUSES:EO:12830#sec1**; Sdedf324fd1688262034dc811; {"char_end":1986,"char_start":1006,"id":"CLAUSES:EO:12830#sec1","kind":"section","label":"Section 1.","pdf_page":13,"scope_id":"EO:12830#sec1"}
  Text: [Tf97c5d91a174aceeb9030e68](#tf97c5d91a174aceeb9030e68); absolute characters 1006–1986
- **CLAUSES:EO:12830#sec3**; Sdedf324fd1688262034dc811; {"char_end":2296,"char_start":1987,"id":"CLAUSES:EO:12830#sec3","kind":"section","label":"Sec. 3.","pdf_page":13,"scope_id":"EO:12830#sec3"}
  Text: [Tf97c5d91a174aceeb9030e68](#tf97c5d91a174aceeb9030e68); absolute characters 1987–2296
- **CLAUSES:EO:12830#sec4**; Sdedf324fd1688262034dc811; {"char_end":2653,"char_start":2297,"id":"CLAUSES:EO:12830#sec4","kind":"section","label":"Sec. 4.","pdf_page":13,"scope_id":"EO:12830#sec4"}
  Text: [Tf97c5d91a174aceeb9030e68](#tf97c5d91a174aceeb9030e68); absolute characters 2297–2653
- **ORIGINAL:EO:12830**; Sdedf324fd1688262034dc811; {"acceptable_as_original":true,"actor_id":"EO:12830","char_end":22312,"char_start":0,"grade":"original_representation_unverified","id":"ORIGINAL:EO:12830","location_confidence":"high","requires_page_check":false,"role":"original","signing_date":"1993-01-09"}
  Text: [Tf97c5d91a174aceeb9030e68](#tf97c5d91a174aceeb9030e68); absolute characters 0–22312

### Complete operative inventory

- EO:12830#sec1 → CLAUSES:EO:12830#sec1; characters 1006–1986
- EO:12830#sec3 → CLAUSES:EO:12830#sec3; characters 1987–2296
- EO:12830#sec4 → CLAUSES:EO:12830#sec4; characters 2297–2653

### own_terms

[]

### actor_contexts

[{"actor_id":"EO:13286","overflow":"actor-texts/EO_13286.json","text_sha256":"57b106e01d54e1bcf61065a73a3591003b50eef2d8d0f65b0b54f98ea436e6df"}]

### actor_provisions

["ACT:EO:12830>EO:13286","ACT:EO:12830>EO:13286@6f82e43ad8746a33","ACT:EO:12830>EO:13286@4641641c9abfa6af"]

### chain

{"confidence":"medium","events":[{"actor_id":"EO:13286","char_end":21256,"char_start":21004,"confidence":"medium","how_named":"direct","id":"CHAIN:EO:12830#1","notes":"Change wording lead; chronology does not decide legal effect.","provision_text":"Executive Order 12830 of January 9, 1993 (\"Establishing the Military Outstanding Volunteer Service Medal\"), is amended by striking \"the Secretary of Transportation\" wherever it appears and inserting \"the Secretary of Homeland Security\" in lieu thereof.","sections_touched":["partial"],"signing_date":"2003-02-28","source":{"acceptable_as_original":false,"archival_id":"app:node/217113","filing_date":null,"grade":"mirror_transcription","instrument_id":"EO:13286","location_confidence":"medium","location_verified":false,"page_or_item":"Executive Order 13286—Amendment of Executive Orders, and Other Actions, in Connection With the Transfer of Certain Functions to the Secretary of Homeland Security; February 28, 2003; APP node 217113; common-crawl capture 2025-10-06T18:03:47Z","requires_page_check":true,"sha256":"c1a2aff53be0c95cb97e0871e389a3b185ae165f6dd9a539722ed1c45f135c34","signing_date":"2003-02-28","text_path":"jobs/app-executive-orders/output/texts/executive-order-13286-amendment-executive-orders-and-other-actions-connection-with-the.txt","text_sha256":"d24268c163cd19e82bda1102e745709657d237c65d627f55716beebc42ba94f0","url":"https://www.presidency.ucsb.edu/documents/executive-order-13286-amendment-executive-orders-and-other-actions-connection-with-the"},"verb":"amend"}],"generic_refs_excluded":221,"id":"CHAIN:EO:12830","notes":"Named, located change provisions only; missing provisions and unheld texts remain dossier gaps. Undated events sort last.","target_id":"EO:12830"}

### current_law_leads

[{"basis_code":"printed_eo_text","checked_through":"2026-10-09","currency_code":"usc_release_point","edition":"U.S. Code release point 119-121","evidence_gap":"No uniquely located attributed legal-text slice is held for this current-law pointer; serialized JSON/JSONL, snippets and absent cache artifacts are not legal-text evidence.","fragment_kind":"current_predicate_candidates","input_origin":"jobs/current-law/output/FRAGMENTS.jsonl","instrument_id":"EO:12830","legal_basis_candidate":"U.S. Code prints the order's text as a note, with no ending statement (10 U.S.C. subtitle A, pt. II, ch. 57 note)","machine_lead":true,"mention_id":"usc:8924bd50faad","snippet":"Ex. Ord. No. 12830. Military Outstanding Volunteer Service Medal | Ex. Ord. No. 12830, Jan. 9, 1993, 58 F.R. 4061, as amended by Ex. Ord. No. 13286, § 28, Feb. 28, 2003, 68 F.R. 10625, provided:","source":{"page_or_item":"10 U.S.C. subtitle A, pt. II, ch. 57 note; note 'Ex. Ord. No. 12830. Military Outstanding Volunteer Service Medal' [USLM note id ida8989a5b-3a6f-11f1-a58a-d8db54b14ab5]; usc10.xml (sha256 f6b1a4f0897cd19431abb8af52cf3aafb02cf6e1870f0f6b5d1992c37fe128b6) in xml_uscAll@119-121.zip","sha256":"c6122974e951003437ece5a998aa7c0b2cdc0f5703dfc78d6135e1fc9e729142","url":"https://uscode.house.gov/download/releasepoints/us/pl/119/121/xml_uscAll@119-121.zip"},"system":"usc","text_path":"USC_EO_NOTES.jsonl#note_id=ida8989a5b-3a6f-11f1-a58a-d8db54b14ab5","where":"USC 10 U.S.C. subtitle A, pt. II, ch. 57 note"},{"custody_records_in":["current-law"],"evidence_gap":"Current-law lead lacks an original-source sha256.","meta":{"basis_code":"printed_eo_text","caution":"a mention in current law is a LEAD, not by itself a legal basis; read the provision to see whether it keeps the order operating","currency_code":"usc_release_point","edition":"U.S. Code release point 119-121","from":"current-law@jobs/current-law/output","from_job":"current-law","mention_id":"usc:8924bd50faad","snippet":"Ex. Ord. No. 12830. Military Outstanding Volunteer Service Medal | Ex. Ord. No. 12830, Jan. 9, 1993, 58 F.R. 4061, as amended by Ex. Ord. No. 13286, § 28, Feb. 28, 2003, 68 F.R. 10625, provided:","snippet_truncated":false,"system":"usc","text_path":"USC_EO_NOTES.jsonl#note_id=ida8989a5b-3a6f-11f1-a58a-d8db54b14ab5","where":"USC 10 U.S.C. subtitle A, pt. II, ch. 57 note"},"proposal":{"checked_through":"2026-10-09","legal_basis":"U.S. Code prints the order's text as a note, with no ending statement (10 U.S.C. subtitle A, pt. II, ch. 57 note)","source":{"page_or_item":"10 U.S.C. subtitle A, pt. II, ch. 57 note; note 'Ex. Ord. No. 12830. Military Outstanding Volunteer Service Medal' [USLM note id ida8989a5b-3a6f-11f1-a58a-d8db54b14ab5]; usc10.xml (sha256 f6b1a4f0897cd19431abb8af52cf3aafb02cf6e1870f0f6b5d1992c37fe128b6) in xml_uscAll@119-121.zip","sha256":"c6122974e951003437ece5a998aa7c0b2cdc0f5703dfc78d6135e1fc9e729142","url":"https://uscode.house.gov/download/releasepoints/us/pl/119/121/xml_uscAll@119-121.zip"}}}]

### machine_searches

[{"complete":true,"entry":{"checked_on":"2026-10-17","query_or_scope":"every citation of this order by number (forms 'Executive Order', 'Ex. Ord.', 'E.O.') in the text and notes of the titles read; edition current through 2026-10-09 (laws enacted after that date and on or before 2026-10-14 are not reflected)","repository":"U.S. Code, Office of the Law Revision Counsel release point 119-121 (USLM XML, 58 title files), statute text and editorial notes","searched_by":"jobs/current-law (machine search)"},"machine_hits_for_this_order":2,"scope_note":"","search_id":"current-law:usc"},{"complete":true,"entry":{"checked_on":"2026-10-17","query_or_scope":"full-text search for 'Executive Order', 'Executive Orders', 'E.O.', 'Ex. Ord.', 'Exec. Order' and regulation text, authority and source citations naming this order","repository":"eCFR point-in-time search as of 2026-10-14 and GovInfo CFR bulk XML (49 titles read)","searched_by":"jobs/current-law (machine search)"},"machine_hits_for_this_order":2,"scope_note":"","search_id":"current-law:ecfr"},{"complete":true,"entry":{"checked_on":"2026-10-19","query_or_scope":"disposition notes of 6938 catalog records (1937 onward) naming this order as amended, revoked, superseded or otherwise affected, plus operative sentences in 17521 saved order texts","repository":"Federal Register executive-order catalog (federalregister.gov API v1, include_pre_1994_docs=true): Office of the Federal Register disposition notes","searched_by":"jobs/later-events (machine search)"},"machine_hits_for_this_order":1,"scope_note":"","search_id":"later-events:ofr_catalog"}]

### draft_gate_errors

["clause_0_state","clause_1_state","clause_2_state","clause_3_state","yes_without_continuing_clause","savings_residuals_evidence","bounded_later_search","unresolved_material_gaps","research_rationale"]

### conflicts

[]

### draft_material_gaps

["DRAFT: state_at_cutoff not decided for 4 clause(s); clause inventory completeness not confirmed","DRAFT: current legal basis not established","DRAFT: savings and residual effects not closed","DRAFT: later_source_search not recorded (machine searches are proposals only; paste them after judging them adequate and resolving every CONFLICT line)"]

### missing

["Current legal predicate and coverage through 2026-10-14 require judgment; a citation or 1989 snapshot cannot prove continuation.","Current-law lead lacks an original-source sha256.","Large actor context must be read at actor-texts/EO_13286.json before deciding scope/savings.","No uniquely located attributed legal-text slice is held for this current-law pointer; serialized JSON/JSONL, snippets and absent cache artifacts are not legal-text evidence."]

### status_history

{"event_count":2,"fingerprint":"9cdbadbc5cdc487a05a6cf4718db529f3077d549b64a9d073810f1d4352c00e4","flags":[],"history_path":"jobs/status-history/output/histories/EO_12830.json","history_sha256":"c88d1baf04b6991024df44ee06495a2b48ff4b2f33722889efd27002c5f90062","input_origin":"jobs/status-history/output/FRAGMENTS.jsonl","legal_cutoff":"2026-10-14","machine_lead":true,"notice":"Editorial leads, not an original, legal conclusion, provisional-status assignment or human certification.","observation_count":1}

### notice

"MACHINE LEADS ONLY. No segmentation, date, source grade, family or chain is a legal conclusion."

### Additional dossier metadata

{"lifecycle_obligations":[{"clause_sha256":"42c3ba9594a8d15101b7f7c2681a138a515b97a72ed0dcb6d27ac2b8f55c7f34","established_ending":null,"human_certified":false,"instrument_id":"EO:12830","later_actor_evidence_ids":[],"own_term_evidence_ids":[],"questions":["Determine the first cessation or current predicate for this scope; check independent commands and surviving effects."],"schema":"eo-lifecycle-obligation/v1","scope_id":"EO:12830#sec1","state":"requires_clause_specific_research","wording_features":[]},{"clause_sha256":"a99b0c245d0e7dcea860a74fad78c578654964792adc74e80fbe8d182399ad6c","established_ending":null,"human_certified":false,"instrument_id":"EO:12830","later_actor_evidence_ids":[],"own_term_evidence_ids":[],"questions":["Determine the first cessation or current predicate for this scope; check independent commands and surviving effects.","Distinguish the due date, demonstrated performance, and continuing duties. Establish occurrence from evidence and explain its effect on this clause."],"schema":"eo-lifecycle-obligation/v1","scope_id":"EO:12830#sec3","state":"requires_clause_specific_research","wording_features":["actual_performance_lead"]},{"clause_sha256":"c18d6b650cb163cc10404bf2a6364973e3225a34a5960c07d4c3fe30e008445d","established_ending":null,"human_certified":false,"instrument_id":"EO:12830","later_actor_evidence_ids":[],"own_term_evidence_ids":[],"questions":["Determine the first cessation or current predicate for this scope; check independent commands and surviving effects."],"schema":"eo-lifecycle-obligation/v1","scope_id":"EO:12830#sec4","state":"requires_clause_specific_research","wording_features":[]}]}

### Preflight

{"custody_validation":"required_from_actual_claim_checker","decisions_still_required":["complete original/inventory","earlier ending","partial scope and effective date","independent commands","savings/residuals","contrary evidence and cutoff predicate"],"evidence_preflight":"blocked_or_research","held_text_receipts":{"jobs/fr-originals/data/full_run/texts/EO_12830.txt":{"characters":22312,"raw_custody":"requires_actual_claim_checker","source_sha256":"c96e10693967f7cf75325225add4bb42925b2ab9d6ebdfee397dad865fe39348","text_sha256":"d6b7d63e64087aa7cde884e5e6a83fa124c0e771aaaaf71f920985ce63be944f"}},"instrument_id":"EO:12830","lifecycle_obligations":[{"clause_sha256":"42c3ba9594a8d15101b7f7c2681a138a515b97a72ed0dcb6d27ac2b8f55c7f34","established_ending":null,"human_certified":false,"instrument_id":"EO:12830","later_actor_evidence_ids":[],"own_term_evidence_ids":[],"questions":["Determine the first cessation or current predicate for this scope; check independent commands and surviving effects."],"schema":"eo-lifecycle-obligation/v1","scope_id":"EO:12830#sec1","state":"requires_clause_specific_research","wording_features":[]},{"clause_sha256":"a99b0c245d0e7dcea860a74fad78c578654964792adc74e80fbe8d182399ad6c","established_ending":null,"human_certified":false,"instrument_id":"EO:12830","later_actor_evidence_ids":[],"own_term_evidence_ids":[],"questions":["Determine the first cessation or current predicate for this scope; check independent commands and surviving effects.","Distinguish the due date, demonstrated performance, and continuing duties. Establish occurrence from evidence and explain its effect on this clause."],"schema":"eo-lifecycle-obligation/v1","scope_id":"EO:12830#sec3","state":"requires_clause_specific_research","wording_features":["actual_performance_lead"]},{"clause_sha256":"c18d6b650cb163cc10404bf2a6364973e3225a34a5960c07d4c3fe30e008445d","established_ending":null,"human_certified":false,"instrument_id":"EO:12830","later_actor_evidence_ids":[],"own_term_evidence_ids":[],"questions":["Determine the first cessation or current predicate for this scope; check independent commands and surviving effects."],"schema":"eo-lifecycle-obligation/v1","scope_id":"EO:12830#sec4","state":"requires_clause_specific_research","wording_features":[]}],"mechanical_tasks":[{"availability":"held_not_loaded","instrument_id":"EO:12830","kind":"load_actor_overflow","reason":"Read full overflow before scope/savings decision","shared_key":"EO:13286","task_id":"TASK:84afaf7b7ab986f33b60241f"},{"availability":"citation_or_pointer_only","instrument_id":"EO:12830","kind":"operative_current_law","reason":"No uniquely located attributed legal-text slice is held for this current-law pointer; serialized JSON/JSONL, snippets and absent cache artifacts are not legal-text evidence.","shared_key":"{\"basis_code\":\"printed_eo_text\",\"source\":{\"page_or_item\":\"10 U.S.C. subtitle A, pt. II, ch. 57 note; note 'Ex. Ord. No. 12830. Military Outstanding Volunteer Service Medal' [USLM note id ida8989a5b-3a6f-11f1-a58a-d8db54b14ab5]; usc10.xml (sha256 f6b1a4f0897cd19431abb8af52cf3aafb02cf6e1870f0f6b5d1992c37fe128b6) in xml_uscAll@119-121.zip\",\"sha256\":\"c6122974e951003437ece5a998aa7c0b2cdc0f5703dfc78d6135e1fc9e729142\",\"url\":\"https://uscode.house.gov/download/releasepoints/us/pl/119/121/xml_uscAll@119-121.zip\"},\"text_path\":\"USC_EO_NOTES.jsonl#note_id=ida8989a5b-3a6f-11f1-a58a-d8db54b14ab5\"}","task_id":"TASK:bc3506ed72a0710f2f2557b4"},{"availability":"citation_or_pointer_only","instrument_id":"EO:12830","kind":"operative_current_law","reason":"Current-law lead lacks an original-source sha256.","shared_key":"{}","task_id":"TASK:1b16444cae50780611b48e39"},{"availability":"absent_or_unreadable","instrument_id":"EO:12830","kind":"held_text_unavailable","reason":"[Errno 2] No such file or directory: '/workspace/scratch/a5be930883fa/eo-readiness/jobs/app-executive-orders/output/texts/executive-order-13286-amendment-executive-orders-and-other-actions-connection-with-the.txt'","shared_key":"jobs/app-executive-orders/output/texts/executive-order-13286-amendment-executive-orders-and-other-actions-connection-with-the.txt","task_id":"TASK:2f0d8690fd95d97958c0569d"},{"availability":"absent_or_unreadable","instrument_id":"EO:12830","kind":"held_text_unavailable","reason":"[Errno 2] No such file or directory: '/workspace/scratch/a5be930883fa/eo-readiness/jobs/clause-drafts/output/texts/cd-opus_zip-13286-1cc5a2464d.txt'","shared_key":"jobs/clause-drafts/output/texts/cd-opus_zip-13286-1cc5a2464d.txt","task_id":"TASK:148b093971bcc21847f4a446"}],"notice":"No known gap is not a legal-readiness finding. Review may expose new facts."}

### Prior research and remaining delta

{"conflicting_versions":[],"current_rulings":[{"expected_sha256":null,"path":"research/readiness/owner_rulings/2026-10-29-tiered-delegation.md","sha256":"20a27c48ee4b86711151ed632bcbab14028197e4a3430ad1431c86c004629cd6","state":"unqualified"}],"full_context":"PACKET.json#/prior_research/orders/EO:12830","notice":"Prior producer/reviewer assertions, not new findings or automatic approval. Reuse only after checking the exact version, source, proposition and scope. Rejected versions and contradictory assertions remain visible; whole-case review is still required.","remaining_delta":{"current_reported_gaps":[],"dossier_fingerprint":"014b9e3f3711e5013a17397f2f6e1c22951c8fab921b9e5d30ab42aa0011122c","existing_lifecycle_questions":[{"clause_sha256":"42c3ba9594a8d15101b7f7c2681a138a515b97a72ed0dcb6d27ac2b8f55c7f34","dossier_pointer":"/lifecycle_obligations/0","later_actor_evidence_ids":[],"own_term_evidence_ids":[],"questions":["Determine the first cessation or current predicate for this scope; check independent commands and surviving effects."],"scope_id":"EO:12830#sec1","state":"requires_clause_specific_research"},{"clause_sha256":"a99b0c245d0e7dcea860a74fad78c578654964792adc74e80fbe8d182399ad6c","dossier_pointer":"/lifecycle_obligations/1","later_actor_evidence_ids":[],"own_term_evidence_ids":[],"questions":["Determine the first cessation or current predicate for this scope; check independent commands and surviving effects.","Distinguish the due date, demonstrated performance, and continuing duties. Establish occurrence from evidence and explain its effect on this clause."],"scope_id":"EO:12830#sec3","state":"requires_clause_specific_research"},{"clause_sha256":"c18d6b650cb163cc10404bf2a6364973e3225a34a5960c07d4c3fe30e008445d","dossier_pointer":"/lifecycle_obligations/2","later_actor_evidence_ids":[],"own_term_evidence_ids":[],"questions":["Determine the first cessation or current predicate for this scope; check independent commands and surviving effects."],"scope_id":"EO:12830#sec4","state":"requires_clause_specific_research"}],"existing_lifecycle_questions_notice":"Current dossier research prompts, not new gap findings or overrides of prior claim/review conclusions.","new_legal_gaps_invented":[],"prior_differences_require_scope_source_proposition_review":true},"selection_and_checkpoint_records":[],"state":"no_prior_research_located","status_holds":[],"status_research":[],"unattached_status_reviews":[],"unfinished_work":[],"versions":[]}

## EO:12985

Fingerprint: 0272069e0948fd683e619b5ab00ce2f6850a99f901ae50ab7d8ce94fc7732c46; provisional status: yes
Ownership/routing: {"route":"new_producer_proposal"}
Required member checks: earlier ending; scope; independent commands; savings.

### Evidence index

- **ACT:EO:12985>EO:13286**; Sd3145c7b44424f882132e4cb; {"actor_id":"EO:13286","char_end":17893,"char_start":17665,"confidence":"medium","effective_class":"unknown","effective_date":null,"effective_wording":[{"char_end":2501,"char_start":2411,"text":"Executive Order 13260 of March 19, 2002, is hereby revoked effective as of March 31, 2003."},{"char_end":41701,"char_start":40943,"text":"(a)\nin the case of the Department of Defense, the Secretary of Defense has, after consideration of the authority provided under subtitle G of title VIII of the Homeland Security Act of 2002, determined that the exercise of authority under this order is necessary for the timely and effective conduct of United States military or intelligence activities; and\n(b)\nin the case of any other executive department or agency that has authority under this order, (i) the Secretary of Homeland Security has advised whether the use of the authority provided under subtitle G of title VIII of the Homeland Security Act of 2002 would be appropriate, and (ii) the Director of the Office and Management and Budget has approved the exercise of authority under this order.\"."},{"char_end":49577,"char_start":49526,"text":"This order shall become effective on March 1, 2003."}],"exceptions_text":[],"filing_date":null,"id":"ACT:EO:12985>EO:13286","names_target":true,"notes":"Machine lead only; no legal ending asserted. Effective wording is ambiguous, section-specific, or has no determinable date.","provision_label":"Sec. 20.","reaches_target_via":"","savings_phrases":["Without prejudice to subsections (a) through (i) of this section, all responsibilities assigned to specific Federal officials pursuant to Executive Order 12656 that are substantially the same as any responsibility assigned to, or function transferred to, the Secretary of Homeland Security pursuant to the Homeland Security Act of 2002 (regardless of whether such responsibility or function is expressly required to be carried out through another official of the Department of Homeland Security or not pursuant to such Act), or intended or required to be carried out by an agency or an agency component transferred to the Department of Homeland Security pursuant to such Act, are hereby reassigned to the Secretary of Homeland Security.","Executive Order 11239 of July 31, 1965 (\"Enforcement of the Convention for Safety of Life at Sea, 1960\"), as amended, is further amended, without prejudice to section 1–106 of Executive Order 12234 of September 3, 1980 (\"Enforcement of the Convention for the Safety of Life at Sea\"), by:","Savings Provision."],"scope":"partial","signing_date":"2003-02-28","target_id":"EO:12985","verb":"amend"}
  Exact retained record text (unshared):
Executive Order 12985 of January 11, 1996 ("Establishing the Armed Forces Service Medal"), is amended by striking "the Secretary of Transportation" in section 2 and inserting "the Secretary of Homeland Security" in lieu thereof.
- **ACT:EO:12985>EO:13286:effective#0**; Sd3145c7b44424f882132e4cb; {"actor_id":"EO:13286","char_end":2501,"char_start":2411,"id":"ACT:EO:12985>EO:13286:effective#0"}
- **ACT:EO:12985>EO:13286:effective#1**; Sd3145c7b44424f882132e4cb; {"actor_id":"EO:13286","char_end":41701,"char_start":40943,"id":"ACT:EO:12985>EO:13286:effective#1"}
- **ACT:EO:12985>EO:13286:effective#2**; Sd3145c7b44424f882132e4cb; {"actor_id":"EO:13286","char_end":49577,"char_start":49526,"id":"ACT:EO:12985>EO:13286:effective#2"}
- **ACT:EO:12985>EO:13286@407232d6eb246b18**; Sd3145c7b44424f882132e4cb; {"actor_id":"EO:13286","char_end":17893,"char_start":17665,"confidence":"medium","effective_class":"unknown","effective_date":null,"effective_wording":[{"char_end":2501,"char_start":2411,"text":"Executive Order 13260 of March 19, 2002, is hereby revoked effective as of March 31, 2003."},{"char_end":41701,"char_start":40943,"text":"(a)\nin the case of the Department of Defense, the Secretary of Defense has, after consideration of the authority provided under subtitle G of title VIII of the Homeland Security Act of 2002, determined that the exercise of authority under this order is necessary for the timely and effective conduct of United States military or intelligence activities; and\n(b)\nin the case of any other executive department or agency that has authority under this order, (i) the Secretary of Homeland Security has advised whether the use of the authority provided under subtitle G of title VIII of the Homeland Security Act of 2002 would be appropriate, and (ii) the Director of the Office and Management and Budget has approved the exercise of authority under this order.\"."},{"char_end":49577,"char_start":49526,"text":"This order shall become effective on March 1, 2003."}],"exceptions_text":[],"filing_date":null,"id":"ACT:EO:12985>EO:13286@407232d6eb246b18","names_target":true,"notes":"Machine lead only; no legal ending asserted. Effective wording is ambiguous, section-specific, or has no determinable date.","provision_label":"Sec. 20.","reaches_target_via":"","savings_phrases":["Without prejudice to subsections (a) through (i) of this section, all responsibilities assigned to specific Federal officials pursuant to Executive Order 12656 that are substantially the same as any responsibility assigned to, or function transferred to, the Secretary of Homeland Security pursuant to the Homeland Security Act of 2002 (regardless of whether such responsibility or function is expressly required to be carried out through another official of the Department of Homeland Security or not pursuant to such Act), or intended or required to be carried out by an agency or an agency component transferred to the Department of Homeland Security pursuant to such Act, are hereby reassigned to the Secretary of Homeland Security.","Executive Order 11239 of July 31, 1965 (\"Enforcement of the Convention for Safety of Life at Sea, 1960\"), as amended, is further amended, without prejudice to section 1–106 of Executive Order 12234 of September 3, 1980 (\"Enforcement of the Convention for the Safety of Life at Sea\"), by:","Savings Provision."],"scope":"partial","signing_date":"2003-02-28","target_id":"EO:12985","verb":"amend"}
- **ACT:EO:12985>EO:13286@71550c617a8ab05c**; S639260cb4c22eda960847445; {"actor_id":"EO:13286","char_end":18159,"char_start":17931,"confidence":"medium","effective_class":"unknown","effective_date":null,"effective_wording":[{"char_end":2699,"char_start":2609,"text":"Executive Order 13260 of March 19, 2002, is hereby revoked effective as of March 31, 2003."},{"char_end":41709,"char_start":41356,"text":"in the case of the Department of Defense, the Secretary of Defense has, after consideration of the authority provided under subtitle G of title VIII of the Homeland Security Act of 2002, determined that the exercise of authority under this order is necessary for the timely and effective conduct of United States military or intelligence activities; and"},{"char_end":50009,"char_start":49958,"text":"This order shall become effective on March 1, 2003."}],"exceptions_text":[],"filing_date":null,"id":"ACT:EO:12985>EO:13286@71550c617a8ab05c","names_target":true,"notes":"Machine lead only; no legal ending asserted. Effective wording is ambiguous, section-specific, or has no determinable date.","provision_label":"Sec. 20.","reaches_target_via":"","savings_phrases":["Without prejudice to subsections (a) through (i) of this section, all responsibilities assigned to specific Federal officials pursuant to Executive Order 12656 that are substantially the same as any responsibility assigned to, or function transferred to, the Secretary of Homeland Security pursuant to the Homeland Security Act of 2002 (regardless of whether such responsibility or function is expressly required to be carried out through another official of the Department of Homeland Security or not pursuant to such Act), or intended or required to be carried out by an agency or an agency component transferred to the Department of Homeland Security pursuant to such Act, are hereby reassigned to the Secretary of Homeland Security.","Executive Order 11239 of July 31, 1965 (\"Enforcement of the Convention for Safety of Life at Sea, 1960\"), as amended, is further amended, without prejudice to section 1–106 of Executive Order 12234 of September 3, 1980 (\"Enforcement of the Convention for the Safety of Life at Sea\"), by:","Savings Provision."],"scope":"partial","signing_date":"2003-02-28","target_id":"EO:12985","verb":"amend"}
- **ACTOR_TEXT:EO:13154**; S757db9e803bf5ea90af93e43; {"actor_id":"EO:13154","char_end":2832,"char_start":0,"id":"ACTOR_TEXT:EO:13154","role":"actor_context"}
  Exact retained record text (unshared):
Instrument: EO:13154
Source: https://www.govinfo.gov/content/pkg/FR-2000-05-05/pdf/00-11532.pdf
SHA-256 of the downloaded file: a5170c1411a028a314a45bf54308229e46a796661a70174d2fa389671f068f5d
Location: 65 FR 26479, PDF pages 1-1 (confidence high)
Machine-extracted text layer of the official PDF (OCR for 1936-1994 scans). May contain recognition errors and parts of neighbouring documents on the same pages. Not an authenticated transcription: check the PDF pages.

=== PDF page 1 of 1 ===
Presidential Documents
26479Federal Register / Vol. 65, No. 88 / Friday, May 5, 2000 / Presidential Documents
Executive Order 13154 of May 3, 2000
Establishing the Kosovo Campaign Medal
By the authority vested in me as President by the Constitution and the
laws of the United States of America, including my authority as Commander
in Chief of the Armed Forces of the United States, it is hereby ordered
as follows:
Section 1. Kosovo Campaign Medal. There is hereby established the Kosovo
Campaign Medal with suitable appurtenances. Except as limited in section
2 of this order, and under uniform regulations to be prescribed by the
Secretaries of the Military Departments and approved by the Secretary of
Defense, or under regulations to be prescribed by the Secretary of Transpor-
tation with respect to the Coast Guard when it is not operating as a service
in the Navy, the Kosovo Campaign Medal shall be awarded to members
of the Armed Forces of the United States who serve or have served in
Kosovo or contiguous waters or airspace, as defined by such regulations,
after March 24, 1999, and before a terminal date to be prescribed by the
Secretary of Defense.
Sec. 2. Relationship to Other Awards. Notwithstanding section 3 of Executive
Order 10977 of December 4, 1961, establishing the Armed Forces Expedi-
tionary Medal and section 3 of Executive Order 12985 of January 11, 1996,
establishing the Armed Forces Service Medal, any member who qualified
for those medals by reasons of service in Kosovo between March 24, 1999,
and May 1, 2000, shall remain qualified for those medals. Upon application,
any such member may be awarded the Kosovo Campaign Medal in lieu
of the Armed Forces Expeditionary Medal or the Armed Forces Service
Medal, but no person may be awarded more than one of these three medals
by reason of service in Kosovo, and no person shall be entitled to more
than one award of the Kosovo Campaign Medal.
Sec. 3. Posthumous Award. The Kosovo Campaign Medal may be awarded
posthumously to any person covered by and under regulations prescribed
in accordance with the first section of this order.
œ–
THE WHITE HOUSE,
May 3, 2000.
[FR Doc. 00–11532
Filed 5–4–00; 11:45 am]
Billing code 3195–01–P
VerDate 27<APR>2000 14:06 May 04, 2000 Jkt 190000 PO 00000 Frm 00001 Fmt 4790 Sfmt 4790 E:\FR\FM\05MYE1.SGM pfrm03 PsN: 05MYE1
- **ACTOR_TEXT:EO:13289**; S213e25bdd3a31c76a3d7df90; {"actor_id":"EO:13289","char_end":4606,"char_start":0,"id":"ACTOR_TEXT:EO:13289","role":"actor_context"}
  Exact retained record text (unshared):
Instrument: EO:13289
Source: https://www.govinfo.gov/content/pkg/FR-2003-03-14/pdf/03-6445.pdf
SHA-256 of the downloaded file: 6670f509054733a97662c450aa98b59747e76b5653f4da0849f7260aa953419e
Location: 68 FR 12567, PDF pages 1-2 (confidence high)
Machine-extracted text layer of the official PDF (OCR for 1936-1994 scans). May contain recognition errors and parts of neighbouring documents on the same pages. Not an authenticated transcription: check the PDF pages.

=== PDF page 1 of 2 ===
Presidential Documents
12567
Federal Register 
Vol. 68, No. 50
Friday, March 14, 2003
Title 3— 
The President
Executive Order 13289 of March 12, 2003
Establishing the Global War on Terrorism Medals 
By the authority vested in me as President by the Constitution and the 
laws of the United States of America, including my authority as Commander 
in Chief of the Armed Forces of the United States, it is hereby ordered 
as follows: 
Section 1. Global War on Terrorism Expeditionary Medal. There is hereby 
established the Global War on Terrorism Expeditionary Medal with suitable 
appurtenances. Except as limited in section 3 of this order, and under 
uniform regulations to be prescribed by the Secretaries of the military depart-
ments and approved by the Secretary of Defense, or under regulations to 
be prescribed by the Secretary of Homeland Security with respect to the 
Coast Guard when it is not operating as a service in the Navy, the Global 
War on Terrorism Expeditionary Medal shall be awarded to members of 
the Armed Forces of the United States who serve or have served in military 
expeditions to combat terrorism, as defined by such regulations, on or after 
September 11, 2001, and before a terminal date to be prescribed by the 
Secretary of Defense. 
Sec. 2. Global War on Terrorism Service Medal. There is hereby established 
the Global War on Terrorism Service Medal with suitable appurtenances. 
Except as limited in section 3 of this order, and under uniform regulations 
to be prescribed by the Secretaries of the military departments and approved 
by the Secretary of Defense, or under regulations to be prescribed by the 
Secretary of Homeland Security with respect to the Coast Guard when it 
is not operating as a service in the Navy, the Global War on Terrorism 
Service Medal shall be awarded to members of the Armed Forces of the 
United States who serve or have served in military operations to combat 
terrorism, as defined by such regulations, on or after September 11, 2001, 
and before a terminal date to be prescribed by the Secretary of Defense. 
Sec. 3. Relationship to Other Awards. Notwithstanding section 3 of Executive 
Order 10977 of December 4, 1961, establishing the Armed Forces Expedi-
tionary Medal and section 3 of Executive Order 12985 of January 11, 1996, 
establishing the Armed Forces Service Medal, any member who qualified 
for those medals by reason of service in operations to combat terrorism 
between September 11, 2001, and a terminal date to be determined by 
the Secretary of Defense, shall remain qualified for those medals. Upon 
application, any such member may be awarded either the Global War on 
Terrorism Expeditionary Medal or the Global War on Terrorism Service 
Medal in lieu of the Armed Forces Expeditionary Medal or the Armed 
Forces Service Medal, but no person may be awarded more than one of 
these four medals by reason of service in the same approved Global War 
on Terrorism expedition or operation to combat terrorism, and no person 
shall be entitled to more than one award of the Global War on Terrorism 
Expeditionary Medal or the Global War on Terrorism Service Medal. 
Sec. 4. Posthumous Award. The Global War on Terrorism Expeditionary 
Medal and the Global War on Terrorism Service Medal may be awarded 
posthumously to any person covered by and under regulations prescribed 
in accordance with the first or second sections of this order.
VerDate Jan<31>2003 16:31 Mar 13, 2003 Jkt 200001 PO 00000 Frm 00003 Fmt 4705 Sfmt 4790 E:\FR\FM\14MRE0.SGM 14MRE0
=== PDF page 2 of 2 ===
12568 Federal Register / Vol. 68, No. 50 / Friday, March 14, 2003 / Presidential Documents 
Sec. 5. Nothing in this Executive Order shall be construed for any purpose 
as fixing, or authorizing the fixing of, the dates of initiation or termination 
of armed hostilities between the United States and terrorists of global reach.
W
THE WHITE HOUSE, 
March 12, 2003. 
[FR Doc. 03–6445
Filed 3–13–03; 12:27 pm] 
Billing code 3195–01–P 
VerDate Jan<31>2003 16:31 Mar 13, 2003 Jkt 200001 PO 00000 Frm 00004 Fmt 4705 Sfmt 4790 E:\FR\FM\14MRE0.SGM 14MRE0
- **CLAUSES:EO:12985#sec1**; Sfc03d9f9782df3f4e95d50a0; {"char_end":1404,"char_start":920,"id":"CLAUSES:EO:12985#sec1","kind":"section","label":"Section 1.","pdf_page":1,"scope_id":"EO:12985#sec1"}
  Text: [T6afd383918d43b1cc512e86f](#t6afd383918d43b1cc512e86f); absolute characters 920–1404
- **CLAUSES:EO:12985#sec1-b**; Sfc03d9f9782df3f4e95d50a0; {"char_end":1474,"char_start":1405,"id":"CLAUSES:EO:12985#sec1-b","kind":"subsection","label":"(b)","pdf_page":1,"scope_id":"EO:12985#sec1-b"}
  Text: [T6afd383918d43b1cc512e86f](#t6afd383918d43b1cc512e86f); absolute characters 1405–1474
- **CLAUSES:EO:12985#sec2**; Sfc03d9f9782df3f4e95d50a0; {"char_end":1992,"char_start":1475,"id":"CLAUSES:EO:12985#sec2","kind":"section","label":"Sec. 2.","pdf_page":1,"scope_id":"EO:12985#sec2"}
  Text: [T6afd383918d43b1cc512e86f](#t6afd383918d43b1cc512e86f); absolute characters 1475–1992
- **CLAUSES:EO:12985#sec3**; Sfc03d9f9782df3f4e95d50a0; {"char_end":2555,"char_start":1993,"id":"CLAUSES:EO:12985#sec3","kind":"section","label":"Sec. 3.","pdf_page":1,"scope_id":"EO:12985#sec3"}
  Text: [T6afd383918d43b1cc512e86f](#t6afd383918d43b1cc512e86f); absolute characters 1993–2555
- **CLAUSES:EO:12985#sec4**; Sfc03d9f9782df3f4e95d50a0; {"char_end":2797,"char_start":2556,"id":"CLAUSES:EO:12985#sec4","kind":"section","label":"Sec. 4.","pdf_page":1,"scope_id":"EO:12985#sec4"}
  Text: [T6afd383918d43b1cc512e86f](#t6afd383918d43b1cc512e86f); absolute characters 2556–2797
- **ORIGINAL:EO:12985**; Sfc03d9f9782df3f4e95d50a0; {"acceptable_as_original":true,"actor_id":"EO:12985","char_end":2895,"char_start":0,"grade":"original_representation_unverified","id":"ORIGINAL:EO:12985","location_confidence":"high","requires_page_check":false,"role":"original","signing_date":"1996-01-11"}
  Text: [T6afd383918d43b1cc512e86f](#t6afd383918d43b1cc512e86f); absolute characters 0–2895

### Complete operative inventory

- EO:12985#sec1 → CLAUSES:EO:12985#sec1; characters 920–1404
- EO:12985#sec1-b → CLAUSES:EO:12985#sec1-b; characters 1405–1474
- EO:12985#sec2 → CLAUSES:EO:12985#sec2; characters 1475–1992
- EO:12985#sec3 → CLAUSES:EO:12985#sec3; characters 1993–2555
- EO:12985#sec4 → CLAUSES:EO:12985#sec4; characters 2556–2797

### own_terms

[]

### actor_contexts

[{"actor_id":"EO:13154","evidence_id":"ACTOR_TEXT:EO:13154"},{"actor_id":"EO:13286","overflow":"actor-texts/EO_13286.json","text_sha256":"57b106e01d54e1bcf61065a73a3591003b50eef2d8d0f65b0b54f98ea436e6df"},{"actor_id":"EO:13289","evidence_id":"ACTOR_TEXT:EO:13289"}]

### actor_provisions

["ACT:EO:12985>EO:13286","ACT:EO:12985>EO:13286@407232d6eb246b18","ACT:EO:12985>EO:13286@71550c617a8ab05c"]

### chain

{"confidence":"medium","events":[{"actor_id":"EO:13286","char_end":17893,"char_start":17665,"confidence":"medium","how_named":"direct","id":"CHAIN:EO:12985#1","notes":"Change wording lead; chronology does not decide legal effect.","provision_text":"Executive Order 12985 of January 11, 1996 (\"Establishing the Armed Forces Service Medal\"), is amended by striking \"the Secretary of Transportation\" in section 2 and inserting \"the Secretary of Homeland Security\" in lieu thereof.","sections_touched":["section 2"],"signing_date":"2003-02-28","source":{"acceptable_as_original":false,"archival_id":"app:node/217113","filing_date":null,"grade":"mirror_transcription","instrument_id":"EO:13286","location_confidence":"medium","location_verified":false,"page_or_item":"Executive Order 13286—Amendment of Executive Orders, and Other Actions, in Connection With the Transfer of Certain Functions to the Secretary of Homeland Security; February 28, 2003; APP node 217113; common-crawl capture 2025-10-06T18:03:47Z","requires_page_check":true,"sha256":"c1a2aff53be0c95cb97e0871e389a3b185ae165f6dd9a539722ed1c45f135c34","signing_date":"2003-02-28","text_path":"jobs/app-executive-orders/output/texts/executive-order-13286-amendment-executive-orders-and-other-actions-connection-with-the.txt","text_sha256":"d24268c163cd19e82bda1102e745709657d237c65d627f55716beebc42ba94f0","url":"https://www.presidency.ucsb.edu/documents/executive-order-13286-amendment-executive-orders-and-other-actions-connection-with-the"},"verb":"amend"}],"generic_refs_excluded":221,"id":"CHAIN:EO:12985","notes":"Named, located change provisions only; missing provisions and unheld texts remain dossier gaps. Undated events sort last.","target_id":"EO:12985"}

### current_law_leads

[{"basis_code":"printed_eo_text","checked_through":"2026-10-09","currency_code":"usc_release_point","edition":"U.S. Code release point 119-121","evidence_gap":"No uniquely located attributed legal-text slice is held for this current-law pointer; serialized JSON/JSONL, snippets and absent cache artifacts are not legal-text evidence.","fragment_kind":"current_predicate_candidates","input_origin":"jobs/current-law/output/FRAGMENTS.jsonl","instrument_id":"EO:12985","legal_basis_candidate":"U.S. Code prints the order's text as a note, with no ending statement (10 U.S.C. subtitle A, pt. II, ch. 57 note)","machine_lead":true,"mention_id":"usc:1395f41f3cca","snippet":"Ex. Ord. No. 12985. Establishing Armed Forces Service Medal | Ex. Ord. No. 12985, Jan. 11, 1996, 61 F.R. 1209, as amended by Ex. Ord. No. 13286, § 20, Feb. 28, 2003, 68 F.R. 10624, provided:","source":{"page_or_item":"10 U.S.C. subtitle A, pt. II, ch. 57 note; note 'Ex. Ord. No. 12985. Establishing Armed Forces Service Medal' [USLM note id ida8989a5c-3a6f-11f1-a58a-d8db54b14ab5]; usc10.xml (sha256 f6b1a4f0897cd19431abb8af52cf3aafb02cf6e1870f0f6b5d1992c37fe128b6) in xml_uscAll@119-121.zip","sha256":"c6122974e951003437ece5a998aa7c0b2cdc0f5703dfc78d6135e1fc9e729142","url":"https://uscode.house.gov/download/releasepoints/us/pl/119/121/xml_uscAll@119-121.zip"},"system":"usc","text_path":"USC_EO_NOTES.jsonl#note_id=ida8989a5c-3a6f-11f1-a58a-d8db54b14ab5","where":"USC 10 U.S.C. subtitle A, pt. II, ch. 57 note"},{"basis_code":"statutory_text_reference","checked_through":"2026-10-09","currency_code":"usc_release_point","edition":"U.S. Code release point 119-121","evidence_gap":"No uniquely located attributed legal-text slice is held for this current-law pointer; serialized JSON/JSONL, snippets and absent cache artifacts are not legal-text evidence.","fragment_kind":"current_predicate_candidates","input_origin":"jobs/current-law/output/FRAGMENTS.jsonl","instrument_id":"EO:12985","legal_basis_candidate":"statute text names the order (38 U.S.C. 4212)","machine_lead":true,"mention_id":"usc:466a6845d96f","snippet":"...serving on active duty in the Armed Forces, participated in a United States military operation for which an Armed Forces service medal was awarded pursuant to Executive Order No. 12985 (61 Fed. Reg. 1209). (iv) Recently separated veterans. (B) The term “qualified”, with respect to an employment position, means having the ability to perform th...","source":{"page_or_item":"38 U.S.C. 4212; usc38.xml (sha256 812bcb4dab911d8d4b503a86de786adf53c7e6815b2667fcfe1dad79b63658b6) in xml_uscAll@119-121.zip","sha256":"c6122974e951003437ece5a998aa7c0b2cdc0f5703dfc78d6135e1fc9e729142","url":"https://uscode.house.gov/download/releasepoints/us/pl/119/121/xml_uscAll@119-121.zip"},"system":"usc","where":"USC 38 U.S.C. 4212"},{"basis_code":"references_in_text_note","checked_through":"2026-10-09","currency_code":"usc_release_point","edition":"U.S. Code release point 119-121","evidence_gap":"No uniquely located attributed legal-text slice is held for this current-law pointer; serialized JSON/JSONL, snippets and absent cache artifacts are not legal-text evidence.","fragment_kind":"current_predicate_candidates","input_origin":"jobs/current-law/output/FRAGMENTS.jsonl","instrument_id":"EO:12985","legal_basis_candidate":"References-in-Text note says statute text refers to the order (38 U.S.C. 4212 note)","machine_lead":true,"mention_id":"usc:053ad5b6044d","snippet":"...113–128, title V, §§ 506, 511(a), July 22, 2014, 128 Stat. 1703, 1705, effective July 1, 2015. For complete classification of this Act to the Code, see Tables. Executive Order No. 12985, referred to in subsec. (a)(3)(A)(iii), is set out as a note preceding section 1121 of Title 10, Armed Forces.","source":{"page_or_item":"38 U.S.C. 4212 note; note 'References in Text' [USLM note id idf8cc606d-ac5f-11f1-867f-e0c61e4ce6af]; usc38.xml (sha256 812bcb4dab911d8d4b503a86de786adf53c7e6815b2667fcfe1dad79b63658b6) in xml_uscAll@119-121.zip","sha256":"c6122974e951003437ece5a998aa7c0b2cdc0f5703dfc78d6135e1fc9e729142","url":"https://uscode.house.gov/download/releasepoints/us/pl/119/121/xml_uscAll@119-121.zip"},"system":"usc","where":"USC 38 U.S.C. 4212 note"},{"basis_code":"cfr_text_reference","checked_through":"2026-10-14","currency_code":"ecfr_bulk_no_change_after_cutoff","edition":"eCFR (GovInfo bulk, amended through 2026-09-22)","evidence_gap":"No uniquely located attributed legal-text slice is held for this current-law pointer; serialized JSON/JSONL, snippets and absent cache artifacts are not legal-text evidence.","fragment_kind":"current_predicate_candidates","input_origin":"jobs/current-law/output/FRAGMENTS.jsonl","instrument_id":"EO:12985","legal_basis_candidate":"regulation text names the order (41 CFR 60-300.2)","machine_lead":true,"mention_id":"ecfr:fffa5a256ea8","snippet":"...U.S. military, ground, naval or air service, participated in a United States military operation for which an Armed Forces service medal was awarded pursuant to Executive Order 12985 (61 FR 1209). (d) Compliance evaluation means any one or combination of actions OFCCP may take to examine a Federal contractor's or subcontractor's compliance...","source":{"page_or_item":"41 CFR 60-300.2 (section_text; GovInfo eCFR XML title 41, amended through 2026-09-22; NODE 41:1.2.3.1.9.1.11.2)","sha256":"f4463cdd577d7d092b31c47a32b67fbb47d628beffbbb689c52d26fbd1a012b3","url":"https://www.govinfo.gov/bulkdata/ECFR/title-41/ECFR-title41.xml"},"system":"ecfr","where":"CFR 41 CFR 60-300.2"},{"basis_code":"cfr_text_reference","checked_through":"2026-10-14","currency_code":"ecfr_bulk_no_change_after_cutoff","edition":"eCFR (GovInfo bulk, amended through 2026-09-22)","evidence_gap":"No uniquely located attributed legal-text slice is held for this current-law pointer; serialized JSON/JSONL, snippets and absent cache artifacts are not legal-text evidence.","fragment_kind":"current_predicate_candidates","input_origin":"jobs/current-law/output/FRAGMENTS.jsonl","instrument_id":"EO:12985","legal_basis_candidate":"regulation text names the order (41 CFR 61-300.2)","machine_lead":true,"mention_id":"ecfr:c06b1fdc693b","snippet":"...U.S. military, ground, naval or air service, participated in a United States military operation for which an Armed Forces service medal was awarded pursuant to Executive Order 12985 (61 FR 1209, 3 CFR, 1996 Comp., p. 159). (3) Disabled veteran means: (i) A veteran of the U.S. military, ground, naval or air service who is entitled to compen...","source":{"page_or_item":"41 CFR 61-300.2 (section_text; GovInfo eCFR XML title 41, amended through 2026-09-22; NODE 41:1.2.4.1.2.0.11.2)","sha256":"f4463cdd577d7d092b31c47a32b67fbb47d628beffbbb689c52d26fbd1a012b3","url":"https://www.govinfo.gov/bulkdata/ECFR/title-41/ECFR-title41.xml"},"system":"ecfr","where":"CFR 41 CFR 61-300.2"},{"basis_code":"cfr_text_reference","checked_through":"2026-10-14","currency_code":"ecfr_bulk_no_change_after_cutoff","edition":"eCFR (GovInfo bulk, amended through 2026-10-09)","evidence_gap":"No uniquely located attributed legal-text slice is held for this current-law pointer; serialized JSON/JSONL, snippets and absent cache artifacts are not legal-text evidence.","fragment_kind":"current_predicate_candidates","input_origin":"jobs/current-law/output/FRAGMENTS.jsonl","instrument_id":"EO:12985","legal_basis_candidate":"regulation text names the order (48 CFR 22.1301)","machine_lead":true,"mention_id":"ecfr:69b4c4aae79f","snippet":"....S. military, ground, naval, or air service, participated in a United States military operation for which an Armed Forces service medal was awarded pursuant to Executive Order 12985 (61 FR 1209). Disabled veteran means— (1) A veteran of the U.S. military, ground, naval, or air service, who is entitled to compensation (or who, but for the r...","source":{"page_or_item":"48 CFR 22.1301 (section_text; GovInfo eCFR XML title 48, amended through 2026-10-09; NODE 48:1.0.1.4.21.13.1.2)","sha256":"acf22f7e7bcfa3dc6201a8383cc5d917175ba82a857bd770112df21d299181c6","url":"https://www.govinfo.gov/bulkdata/ECFR/title-48/ECFR-title48.xml"},"system":"ecfr","where":"CFR 48 CFR 22.1301"},{"basis_code":"cfr_text_reference","checked_through":"2026-10-14","currency_code":"ecfr_bulk_no_change_after_cutoff","edition":"eCFR (GovInfo bulk, amended through 2026-10-15)","evidence_gap":"No uniquely located attributed legal-text slice is held for this current-law pointer; serialized JSON/JSONL, snippets and absent cache artifacts are not legal-text evidence.","fragment_kind":"current_predicate_candidates","input_origin":"jobs/current-law/output/FRAGMENTS.jsonl","instrument_id":"EO:12985","legal_basis_candidate":"regulation text names the order (5 CFR 307.102)","machine_lead":true,"mention_id":"ecfr:147ef733e6b7","snippet":"...on active duty with the Armed Forces, participated in a United States military operation for which an Armed Forces Service Medal (AFSM) was awarded pursuant to Executive Order 12985 (61 FR 1209); and (4) Recently separated veterans. Disabled veteran, as defined in 38 U.S.C. 4211 means: (1) A veteran who is entitled to compensation (or who,...","source":{"page_or_item":"5 CFR 307.102 (section_text; GovInfo eCFR XML title 5, amended through 2026-10-15; NODE 5:1.0.1.2.38.0.14.2)","sha256":"d0b85cb99762ee3117c673c30a95c6847c5f15e9d4a9b1401616030827721c91","url":"https://www.govinfo.gov/bulkdata/ECFR/title-5/ECFR-title5.xml"},"system":"ecfr","where":"CFR 5 CFR 307.102"},{"basis_code":"cfr_appendix_text_reference","checked_through":"2026-10-14","currency_code":"ecfr_bulk_no_change_after_cutoff","edition":"eCFR (GovInfo bulk, amended through 2026-09-22)","evidence_gap":"No uniquely located attributed legal-text slice is held for this current-law pointer; serialized JSON/JSONL, snippets and absent cache artifacts are not legal-text evidence.","fragment_kind":"current_predicate_candidates","input_origin":"jobs/current-law/output/FRAGMENTS.jsonl","instrument_id":"EO:12985","legal_basis_candidate":"CFR appendix names or reprints the order (41 CFR part 60, Appendix B to Part 60-300)","machine_lead":true,"mention_id":"ecfr:9572b8aa3674","snippet":"...U.S. military, ground, naval or air service, participated in a United States military operation for which an Armed Forces service medal was awarded pursuant to Executive Order 12985. Protected veterans may have additional rights under USERRA—the Uniformed Services Employment and Reemployment Rights Act. In particular, if you were absent fr...","source":{"page_or_item":"41 CFR part 60, Appendix B to Part 60-300 (appendix_text; GovInfo eCFR XML title 41, amended through 2026-09-22; NODE 41:1.2.3.1.9.5.11.7.3)","sha256":"f4463cdd577d7d092b31c47a32b67fbb47d628beffbbb689c52d26fbd1a012b3","url":"https://www.govinfo.gov/bulkdata/ECFR/title-41/ECFR-title41.xml"},"system":"ecfr","where":"CFR 41 CFR part 60, Appendix B to Part 60-300"},{"basis_code":"cfr_search_excerpt_reference","checked_through":"2026-10-14","currency_code":"ecfr_search_point_in_time","edition":"eCFR as of 2026-10-14","evidence_gap":"No uniquely located attributed legal-text slice is held for this current-law pointer; serialized JSON/JSONL, snippets and absent cache artifacts are not legal-text evidence.","fragment_kind":"current_predicate_candidates","input_origin":"jobs/current-law/output/FRAGMENTS.jsonl","instrument_id":"EO:12985","legal_basis_candidate":"eCFR point-in-time search excerpt names the order (41 CFR part 60-300, Appendix B to Part 60-300)","machine_lead":true,"mention_id":"ecfr:2e2a56c772f8","snippet":"Sample Invitation to Self-Identify | service medal was awarded pursuant to Executive Order 12985. Protected veterans may have","source":{"page_or_item":"41 CFR part 60-300, Appendix B to Part 60-300 (eCFR search API result, query \"Executive Order\", date=2026-10-14, page 3)","sha256":"6edecd5d7d179bd77a1c39561c12105cf4842032c11a19706bb4e0a40f39dd58","url":"https://www.ecfr.gov/api/search/v1/results?query=%22Executive+Order%22&date=2026-10-14&per_page=1000&page=3"},"system":"ecfr","where":"CFR 41 CFR part 60-300, Appendix B to Part 60-300"},{"custody_records_in":["current-law"],"evidence_gap":"Current-law lead lacks an original-source sha256.","meta":{"basis_code":"cfr_text_reference","caution":"a mention in current law is a LEAD, not by itself a legal basis; read the provision to see whether it keeps the order operating","currency_code":"ecfr_bulk_no_change_after_cutoff","edition":"eCFR (GovInfo bulk, amended through 2026-09-22)","from":"current-law@jobs/current-law/output","from_job":"current-law","mention_id":"ecfr:fffa5a256ea8","snippet":"...U.S. military, ground, naval or air service, participated in a United States military operation for which an Armed Forces service medal was awarded pursuant to Executive Order 12985 (61 FR 1209). (d) Compliance evaluation means any one or combination of actions OFCCP may take to examine a Federal ...","snippet_truncated":true,"system":"ecfr","where":"CFR 41 CFR 60-300.2"},"proposal":{"checked_through":"2026-10-14","legal_basis":"regulation text names the order (41 CFR 60-300.2)","source":{"page_or_item":"41 CFR 60-300.2 (section_text; GovInfo eCFR XML title 41, amended through 2026-09-22; NODE 41:1.2.3.1.9.1.11.2)","sha256":"f4463cdd577d7d092b31c47a32b67fbb47d628beffbbb689c52d26fbd1a012b3","url":"https://www.govinfo.gov/bulkdata/ECFR/title-41/ECFR-title41.xml"}}},{"custody_records_in":["current-law"],"evidence_gap":"Current-law lead lacks an original-source sha256.","meta":{"basis_code":"cfr_text_reference","caution":"a mention in current law is a LEAD, not by itself a legal basis; read the provision to see whether it keeps the order operating","currency_code":"ecfr_bulk_no_change_after_cutoff","edition":"eCFR (GovInfo bulk, amended through 2026-09-22)","from":"current-law@jobs/current-law/output","from_job":"current-law","mention_id":"ecfr:c06b1fdc693b","snippet":"...U.S. military, ground, naval or air service, participated in a United States military operation for which an Armed Forces service medal was awarded pursuant to Executive Order 12985 (61 FR 1209, 3 CFR, 1996 Comp., p. 159). (3) Disabled veteran means: (i) A veteran of the U.S. military, ground, na ...","snippet_truncated":true,"system":"ecfr","where":"CFR 41 CFR 61-300.2"},"proposal":{"checked_through":"2026-10-14","legal_basis":"regulation text names the order (41 CFR 61-300.2)","source":{"page_or_item":"41 CFR 61-300.2 (section_text; GovInfo eCFR XML title 41, amended through 2026-09-22; NODE 41:1.2.4.1.2.0.11.2)","sha256":"f4463cdd577d7d092b31c47a32b67fbb47d628beffbbb689c52d26fbd1a012b3","url":"https://www.govinfo.gov/bulkdata/ECFR/title-41/ECFR-title41.xml"}}},{"custody_records_in":["current-law"],"evidence_gap":"Current-law lead lacks an original-source sha256.","meta":{"basis_code":"cfr_text_reference","caution":"a mention in current law is a LEAD, not by itself a legal basis; read the provision to see whether it keeps the order operating","currency_code":"ecfr_bulk_no_change_after_cutoff","edition":"eCFR (GovInfo bulk, amended through 2026-10-09)","from":"current-law@jobs/current-law/output","from_job":"current-law","mention_id":"ecfr:69b4c4aae79f","snippet":"....S. military, ground, naval, or air service, participated in a United States military operation for which an Armed Forces service medal was awarded pursuant to Executive Order 12985 (61 FR 1209). Disabled veteran means— (1) A veteran of the U.S. military, ground, naval, or air service, who is ent ...","snippet_truncated":true,"system":"ecfr","where":"CFR 48 CFR 22.1301"},"proposal":{"checked_through":"2026-10-14","legal_basis":"regulation text names the order (48 CFR 22.1301)","source":{"page_or_item":"48 CFR 22.1301 (section_text; GovInfo eCFR XML title 48, amended through 2026-10-09; NODE 48:1.0.1.4.21.13.1.2)","sha256":"acf22f7e7bcfa3dc6201a8383cc5d917175ba82a857bd770112df21d299181c6","url":"https://www.govinfo.gov/bulkdata/ECFR/title-48/ECFR-title48.xml"}}},{"custody_records_in":["current-law"],"evidence_gap":"Current-law lead lacks an original-source sha256.","meta":{"basis_code":"cfr_text_reference","caution":"a mention in current law is a LEAD, not by itself a legal basis; read the provision to see whether it keeps the order operating","currency_code":"ecfr_bulk_no_change_after_cutoff","edition":"eCFR (GovInfo bulk, amended through 2026-10-15)","from":"current-law@jobs/current-law/output","from_job":"current-law","mention_id":"ecfr:147ef733e6b7","snippet":"...on active duty with the Armed Forces, participated in a United States military operation for which an Armed Forces Service Medal (AFSM) was awarded pursuant to Executive Order 12985 (61 FR 1209); and (4) Recently separated veterans. Disabled veteran, as defined in 38 U.S.C. 4211 means: (1) A vete ...","snippet_truncated":true,"system":"ecfr","where":"CFR 5 CFR 307.102"},"proposal":{"checked_through":"2026-10-14","legal_basis":"regulation text names the order (5 CFR 307.102)","source":{"page_or_item":"5 CFR 307.102 (section_text; GovInfo eCFR XML title 5, amended through 2026-10-15; NODE 5:1.0.1.2.38.0.14.2)","sha256":"d0b85cb99762ee3117c673c30a95c6847c5f15e9d4a9b1401616030827721c91","url":"https://www.govinfo.gov/bulkdata/ECFR/title-5/ECFR-title5.xml"}}},{"custody_records_in":["current-law"],"evidence_gap":"Current-law lead lacks an original-source sha256.","meta":{"basis_code":"cfr_appendix_text_reference","caution":"a mention in current law is a LEAD, not by itself a legal basis; read the provision to see whether it keeps the order operating","currency_code":"ecfr_bulk_no_change_after_cutoff","edition":"eCFR (GovInfo bulk, amended through 2026-09-22)","from":"current-law@jobs/current-law/output","from_job":"current-law","mention_id":"ecfr:9572b8aa3674","snippet":"...U.S. military, ground, naval or air service, participated in a United States military operation for which an Armed Forces service medal was awarded pursuant to Executive Order 12985. Protected veterans may have additional rights under USERRA—the Uniformed Services Employment and Reemployment Righ ...","snippet_truncated":true,"system":"ecfr","where":"CFR 41 CFR part 60, Appendix B to Part 60-300"},"proposal":{"checked_through":"2026-10-14","legal_basis":"CFR appendix names or reprints the order (41 CFR part 60, Appendix B to Part 60-300)","source":{"page_or_item":"41 CFR part 60, Appendix B to Part 60-300 (appendix_text; GovInfo eCFR XML title 41, amended through 2026-09-22; NODE 41:1.2.3.1.9.5.11.7.3)","sha256":"f4463cdd577d7d092b31c47a32b67fbb47d628beffbbb689c52d26fbd1a012b3","url":"https://www.govinfo.gov/bulkdata/ECFR/title-41/ECFR-title41.xml"}}},{"custody_records_in":["current-law"],"evidence_gap":"Current-law lead lacks an original-source sha256.","meta":{"basis_code":"cfr_search_excerpt_reference","caution":"a mention in current law is a LEAD, not by itself a legal basis; read the provision to see whether it keeps the order operating","currency_code":"ecfr_search_point_in_time","edition":"eCFR as of 2026-10-14","from":"current-law@jobs/current-law/output","from_job":"current-law","mention_id":"ecfr:2e2a56c772f8","snippet":"Sample Invitation to Self-Identify | service medal was awarded pursuant to Executive Order 12985. Protected veterans may have","snippet_truncated":false,"system":"ecfr","where":"CFR 41 CFR part 60-300, Appendix B to Part 60-300"},"proposal":{"checked_through":"2026-10-14","legal_basis":"eCFR point-in-time search excerpt names the order (41 CFR part 60-300, Appendix B to Part 60-300)","source":{"page_or_item":"41 CFR part 60-300, Appendix B to Part 60-300 (eCFR search API result, query \"Executive Order\", date=2026-10-14, page 3)","sha256":"6edecd5d7d179bd77a1c39561c12105cf4842032c11a19706bb4e0a40f39dd58","url":"https://www.ecfr.gov/api/search/v1/results?query=%22Executive+Order%22&date=2026-10-14&per_page=1000&page=3"}}},{"custody_records_in":["current-law"],"evidence_gap":"Current-law lead lacks an original-source sha256.","meta":{"basis_code":"statutory_text_reference","caution":"a mention in current law is a LEAD, not by itself a legal basis; read the provision to see whether it keeps the order operating","currency_code":"usc_release_point","edition":"U.S. Code release point 119-121","from":"current-law@jobs/current-law/output","from_job":"current-law","mention_id":"usc:466a6845d96f","snippet":"...serving on active duty in the Armed Forces, participated in a United States military operation for which an Armed Forces service medal was awarded pursuant to Executive Order No. 12985 (61 Fed. Reg. 1209). (iv) Recently separated veterans. (B) The term “qualified”, with respect to an employment p ...","snippet_truncated":true,"system":"usc","where":"USC 38 U.S.C. 4212"},"proposal":{"checked_through":"2026-10-09","legal_basis":"statute text names the order (38 U.S.C. 4212)","source":{"page_or_item":"38 U.S.C. 4212; usc38.xml (sha256 812bcb4dab911d8d4b503a86de786adf53c7e6815b2667fcfe1dad79b63658b6) in xml_uscAll@119-121.zip","sha256":"c6122974e951003437ece5a998aa7c0b2cdc0f5703dfc78d6135e1fc9e729142","url":"https://uscode.house.gov/download/releasepoints/us/pl/119/121/xml_uscAll@119-121.zip"}}},{"custody_records_in":["current-law"],"evidence_gap":"Current-law lead lacks an original-source sha256.","meta":{"basis_code":"references_in_text_note","caution":"a mention in current law is a LEAD, not by itself a legal basis; read the provision to see whether it keeps the order operating","currency_code":"usc_release_point","edition":"U.S. Code release point 119-121","from":"current-law@jobs/current-law/output","from_job":"current-law","mention_id":"usc:053ad5b6044d","snippet":"...113–128, title V, §§ 506, 511(a), July 22, 2014, 128 Stat. 1703, 1705, effective July 1, 2015. For complete classification of this Act to the Code, see Tables. Executive Order No. 12985, referred to in subsec. (a)(3)(A)(iii), is set out as a note preceding section 1121 of Title 10, Armed Forces.","snippet_truncated":false,"system":"usc","where":"USC 38 U.S.C. 4212 note"},"proposal":{"checked_through":"2026-10-09","legal_basis":"References-in-Text note says statute text refers to the order (38 U.S.C. 4212 note)","source":{"page_or_item":"38 U.S.C. 4212 note; note 'References in Text' [USLM note id idf8cc606d-ac5f-11f1-867f-e0c61e4ce6af]; usc38.xml (sha256 812bcb4dab911d8d4b503a86de786adf53c7e6815b2667fcfe1dad79b63658b6) in xml_uscAll@119-121.zip","sha256":"c6122974e951003437ece5a998aa7c0b2cdc0f5703dfc78d6135e1fc9e729142","url":"https://uscode.house.gov/download/releasepoints/us/pl/119/121/xml_uscAll@119-121.zip"}}},{"custody_records_in":["current-law"],"evidence_gap":"Current-law lead lacks an original-source sha256.","meta":{"basis_code":"printed_eo_text","caution":"a mention in current law is a LEAD, not by itself a legal basis; read the provision to see whether it keeps the order operating","currency_code":"usc_release_point","edition":"U.S. Code release point 119-121","from":"current-law@jobs/current-law/output","from_job":"current-law","mention_id":"usc:1395f41f3cca","snippet":"Ex. Ord. No. 12985. Establishing Armed Forces Service Medal | Ex. Ord. No. 12985, Jan. 11, 1996, 61 F.R. 1209, as amended by Ex. Ord. No. 13286, § 20, Feb. 28, 2003, 68 F.R. 10624, provided:","snippet_truncated":false,"system":"usc","text_path":"USC_EO_NOTES.jsonl#note_id=ida8989a5c-3a6f-11f1-a58a-d8db54b14ab5","where":"USC 10 U.S.C. subtitle A, pt. II, ch. 57 note"},"proposal":{"checked_through":"2026-10-09","legal_basis":"U.S. Code prints the order's text as a note, with no ending statement (10 U.S.C. subtitle A, pt. II, ch. 57 note)","source":{"page_or_item":"10 U.S.C. subtitle A, pt. II, ch. 57 note; note 'Ex. Ord. No. 12985. Establishing Armed Forces Service Medal' [USLM note id ida8989a5c-3a6f-11f1-a58a-d8db54b14ab5]; usc10.xml (sha256 f6b1a4f0897cd19431abb8af52cf3aafb02cf6e1870f0f6b5d1992c37fe128b6) in xml_uscAll@119-121.zip","sha256":"c6122974e951003437ece5a998aa7c0b2cdc0f5703dfc78d6135e1fc9e729142","url":"https://uscode.house.gov/download/releasepoints/us/pl/119/121/xml_uscAll@119-121.zip"}}}]

### machine_searches

[{"complete":true,"entry":{"checked_on":"2026-10-17","query_or_scope":"every citation of this order by number (forms 'Executive Order', 'Ex. Ord.', 'E.O.') in the text and notes of the titles read; edition current through 2026-10-09 (laws enacted after that date and on or before 2026-10-14 are not reflected)","repository":"U.S. Code, Office of the Law Revision Counsel release point 119-121 (USLM XML, 58 title files), statute text and editorial notes","searched_by":"jobs/current-law (machine search)"},"machine_hits_for_this_order":10,"scope_note":"","search_id":"current-law:usc"},{"complete":true,"entry":{"checked_on":"2026-10-17","query_or_scope":"full-text search for 'Executive Order', 'Executive Orders', 'E.O.', 'Ex. Ord.', 'Exec. Order' and regulation text, authority and source citations naming this order","repository":"eCFR point-in-time search as of 2026-10-14 and GovInfo CFR bulk XML (49 titles read)","searched_by":"jobs/current-law (machine search)"},"machine_hits_for_this_order":10,"scope_note":"","search_id":"current-law:ecfr"},{"complete":true,"entry":{"checked_on":"2026-10-19","query_or_scope":"disposition notes of 6938 catalog records (1937 onward) naming this order as amended, revoked, superseded or otherwise affected, plus operative sentences in 17521 saved order texts","repository":"Federal Register executive-order catalog (federalregister.gov API v1, include_pre_1994_docs=true): Office of the Federal Register disposition notes","searched_by":"jobs/later-events (machine search)"},"machine_hits_for_this_order":2,"scope_note":"","search_id":"later-events:ofr_catalog"}]

### draft_gate_errors

["clause_0_state","clause_1_state","clause_2_state","clause_3_state","yes_without_continuing_clause","savings_residuals_evidence","bounded_later_search","unresolved_material_gaps","research_rationale"]

### conflicts

[]

### draft_material_gaps

["DRAFT: state_at_cutoff not decided for 4 clause(s); clause inventory completeness not confirmed","DRAFT: current legal basis not established","DRAFT: savings and residual effects not closed","DRAFT: later_source_search not recorded (machine searches are proposals only; paste them after judging them adequate and resolving every CONFLICT line)"]

### missing

["Current legal predicate and coverage through 2026-10-14 require judgment; a citation or 1989 snapshot cannot prove continuation.","Current-law lead lacks an original-source sha256.","Large actor context must be read at actor-texts/EO_13286.json before deciding scope/savings.","No uniquely located attributed legal-text slice is held for this current-law pointer; serialized JSON/JSONL, snippets and absent cache artifacts are not legal-text evidence.","cited by number, no change provision located: EO:13289","target provision not located: EO:13154"]

### status_history

{"event_count":3,"fingerprint":"c83fb400f66c686af80ffd9dbed16cb16b14872cc10a4d04f142873603705974","flags":[],"history_path":"jobs/status-history/output/histories/EO_12985.json","history_sha256":"af3fc1d25d75108b640899e3fe43ab6297ce2227e55c56c92f6bcaded94c9177","input_origin":"jobs/status-history/output/FRAGMENTS.jsonl","legal_cutoff":"2026-10-14","machine_lead":true,"notice":"Editorial leads, not an original, legal conclusion, provisional-status assignment or human certification.","observation_count":1}

### notice

"MACHINE LEADS ONLY. No segmentation, date, source grade, family or chain is a legal conclusion."

### Additional dossier metadata

{"lifecycle_obligations":[{"clause_sha256":"021705710fe7559b5c5a8c241f82f5b14bbbed12c4cb915d49a88019b637eef4","established_ending":null,"human_certified":false,"instrument_id":"EO:12985","later_actor_evidence_ids":[],"own_term_evidence_ids":[],"questions":["Determine the first cessation or current predicate for this scope; check independent commands and surviving effects."],"schema":"eo-lifecycle-obligation/v1","scope_id":"EO:12985#sec1","state":"requires_clause_specific_research","wording_features":[]},{"clause_sha256":"71784ae82af1d5acceea79750265c29217a60a9eb87806e2a3f67a2072532a9c","established_ending":null,"human_certified":false,"instrument_id":"EO:12985","later_actor_evidence_ids":[],"own_term_evidence_ids":[],"questions":["Determine the first cessation or current predicate for this scope; check independent commands and surviving effects."],"schema":"eo-lifecycle-obligation/v1","scope_id":"EO:12985#sec1-b","state":"requires_clause_specific_research","wording_features":[]},{"clause_sha256":"f1c3ba6aae2908db427a82750093844837b68fbf86deb1a0127b3f214bcad66e","established_ending":null,"human_certified":false,"instrument_id":"EO:12985","later_actor_evidence_ids":[],"own_term_evidence_ids":[],"questions":["Determine the first cessation or current predicate for this scope; check independent commands and surviving effects."],"schema":"eo-lifecycle-obligation/v1","scope_id":"EO:12985#sec2","state":"requires_clause_specific_research","wording_features":[]},{"clause_sha256":"10cbe4907f4ccc4002e566458421934d82910645910cfa4cdd842dad2d00722a","established_ending":null,"human_certified":false,"instrument_id":"EO:12985","later_actor_evidence_ids":[],"own_term_evidence_ids":[],"questions":["Determine the first cessation or current predicate for this scope; check independent commands and surviving effects."],"schema":"eo-lifecycle-obligation/v1","scope_id":"EO:12985#sec3","state":"requires_clause_specific_research","wording_features":[]},{"clause_sha256":"f1303c467a12e9bec412b0fd69dccd550e6ce2de311110549b34361807023ecc","established_ending":null,"human_certified":false,"instrument_id":"EO:12985","later_actor_evidence_ids":[],"own_term_evidence_ids":[],"questions":["Determine the first cessation or current predicate for this scope; check independent commands and surviving effects."],"schema":"eo-lifecycle-obligation/v1","scope_id":"EO:12985#sec4","state":"requires_clause_specific_research","wording_features":[]}]}

### Preflight

{"custody_validation":"required_from_actual_claim_checker","decisions_still_required":["complete original/inventory","earlier ending","partial scope and effective date","independent commands","savings/residuals","contrary evidence and cutoff predicate"],"evidence_preflight":"blocked_or_research","held_text_receipts":{"jobs/fr-originals/data/full_run/texts/EO_12985.txt":{"characters":2895,"raw_custody":"requires_actual_claim_checker","source_sha256":"eece26bfc0809ebfef4b097a78abfcfe4e59788c977ae20b07ab24ab82428023","text_sha256":"76f891cde9ad452e56d7c4eaa3b216c1b3ff68bcd54e29825e55be3709c3a6f3"}},"instrument_id":"EO:12985","lifecycle_obligations":[{"clause_sha256":"021705710fe7559b5c5a8c241f82f5b14bbbed12c4cb915d49a88019b637eef4","established_ending":null,"human_certified":false,"instrument_id":"EO:12985","later_actor_evidence_ids":[],"own_term_evidence_ids":[],"questions":["Determine the first cessation or current predicate for this scope; check independent commands and surviving effects."],"schema":"eo-lifecycle-obligation/v1","scope_id":"EO:12985#sec1","state":"requires_clause_specific_research","wording_features":[]},{"clause_sha256":"71784ae82af1d5acceea79750265c29217a60a9eb87806e2a3f67a2072532a9c","established_ending":null,"human_certified":false,"instrument_id":"EO:12985","later_actor_evidence_ids":[],"own_term_evidence_ids":[],"questions":["Determine the first cessation or current predicate for this scope; check independent commands and surviving effects."],"schema":"eo-lifecycle-obligation/v1","scope_id":"EO:12985#sec1-b","state":"requires_clause_specific_research","wording_features":[]},{"clause_sha256":"f1c3ba6aae2908db427a82750093844837b68fbf86deb1a0127b3f214bcad66e","established_ending":null,"human_certified":false,"instrument_id":"EO:12985","later_actor_evidence_ids":[],"own_term_evidence_ids":[],"questions":["Determine the first cessation or current predicate for this scope; check independent commands and surviving effects."],"schema":"eo-lifecycle-obligation/v1","scope_id":"EO:12985#sec2","state":"requires_clause_specific_research","wording_features":[]},{"clause_sha256":"10cbe4907f4ccc4002e566458421934d82910645910cfa4cdd842dad2d00722a","established_ending":null,"human_certified":false,"instrument_id":"EO:12985","later_actor_evidence_ids":[],"own_term_evidence_ids":[],"questions":["Determine the first cessation or current predicate for this scope; check independent commands and surviving effects."],"schema":"eo-lifecycle-obligation/v1","scope_id":"EO:12985#sec3","state":"requires_clause_specific_research","wording_features":[]},{"clause_sha256":"f1303c467a12e9bec412b0fd69dccd550e6ce2de311110549b34361807023ecc","established_ending":null,"human_certified":false,"instrument_id":"EO:12985","later_actor_evidence_ids":[],"own_term_evidence_ids":[],"questions":["Determine the first cessation or current predicate for this scope; check independent commands and surviving effects."],"schema":"eo-lifecycle-obligation/v1","scope_id":"EO:12985#sec4","state":"requires_clause_specific_research","wording_features":[]}],"mechanical_tasks":[{"availability":"held_not_loaded","instrument_id":"EO:12985","kind":"load_actor_overflow","reason":"Read full overflow before scope/savings decision","shared_key":"EO:13286","task_id":"TASK:84afaf7b7ab986f33b60241f"},{"availability":"citation_or_pointer_only","instrument_id":"EO:12985","kind":"operative_current_law","reason":"No uniquely located attributed legal-text slice is held for this current-law pointer; serialized JSON/JSONL, snippets and absent cache artifacts are not legal-text evidence.","shared_key":"{\"basis_code\":\"printed_eo_text\",\"source\":{\"page_or_item\":\"10 U.S.C. subtitle A, pt. II, ch. 57 note; note 'Ex. Ord. No. 12985. Establishing Armed Forces Service Medal' [USLM note id ida8989a5c-3a6f-11f1-a58a-d8db54b14ab5]; usc10.xml (sha256 f6b1a4f0897cd19431abb8af52cf3aafb02cf6e1870f0f6b5d1992c37fe128b6) in xml_uscAll@119-121.zip\",\"sha256\":\"c6122974e951003437ece5a998aa7c0b2cdc0f5703dfc78d6135e1fc9e729142\",\"url\":\"https://uscode.house.gov/download/releasepoints/us/pl/119/121/xml_uscAll@119-121.zip\"},\"text_path\":\"USC_EO_NOTES.jsonl#note_id=ida8989a5c-3a6f-11f1-a58a-d8db54b14ab5\"}","task_id":"TASK:4055b32ad55ebfaf70d81604"},{"availability":"citation_or_pointer_only","instrument_id":"EO:12985","kind":"operative_current_law","reason":"No uniquely located attributed legal-text slice is held for this current-law pointer; serialized JSON/JSONL, snippets and absent cache artifacts are not legal-text evidence.","shared_key":"{\"basis_code\":\"statutory_text_reference\",\"source\":{\"page_or_item\":\"38 U.S.C. 4212; usc38.xml (sha256 812bcb4dab911d8d4b503a86de786adf53c7e6815b2667fcfe1dad79b63658b6) in xml_uscAll@119-121.zip\",\"sha256\":\"c6122974e951003437ece5a998aa7c0b2cdc0f5703dfc78d6135e1fc9e729142\",\"url\":\"https://uscode.house.gov/download/releasepoints/us/pl/119/121/xml_uscAll@119-121.zip\"}}","task_id":"TASK:a32bfc0f773cdd2ade95169a"},{"availability":"citation_or_pointer_only","instrument_id":"EO:12985","kind":"operative_current_law","reason":"No uniquely located attributed legal-text slice is held for this current-law pointer; serialized JSON/JSONL, snippets and absent cache artifacts are not legal-text evidence.","shared_key":"{\"basis_code\":\"references_in_text_note\",\"source\":{\"page_or_item\":\"38 U.S.C. 4212 note; note 'References in Text' [USLM note id idf8cc606d-ac5f-11f1-867f-e0c61e4ce6af]; usc38.xml (sha256 812bcb4dab911d8d4b503a86de786adf53c7e6815b2667fcfe1dad79b63658b6) in xml_uscAll@119-121.zip\",\"sha256\":\"c6122974e951003437ece5a998aa7c0b2cdc0f5703dfc78d6135e1fc9e729142\",\"url\":\"https://uscode.house.gov/download/releasepoints/us/pl/119/121/xml_uscAll@119-121.zip\"}}","task_id":"TASK:22431ad056a4a936af28d39f"},{"availability":"citation_or_pointer_only","instrument_id":"EO:12985","kind":"operative_current_law","reason":"No uniquely located attributed legal-text slice is held for this current-law pointer; serialized JSON/JSONL, snippets and absent cache artifacts are not legal-text evidence.","shared_key":"{\"basis_code\":\"cfr_text_reference\",\"source\":{\"page_or_item\":\"41 CFR 60-300.2 (section_text; GovInfo eCFR XML title 41, amended through 2026-09-22; NODE 41:1.2.3.1.9.1.11.2)\",\"sha256\":\"f4463cdd577d7d092b31c47a32b67fbb47d628beffbbb689c52d26fbd1a012b3\",\"url\":\"https://www.govinfo.gov/bulkdata/ECFR/title-41/ECFR-title41.xml\"}}","task_id":"TASK:12a6f8b43fb8f502506ef91b"},{"availability":"citation_or_pointer_only","instrument_id":"EO:12985","kind":"operative_current_law","reason":"No uniquely located attributed legal-text slice is held for this current-law pointer; serialized JSON/JSONL, snippets and absent cache artifacts are not legal-text evidence.","shared_key":"{\"basis_code\":\"cfr_text_reference\",\"source\":{\"page_or_item\":\"41 CFR 61-300.2 (section_text; GovInfo eCFR XML title 41, amended through 2026-09-22; NODE 41:1.2.4.1.2.0.11.2)\",\"sha256\":\"f4463cdd577d7d092b31c47a32b67fbb47d628beffbbb689c52d26fbd1a012b3\",\"url\":\"https://www.govinfo.gov/bulkdata/ECFR/title-41/ECFR-title41.xml\"}}","task_id":"TASK:2389f196e0513b65cfb97e9c"},{"availability":"citation_or_pointer_only","instrument_id":"EO:12985","kind":"operative_current_law","reason":"No uniquely located attributed legal-text slice is held for this current-law pointer; serialized JSON/JSONL, snippets and absent cache artifacts are not legal-text evidence.","shared_key":"{\"basis_code\":\"cfr_text_reference\",\"source\":{\"page_or_item\":\"48 CFR 22.1301 (section_text; GovInfo eCFR XML title 48, amended through 2026-10-09; NODE 48:1.0.1.4.21.13.1.2)\",\"sha256\":\"acf22f7e7bcfa3dc6201a8383cc5d917175ba82a857bd770112df21d299181c6\",\"url\":\"https://www.govinfo.gov/bulkdata/ECFR/title-48/ECFR-title48.xml\"}}","task_id":"TASK:5b8cf9cca0a8511138092dd5"},{"availability":"citation_or_pointer_only","instrument_id":"EO:12985","kind":"operative_current_law","reason":"No uniquely located attributed legal-text slice is held for this current-law pointer; serialized JSON/JSONL, snippets and absent cache artifacts are not legal-text evidence.","shared_key":"{\"basis_code\":\"cfr_text_reference\",\"source\":{\"page_or_item\":\"5 CFR 307.102 (section_text; GovInfo eCFR XML title 5, amended through 2026-10-15; NODE 5:1.0.1.2.38.0.14.2)\",\"sha256\":\"d0b85cb99762ee3117c673c30a95c6847c5f15e9d4a9b1401616030827721c91\",\"url\":\"https://www.govinfo.gov/bulkdata/ECFR/title-5/ECFR-title5.xml\"}}","task_id":"TASK:1af560c59c98cb4ea63b04f1"},{"availability":"citation_or_pointer_only","instrument_id":"EO:12985","kind":"operative_current_law","reason":"No uniquely located attributed legal-text slice is held for this current-law pointer; serialized JSON/JSONL, snippets and absent cache artifacts are not legal-text evidence.","shared_key":"{\"basis_code\":\"cfr_appendix_text_reference\",\"source\":{\"page_or_item\":\"41 CFR part 60, Appendix B to Part 60-300 (appendix_text; GovInfo eCFR XML title 41, amended through 2026-09-22; NODE 41:1.2.3.1.9.5.11.7.3)\",\"sha256\":\"f4463cdd577d7d092b31c47a32b67fbb47d628beffbbb689c52d26fbd1a012b3\",\"url\":\"https://www.govinfo.gov/bulkdata/ECFR/title-41/ECFR-title41.xml\"}}","task_id":"TASK:f6393f0aef144c4adc893524"},{"availability":"citation_or_pointer_only","instrument_id":"EO:12985","kind":"operative_current_law","reason":"No uniquely located attributed legal-text slice is held for this current-law pointer; serialized JSON/JSONL, snippets and absent cache artifacts are not legal-text evidence.","shared_key":"{\"basis_code\":\"cfr_search_excerpt_reference\",\"source\":{\"page_or_item\":\"41 CFR part 60-300, Appendix B to Part 60-300 (eCFR search API result, query \\\"Executive Order\\\", date=2026-10-14, page 3)\",\"sha256\":\"6edecd5d7d179bd77a1c39561c12105cf4842032c11a19706bb4e0a40f39dd58\",\"url\":\"https://www.ecfr.gov/api/search/v1/results?query=%22Executive+Order%22&date=2026-10-14&per_page=1000&page=3\"}}","task_id":"TASK:925fbb7ba628d7b3fee68d06"},{"availability":"citation_or_pointer_only","instrument_id":"EO:12985","kind":"operative_current_law","reason":"Current-law lead lacks an original-source sha256.","shared_key":"{}","task_id":"TASK:1b16444cae50780611b48e39"},{"availability":"citation_or_pointer_only","instrument_id":"EO:12985","kind":"operative_current_law","reason":"Current-law lead lacks an original-source sha256.","shared_key":"{}","task_id":"TASK:1b16444cae50780611b48e39"},{"availability":"citation_or_pointer_only","instrument_id":"EO:12985","kind":"operative_current_law","reason":"Current-law lead lacks an original-source sha256.","shared_key":"{}","task_id":"TASK:1b16444cae50780611b48e39"},{"availability":"citation_or_pointer_only","instrument_id":"EO:12985","kind":"operative_current_law","reason":"Current-law lead lacks an original-source sha256.","shared_key":"{}","task_id":"TASK:1b16444cae50780611b48e39"},{"availability":"citation_or_pointer_only","instrument_id":"EO:12985","kind":"operative_current_law","reason":"Current-law lead lacks an original-source sha256.","shared_key":"{}","task_id":"TASK:1b16444cae50780611b48e39"},{"availability":"citation_or_pointer_only","instrument_id":"EO:12985","kind":"operative_current_law","reason":"Current-law lead lacks an original-source sha256.","shared_key":"{}","task_id":"TASK:1b16444cae50780611b48e39"},{"availability":"citation_or_pointer_only","instrument_id":"EO:12985","kind":"operative_current_law","reason":"Current-law lead lacks an original-source sha256.","shared_key":"{}","task_id":"TASK:1b16444cae50780611b48e39"},{"availability":"citation_or_pointer_only","instrument_id":"EO:12985","kind":"operative_current_law","reason":"Current-law lead lacks an original-source sha256.","shared_key":"{}","task_id":"TASK:1b16444cae50780611b48e39"},{"availability":"citation_or_pointer_only","instrument_id":"EO:12985","kind":"operative_current_law","reason":"Current-law lead lacks an original-source sha256.","shared_key":"{}","task_id":"TASK:1b16444cae50780611b48e39"},{"availability":"held_not_loaded","instrument_id":"EO:12985","kind":"read_citing_order","reason":"cited by number, no change provision located: EO:13289","shared_key":"EO:13289","task_id":"TASK:27621c8342df74bec118ad72"},{"availability":"held_not_loaded","instrument_id":"EO:12985","kind":"locate_held_provision","reason":"target provision not located: EO:13154","shared_key":"EO:13154","task_id":"TASK:e6616e06c5d98f11f800cbe5"},{"availability":"absent_or_unreadable","instrument_id":"EO:12985","kind":"held_text_unavailable","reason":"[Errno 2] No such file or directory: '/workspace/scratch/a5be930883fa/eo-readiness/jobs/app-executive-orders/output/texts/executive-order-13286-amendment-executive-orders-and-other-actions-connection-with-the.txt'","shared_key":"jobs/app-executive-orders/output/texts/executive-order-13286-amendment-executive-orders-and-other-actions-connection-with-the.txt","task_id":"TASK:2f0d8690fd95d97958c0569d"},{"availability":"absent_or_unreadable","instrument_id":"EO:12985","kind":"held_text_unavailable","reason":"[Errno 2] No such file or directory: '/workspace/scratch/a5be930883fa/eo-readiness/jobs/clause-drafts/output/texts/cd-opus_zip-13286-1cc5a2464d.txt'","shared_key":"jobs/clause-drafts/output/texts/cd-opus_zip-13286-1cc5a2464d.txt","task_id":"TASK:148b093971bcc21847f4a446"},{"availability":"absent_or_unreadable","instrument_id":"EO:12985","kind":"held_text_unavailable","reason":"[Errno 2] No such file or directory: '/workspace/scratch/a5be930883fa/eo-readiness/jobs/fr-originals/data/full_run/texts/EO_13154.txt'","shared_key":"jobs/fr-originals/data/full_run/texts/EO_13154.txt","task_id":"TASK:e54b76a8ea82b7d74e678e90"},{"availability":"absent_or_unreadable","instrument_id":"EO:12985","kind":"held_text_unavailable","reason":"[Errno 2] No such file or directory: '/workspace/scratch/a5be930883fa/eo-readiness/jobs/fr-originals/data/full_run/texts/EO_13289.txt'","shared_key":"jobs/fr-originals/data/full_run/texts/EO_13289.txt","task_id":"TASK:8baa1743fe696661db7bd624"}],"notice":"No known gap is not a legal-readiness finding. Review may expose new facts."}

### Prior research and remaining delta

{"conflicting_versions":[],"current_rulings":[{"expected_sha256":null,"path":"research/readiness/owner_rulings/2026-10-29-tiered-delegation.md","sha256":"20a27c48ee4b86711151ed632bcbab14028197e4a3430ad1431c86c004629cd6","state":"unqualified"}],"full_context":"PACKET.json#/prior_research/orders/EO:12985","notice":"Prior producer/reviewer assertions, not new findings or automatic approval. Reuse only after checking the exact version, source, proposition and scope. Rejected versions and contradictory assertions remain visible; whole-case review is still required.","remaining_delta":{"current_reported_gaps":[],"dossier_fingerprint":"0272069e0948fd683e619b5ab00ce2f6850a99f901ae50ab7d8ce94fc7732c46","existing_lifecycle_questions":[{"clause_sha256":"021705710fe7559b5c5a8c241f82f5b14bbbed12c4cb915d49a88019b637eef4","dossier_pointer":"/lifecycle_obligations/0","later_actor_evidence_ids":[],"own_term_evidence_ids":[],"questions":["Determine the first cessation or current predicate for this scope; check independent commands and surviving effects."],"scope_id":"EO:12985#sec1","state":"requires_clause_specific_research"},{"clause_sha256":"71784ae82af1d5acceea79750265c29217a60a9eb87806e2a3f67a2072532a9c","dossier_pointer":"/lifecycle_obligations/1","later_actor_evidence_ids":[],"own_term_evidence_ids":[],"questions":["Determine the first cessation or current predicate for this scope; check independent commands and surviving effects."],"scope_id":"EO:12985#sec1-b","state":"requires_clause_specific_research"},{"clause_sha256":"f1c3ba6aae2908db427a82750093844837b68fbf86deb1a0127b3f214bcad66e","dossier_pointer":"/lifecycle_obligations/2","later_actor_evidence_ids":[],"own_term_evidence_ids":[],"questions":["Determine the first cessation or current predicate for this scope; check independent commands and surviving effects."],"scope_id":"EO:12985#sec2","state":"requires_clause_specific_research"},{"clause_sha256":"10cbe4907f4ccc4002e566458421934d82910645910cfa4cdd842dad2d00722a","dossier_pointer":"/lifecycle_obligations/3","later_actor_evidence_ids":[],"own_term_evidence_ids":[],"questions":["Determine the first cessation or current predicate for this scope; check independent commands and surviving effects."],"scope_id":"EO:12985#sec3","state":"requires_clause_specific_research"},{"clause_sha256":"f1303c467a12e9bec412b0fd69dccd550e6ce2de311110549b34361807023ecc","dossier_pointer":"/lifecycle_obligations/4","later_actor_evidence_ids":[],"own_term_evidence_ids":[],"questions":["Determine the first cessation or current predicate for this scope; check independent commands and surviving effects."],"scope_id":"EO:12985#sec4","state":"requires_clause_specific_research"}],"existing_lifecycle_questions_notice":"Current dossier research prompts, not new gap findings or overrides of prior claim/review conclusions.","new_legal_gaps_invented":[],"prior_differences_require_scope_source_proposition_review":true},"selection_and_checkpoint_records":[],"state":"no_prior_research_located","status_holds":[],"status_research":[],"unattached_status_reviews":[],"unfinished_work":[],"versions":[]}

## EO:12793

Fingerprint: 9f05eb3439017c1215a8a46f2e7982a426b11a10ca8328cb25dffcf42dc302c5; provisional status: yes
Ownership/routing: {"route":"new_producer_proposal"}
Required member checks: earlier ending; scope; independent commands; savings.

### Evidence index

- **ACT:EO:12793>EO:13286**; Sd3145c7b44424f882132e4cb; {"actor_id":"EO:13286","char_end":22077,"char_start":21816,"confidence":"medium","effective_class":"unknown","effective_date":null,"effective_wording":[{"char_end":2501,"char_start":2411,"text":"Executive Order 13260 of March 19, 2002, is hereby revoked effective as of March 31, 2003."},{"char_end":41701,"char_start":40943,"text":"(a)\nin the case of the Department of Defense, the Secretary of Defense has, after consideration of the authority provided under subtitle G of title VIII of the Homeland Security Act of 2002, determined that the exercise of authority under this order is necessary for the timely and effective conduct of United States military or intelligence activities; and\n(b)\nin the case of any other executive department or agency that has authority under this order, (i) the Secretary of Homeland Security has advised whether the use of the authority provided under subtitle G of title VIII of the Homeland Security Act of 2002 would be appropriate, and (ii) the Director of the Office and Management and Budget has approved the exercise of authority under this order.\"."},{"char_end":49577,"char_start":49526,"text":"This order shall become effective on March 1, 2003."}],"exceptions_text":[],"filing_date":null,"id":"ACT:EO:12793>EO:13286","names_target":true,"notes":"Machine lead only; no legal ending asserted. Effective wording is ambiguous, section-specific, or has no determinable date.","provision_label":"Sec. 31.","reaches_target_via":"","savings_phrases":["Without prejudice to subsections (a) through (i) of this section, all responsibilities assigned to specific Federal officials pursuant to Executive Order 12656 that are substantially the same as any responsibility assigned to, or function transferred to, the Secretary of Homeland Security pursuant to the Homeland Security Act of 2002 (regardless of whether such responsibility or function is expressly required to be carried out through another official of the Department of Homeland Security or not pursuant to such Act), or intended or required to be carried out by an agency or an agency component transferred to the Department of Homeland Security pursuant to such Act, are hereby reassigned to the Secretary of Homeland Security.","Executive Order 11239 of July 31, 1965 (\"Enforcement of the Convention for Safety of Life at Sea, 1960\"), as amended, is further amended, without prejudice to section 1–106 of Executive Order 12234 of September 3, 1980 (\"Enforcement of the Convention for the Safety of Life at Sea\"), by:","Savings Provision."],"scope":"partial","signing_date":"2003-02-28","target_id":"EO:12793","verb":"amend"}
  Exact retained record text (unshared):
Executive Order 12793 of March 20, 1992 ("Continuing the Presidential Service Certificate and Presidential Service Badge"), is amended by striking "the Secretary of Transportation" in section 1 and inserting "the Secretary of Homeland Security" in lieu thereof.
- **ACT:EO:12793>EO:13286:effective#0**; Sd3145c7b44424f882132e4cb; {"actor_id":"EO:13286","char_end":2501,"char_start":2411,"id":"ACT:EO:12793>EO:13286:effective#0"}
- **ACT:EO:12793>EO:13286:effective#1**; Sd3145c7b44424f882132e4cb; {"actor_id":"EO:13286","char_end":41701,"char_start":40943,"id":"ACT:EO:12793>EO:13286:effective#1"}
- **ACT:EO:12793>EO:13286:effective#2**; Sd3145c7b44424f882132e4cb; {"actor_id":"EO:13286","char_end":49577,"char_start":49526,"id":"ACT:EO:12793>EO:13286:effective#2"}
- **ACT:EO:12793>EO:13286@1f07c88d0efe40c8**; Sd3145c7b44424f882132e4cb; {"actor_id":"EO:13286","char_end":22077,"char_start":21816,"confidence":"medium","effective_class":"unknown","effective_date":null,"effective_wording":[{"char_end":2501,"char_start":2411,"text":"Executive Order 13260 of March 19, 2002, is hereby revoked effective as of March 31, 2003."},{"char_end":41701,"char_start":40943,"text":"(a)\nin the case of the Department of Defense, the Secretary of Defense has, after consideration of the authority provided under subtitle G of title VIII of the Homeland Security Act of 2002, determined that the exercise of authority under this order is necessary for the timely and effective conduct of United States military or intelligence activities; and\n(b)\nin the case of any other executive department or agency that has authority under this order, (i) the Secretary of Homeland Security has advised whether the use of the authority provided under subtitle G of title VIII of the Homeland Security Act of 2002 would be appropriate, and (ii) the Director of the Office and Management and Budget has approved the exercise of authority under this order.\"."},{"char_end":49577,"char_start":49526,"text":"This order shall become effective on March 1, 2003."}],"exceptions_text":[],"filing_date":null,"id":"ACT:EO:12793>EO:13286@1f07c88d0efe40c8","names_target":true,"notes":"Machine lead only; no legal ending asserted. Effective wording is ambiguous, section-specific, or has no determinable date.","provision_label":"Sec. 31.","reaches_target_via":"","savings_phrases":["Without prejudice to subsections (a) through (i) of this section, all responsibilities assigned to specific Federal officials pursuant to Executive Order 12656 that are substantially the same as any responsibility assigned to, or function transferred to, the Secretary of Homeland Security pursuant to the Homeland Security Act of 2002 (regardless of whether such responsibility or function is expressly required to be carried out through another official of the Department of Homeland Security or not pursuant to such Act), or intended or required to be carried out by an agency or an agency component transferred to the Department of Homeland Security pursuant to such Act, are hereby reassigned to the Secretary of Homeland Security.","Executive Order 11239 of July 31, 1965 (\"Enforcement of the Convention for Safety of Life at Sea, 1960\"), as amended, is further amended, without prejudice to section 1–106 of Executive Order 12234 of September 3, 1980 (\"Enforcement of the Convention for the Safety of Life at Sea\"), by:","Savings Provision."],"scope":"partial","signing_date":"2003-02-28","target_id":"EO:12793","verb":"amend"}
- **ACT:EO:12793>EO:13286@6c0146167ca9b5a6**; S639260cb4c22eda960847445; {"actor_id":"EO:13286","char_end":22373,"char_start":22112,"confidence":"medium","effective_class":"unknown","effective_date":null,"effective_wording":[{"char_end":2699,"char_start":2609,"text":"Executive Order 13260 of March 19, 2002, is hereby revoked effective as of March 31, 2003."},{"char_end":41709,"char_start":41356,"text":"in the case of the Department of Defense, the Secretary of Defense has, after consideration of the authority provided under subtitle G of title VIII of the Homeland Security Act of 2002, determined that the exercise of authority under this order is necessary for the timely and effective conduct of United States military or intelligence activities; and"},{"char_end":50009,"char_start":49958,"text":"This order shall become effective on March 1, 2003."}],"exceptions_text":[],"filing_date":null,"id":"ACT:EO:12793>EO:13286@6c0146167ca9b5a6","names_target":true,"notes":"Machine lead only; no legal ending asserted. Effective wording is ambiguous, section-specific, or has no determinable date.","provision_label":"Sec. 31.","reaches_target_via":"","savings_phrases":["Without prejudice to subsections (a) through (i) of this section, all responsibilities assigned to specific Federal officials pursuant to Executive Order 12656 that are substantially the same as any responsibility assigned to, or function transferred to, the Secretary of Homeland Security pursuant to the Homeland Security Act of 2002 (regardless of whether such responsibility or function is expressly required to be carried out through another official of the Department of Homeland Security or not pursuant to such Act), or intended or required to be carried out by an agency or an agency component transferred to the Department of Homeland Security pursuant to such Act, are hereby reassigned to the Secretary of Homeland Security.","Executive Order 11239 of July 31, 1965 (\"Enforcement of the Convention for Safety of Life at Sea, 1960\"), as amended, is further amended, without prejudice to section 1–106 of Executive Order 12234 of September 3, 1980 (\"Enforcement of the Convention for the Safety of Life at Sea\"), by:","Savings Provision."],"scope":"partial","signing_date":"2003-02-28","target_id":"EO:12793","verb":"amend"}
- **ACT:EO:12793>EO:13373**; Sbf0d20d958916f234babd443; {"actor_id":"EO:13373","char_end":3664,"char_start":920,"confidence":"medium","effective_class":"on_signing","effective_date":null,"effective_wording":[],"exceptions_text":[],"filing_date":null,"id":"ACT:EO:12793>EO:13373","names_target":true,"notes":"Machine lead only; no legal ending asserted. No express effective wording found; on_signing is an unconfirmed lead assumption; signing date is not asserted as an exact effective date.","provision_label":"Section 1.","reaches_target_via":"","savings_phrases":[],"scope":"partial","signing_date":"2005-03-10","target_id":"EO:12793","verb":"amend"}
  Exact retained record text (unshared):
Executive Order 11926 
of July 19, 1976, as amended by Executive Order 13286 of February 28, 
2003, is further amended as follows: 
(a) in section 1, by striking ‘‘and Coast Guard’’ and inserting in lieu 
thereof ‘‘Coast Guard, commissioned corps of the National Oceanic and 
Atmospheric Administration, and commissioned corps of the Public Health 
Service’’; 
(b) in section 1, by inserting ‘‘, or who have been assigned to perform 
duties predominantly for the Vice President for a period of at least one 
year subsequent to January 20, 2001, in the implementation of Public Law 
93–346, as amended, or in military units and support facilities to which 
section 1 of Executive Order 12793 of March 20, 1992, as amended, refers’’ 
immediately preceding the period; 
(c) in section 2, by striking ‘‘Military Assistant to the Vice President’’ 
and inserting in lieu thereof ‘‘Vice President’s designee (with the concurrence 
of the Director of the White House Military Office in the case of personnel 
in military units or support facilities to which section 1 of Executive Order 
12793, as amended, refers)’’; 
(d) in section 2, by inserting ‘‘and, in the case of members of the commis-
sioned corps of the National Oceanic and Atmospheric Administration or 
the commissioned corps of the Public Health Service so assigned, by the 
Secretary of Commerce or the Secretary of Health and Human Services, 
respectively’’ immediately preceding the period; 
(e) in section 5, by adding at the end of the section ‘‘No award shall 
be made to an individual under this Order based on a period of service 
with respect to which, in whole or in part, the individual was awarded 
the Presidential Service Badge.’’; 
(f) in section 6, by striking ‘‘and Coast Guard,’’ and inserting in lieu 
thereof ‘‘Coast Guard, commissioned corps of the National Oceanic and 
Atmospheric Administration, and commissioned corps of the Public Health 
Service,’’; 
(g) in section 6, by inserting ‘‘, or who has been assigned to perform 
duties predominantly for the Vice President, in the implementation of Public 
Law 93–346, as amended, or in military units and support facilities to 
which section 1 of Executive Order 12793, as amended, refers,’’ after ‘‘Office 
of the Vice President’’; 
(h) in section 6, by inserting ‘‘, unless otherwise directed by the Director 
of the White House Military Office in the case of personnel in military 
units or support facilities to which section 1 of Executive Order 12793, 
as amended, refers,’’ after ‘‘is authorized’’; 
(i) in section 6, by inserting ‘‘or her’’ after ‘‘his’’; and 
(j) in section 6, by striking ‘‘first day of duty in the Office of the Vice 
President’’ and inserting in lieu thereof ‘‘first day of such duty’’.
- **ACT:EO:12793>EO:13373@05e0519a309fc70d**; Sc63997dc1f2d3b6770717b06; {"actor_id":"EO:13373","char_end":3664,"char_start":920,"confidence":"medium","effective_class":"on_signing","effective_date":null,"effective_wording":[],"exceptions_text":[],"filing_date":null,"id":"ACT:EO:12793>EO:13373@05e0519a309fc70d","names_target":true,"notes":"Machine lead only; no legal ending asserted. No express effective wording found; on_signing is an unconfirmed lead assumption; signing date is not asserted as an exact effective date.","provision_label":"Section 1.","reaches_target_via":"","savings_phrases":[],"scope":"partial","signing_date":"2005-03-10","target_id":"EO:12793","verb":"amend"}
- **ACT:EO:12793>EO:13373@c9742b861a3c5c03**; S602f6a5e5287bd9c420ba094; {"actor_id":"EO:13373","char_end":3017,"char_start":314,"confidence":"medium","effective_class":"on_signing","effective_date":null,"effective_wording":[],"exceptions_text":[],"filing_date":null,"id":"ACT:EO:12793>EO:13373@c9742b861a3c5c03","names_target":true,"notes":"Machine lead only; no legal ending asserted. No express effective wording found; on_signing is an unconfirmed lead assumption; signing date is not asserted as an exact effective date.","provision_label":"Section 1.","reaches_target_via":"","savings_phrases":[],"scope":"partial","signing_date":"2005-03-10","target_id":"EO:12793","verb":"amend"}
  Exact retained record text (unshared):
Executive Order 11926
of July 19, 1976, as amended by Executive Order 13286 of February 28,
2003, is further amended as follows:
(a) in section 1, by striking ‘‘and Coast Guard’’ and inserting in lieu
thereof ‘‘Coast Guard, commissioned corps of the National Oceanic and
Atmospheric Administration, and commissioned corps of the Public Health
Service’’;
(b) in section 1, by inserting ‘‘, or who have been assigned to perform
duties predominantly for the Vice President for a period of at least one
year subsequent to January 20, 2001, in the implementation of Public Law
93–346, as amended, or in military units and support facilities to which
section 1 of Executive Order 12793 of March 20, 1992, as amended, refers’’
immediately preceding the period;
(c) in section 2, by striking ‘‘Military Assistant to the Vice President’’
and inserting in lieu thereof ‘‘Vice President’s designee (with the concurrence
of the Director of the White House Military Office in the case of personnel
in military units or support facilities to which section 1 of Executive Order
12793, as amended, refers)’’;
(d) in section 2, by inserting ‘‘and, in the case of members of the commis-
sioned corps of the National Oceanic and Atmospheric Administration or
the commissioned corps of the Public Health Service so assigned, by the
Secretary of Commerce or the Secretary of Health and Human Services,
respectively’’ immediately preceding the period;
(e) in section 5, by adding at the end of the section ‘‘No award shall
be made to an individual under this Order based on a period of service
with respect to which, in whole or in part, the individual was awarded
the Presidential Service Badge.’’;
(f) in section 6, by striking ‘‘and Coast Guard,’’ and inserting in lieu
thereof ‘‘Coast Guard, commissioned corps of the National Oceanic and
Atmospheric Administration, and commissioned corps of the Public Health
Service,’’;
(g) in section 6, by inserting ‘‘, or who has been assigned to perform
duties predominantly for the Vice President, in the implementation of Public
Law 93–346, as amended, or in military units and support facilities to
which section 1 of Executive Order 12793, as amended, refers,’’ after ‘‘Office
of the Vice President’’;
(h) in section 6, by inserting ‘‘, unless otherwise directed by the Director
of the White House Military Office in the case of personnel in military
units or support facilities to which section 1 of Executive Order 12793,
as amended, refers,’’ after ‘‘is authorized’’;
(i) in section 6, by inserting ‘‘or her’’ after ‘‘his’’; and
(j) in section 6, by striking ‘‘first day of duty in the Office of the Vice
President’’ and inserting in lieu thereof ‘‘first day of such duty’’.
- **ACT:EO:12793>EO:13373@da54484b7b236af5**; Sbf0d20d958916f234babd443; {"actor_id":"EO:13373","char_end":3664,"char_start":920,"confidence":"medium","effective_class":"on_signing","effective_date":null,"effective_wording":[],"exceptions_text":[],"filing_date":null,"id":"ACT:EO:12793>EO:13373@da54484b7b236af5","names_target":true,"notes":"Machine lead only; no legal ending asserted. No express effective wording found; on_signing is an unconfirmed lead assumption; signing date is not asserted as an exact effective date.","provision_label":"Section 1.","reaches_target_via":"","savings_phrases":[],"scope":"partial","signing_date":"2005-03-10","target_id":"EO:12793","verb":"amend"}
- **ACT:EO:12793>EO:14131**; S80a00f7f9eb9fff406ce1f50; {"actor_id":"EO:14131","char_end":1426,"char_start":1012,"confidence":"medium","effective_class":"on_signing","effective_date":null,"effective_wording":[],"exceptions_text":[],"filing_date":null,"id":"ACT:EO:12793>EO:14131","names_target":true,"notes":"Machine lead only; no legal ending asserted. No express effective wording found; on_signing is an unconfirmed lead assumption; signing date is not asserted as an exact effective date. MULTIPLE_PROVISIONS: first located provision quoted; additional provisions require review.","provision_label":"Section 1 .","reaches_target_via":"","savings_phrases":[],"scope":"partial","signing_date":"2024-12-20","target_id":"EO:12793","verb":"transfer"}
  Exact retained record text (unshared):
Executive 
Order 12793 of March 20, 1992 (Continuing the Presidential Service Certifi-
cate and the Presidential Service Badge), as amended by Executive Order 
13286 of February 28, 2003 (Amendment of Executive Orders, and Other 
Actions, in Connection With the Transfer of Certain Functions to the Sec-
retary of Homeland Security), is further amended by: 
(a) Amending section 1 to read as follows: 
‘‘Section 1.
- **ACT:EO:12793>EO:14131@3ceb8647fb75d2ac**; S67326156efbb0f72450f03ba; {"actor_id":"EO:14131","char_end":620,"char_start":271,"confidence":"medium","effective_class":"on_signing","effective_date":null,"effective_wording":[],"exceptions_text":[],"filing_date":null,"id":"ACT:EO:12793>EO:14131@3ceb8647fb75d2ac","names_target":true,"notes":"Machine lead only; no legal ending asserted. No express effective wording found; on_signing is an unconfirmed lead assumption; signing date is not asserted as an exact effective date.","provision_label":"Section 1.","reaches_target_via":"","savings_phrases":[],"scope":"whole","signing_date":"2024-12-20","target_id":"EO:12793","verb":"transfer"}
  Exact retained record text (unshared):
Executive Order 12793 of March 20, 1992 (Continuing the Presidential Service Certificate and the Presidential Service Badge), as amended by Executive Order 13286 of February 28, 2003 (Amendment of Executive Orders, and Other Actions, in Connection With the Transfer of Certain Functions to the Secretary of Homeland Security), is further amended by:
- **ACT:EO:12793>EO:14131@411e3f263bf46af2**; S80a00f7f9eb9fff406ce1f50; {"actor_id":"EO:14131","char_end":1426,"char_start":1012,"confidence":"medium","effective_class":"on_signing","effective_date":null,"effective_wording":[],"exceptions_text":[],"filing_date":null,"id":"ACT:EO:12793>EO:14131@411e3f263bf46af2","names_target":true,"notes":"Machine lead only; no legal ending asserted. No express effective wording found; on_signing is an unconfirmed lead assumption; signing date is not asserted as an exact effective date. MULTIPLE_PROVISIONS: first located provision quoted; additional provisions require review.","provision_label":"Section 1 .","reaches_target_via":"","savings_phrases":[],"scope":"partial","signing_date":"2024-12-20","target_id":"EO:12793","verb":"transfer"}
- **ACT:EO:12793>EO:14131@83d93e72b9daa837**; S358ae0f0add704ca9237d781; {"actor_id":"EO:14131","char_end":1426,"char_start":1012,"confidence":"medium","effective_class":"on_signing","effective_date":null,"effective_wording":[],"exceptions_text":[],"filing_date":null,"id":"ACT:EO:12793>EO:14131@83d93e72b9daa837","names_target":true,"notes":"Machine lead only; no legal ending asserted. No express effective wording found; on_signing is an unconfirmed lead assumption; signing date is not asserted as an exact effective date. MULTIPLE_PROVISIONS: first located provision quoted; additional provisions require review.","provision_label":"Section 1 .","reaches_target_via":"","savings_phrases":[],"scope":"partial","signing_date":"2024-12-20","target_id":"EO:12793","verb":"transfer"}
- **ACT:EO:12793>EO:14131@e7de9a30112bbd6d**; S9d3becb814615b7a8224402c; {"actor_id":"EO:14131","char_end":811,"char_start":397,"confidence":"medium","effective_class":"on_signing","effective_date":null,"effective_wording":[],"exceptions_text":[],"filing_date":null,"id":"ACT:EO:12793>EO:14131@e7de9a30112bbd6d","names_target":true,"notes":"Machine lead only; no legal ending asserted. No express effective wording found; on_signing is an unconfirmed lead assumption; signing date is not asserted as an exact effective date. MULTIPLE_PROVISIONS: first located provision quoted; additional provisions require review.","provision_label":"Section 1 .","reaches_target_via":"","savings_phrases":[],"scope":"partial","signing_date":"2024-12-20","target_id":"EO:12793","verb":"transfer"}
- **ACTOR_TEXT:EO:13373**; Sbf0d20d958916f234babd443; {"actor_id":"EO:13373","char_end":4390,"char_start":0,"id":"ACTOR_TEXT:EO:13373","role":"actor_context"}
  Exact retained record text (unshared):
Instrument: EO:13373
Source: https://www.govinfo.gov/content/pkg/FR-2005-03-14/pdf/05-5097.pdf
SHA-256 of the downloaded file: 4a783e7a5b00b9fd4ee8db2b8c13b5627b0df63f71ff06a8a52d610085491c4f
Location: 70 FR 12579, PDF pages 1-2 (confidence high)
Machine-extracted text layer of the official PDF (OCR for 1936-1994 scans). May contain recognition errors and parts of neighbouring documents on the same pages. Not an authenticated transcription: check the PDF pages.

=== PDF page 1 of 2 ===
Presidential Documents
12579
Federal Register 
Vol. 70, No. 48
Monday, March 14, 2005
Title 3— 
The President 
Executive Order 13373 of March 10, 2005
Amendments to Executive Order 11926 Relating to the Vice 
Presidential Service Badge 
By the authority vested in me as President by the Constitution and the 
laws of the United States of America, it is hereby ordered as follows: 
Section 1. Amendments to Executive Order 11926. Executive Order 11926 
of July 19, 1976, as amended by Executive Order 13286 of February 28, 
2003, is further amended as follows: 
(a) in section 1, by striking ‘‘and Coast Guard’’ and inserting in lieu 
thereof ‘‘Coast Guard, commissioned corps of the National Oceanic and 
Atmospheric Administration, and commissioned corps of the Public Health 
Service’’; 
(b) in section 1, by inserting ‘‘, or who have been assigned to perform 
duties predominantly for the Vice President for a period of at least one 
year subsequent to January 20, 2001, in the implementation of Public Law 
93–346, as amended, or in military units and support facilities to which 
section 1 of Executive Order 12793 of March 20, 1992, as amended, refers’’ 
immediately preceding the period; 
(c) in section 2, by striking ‘‘Military Assistant to the Vice President’’ 
and inserting in lieu thereof ‘‘Vice President’s designee (with the concurrence 
of the Director of the White House Military Office in the case of personnel 
in military units or support facilities to which section 1 of Executive Order 
12793, as amended, refers)’’; 
(d) in section 2, by inserting ‘‘and, in the case of members of the commis-
sioned corps of the National Oceanic and Atmospheric Administration or 
the commissioned corps of the Public Health Service so assigned, by the 
Secretary of Commerce or the Secretary of Health and Human Services, 
respectively’’ immediately preceding the period; 
(e) in section 5, by adding at the end of the section ‘‘No award shall 
be made to an individual under this Order based on a period of service 
with respect to which, in whole or in part, the individual was awarded 
the Presidential Service Badge.’’; 
(f) in section 6, by striking ‘‘and Coast Guard,’’ and inserting in lieu 
thereof ‘‘Coast Guard, commissioned corps of the National Oceanic and 
Atmospheric Administration, and commissioned corps of the Public Health 
Service,’’; 
(g) in section 6, by inserting ‘‘, or who has been assigned to perform 
duties predominantly for the Vice President, in the implementation of Public 
Law 93–346, as amended, or in military units and support facilities to 
which section 1 of Executive Order 12793, as amended, refers,’’ after ‘‘Office 
of the Vice President’’; 
(h) in section 6, by inserting ‘‘, unless otherwise directed by the Director 
of the White House Military Office in the case of personnel in military 
units or support facilities to which section 1 of Executive Order 12793, 
as amended, refers,’’ after ‘‘is authorized’’; 
(i) in section 6, by inserting ‘‘or her’’ after ‘‘his’’; and 
(j) in section 6, by striking ‘‘first day of duty in the Office of the Vice 
President’’ and inserting in lieu thereof ‘‘first day of such duty’’. 
VerDate jul<14>2003 15:44 Mar 11, 2005 Jkt 205001 PO 00000 Frm 00003 Fmt 4705 Sfmt 4790 E:\FR\FM\14MRE0.SGM 14MRE0
=== PDF page 2 of 2 ===
12580 Federal Register / Vol. 70, No. 48 / Monday, March 14, 2005 / Presidential Documents 
Sec. 2. This order is not intended to, and does not, create any right or 
benefit, substantive or procedural, enforceable at law or in equity by any 
party against the United States, its departments, agencies, entities, officers, 
employees or agents, or any other person.
W
THE WHITE HOUSE, 
March 10, 2005. 
[FR Doc. 05 –5097
Filed 3 –11–05; 8:45 am] 
Billing code 3195 –01–P 
VerDate jul<14>2003 15:44 Mar 11, 2005 Jkt 205001 PO 00000 Frm 00004 Fmt 4705 Sfmt 4790 E:\FR\FM\14MRE0.SGM 14MRE0
- **ACTOR_TEXT:EO:14131**; S80a00f7f9eb9fff406ce1f50; {"actor_id":"EO:14131","char_end":7943,"char_start":0,"id":"ACTOR_TEXT:EO:14131","role":"actor_context"}
  Exact retained record text (unshared):
Instrument: EO:14131
Source: https://www.govinfo.gov/content/pkg/FR-2024-12-27/pdf/2024-31355.pdf
SHA-256 of the downloaded file: 0cc709cf35c2ed46523e8c88e6d0d26596377ea945d7c3ed458c7dd3c48db88f
Location: 89 FR 105377, PDF pages 1-3 (confidence high)
Machine-extracted text layer of the official PDF (OCR for 1936-1994 scans). May contain recognition errors and parts of neighbouring documents on the same pages. Not an authenticated transcription: check the PDF pages.

=== PDF page 1 of 3 ===
Presidential Documents
105377 Federal Register / Vol. 89, No. 248 / Friday, December 27, 2024 / Presidential Documents 
Executive Order 14131 of December 20, 2024 
Amendments to Executive Orders Relating to Certain Certifi-
cates and Badges 
By the authority vested in me as President by the Constitution and the 
laws of the United States of America, and as Commander in Chief of the 
Armed Forces of the United States, it is hereby ordered as follows: 
Section 1 . Amendments to Executive Order 12793, as Amended . Executive 
Order 12793 of March 20, 1992 (Continuing the Presidential Service Certifi-
cate and the Presidential Service Badge), as amended by Executive Order 
13286 of February 28, 2003 (Amendment of Executive Orders, and Other 
Actions, in Connection With the Transfer of Certain Functions to the Sec-
retary of Homeland Security), is further amended by: 
(a) Amending section 1 to read as follows: 
‘‘Section 1. Presidential Service Certificate. The Presidential Service Certifi-
cate (Certificate) is hereby continued, the design of which accompanies 
and is hereby made a part of this order. The Certificate shall be awarded 
in the name of the President of the United States to members of the 
United States Uniformed Services who have been assigned to the White 
House Office; to military units and support facilities under the administra-
tion of the White House Military Office; or to other direct support positions 
within the Executive Office of the President (EOP). The Certificate shall 
be awarded by the Secretary of the military department concerned, or, 
when the Coast Guard is not operating as a service in the Navy, by 
the Secretary of Homeland Security, and, in the case of members of 
the Commissioned Corps of the National Oceanic and Atmospheric Admin-
istration or the Commissioned Corps of the Public Health Service, by 
the Secretary of Commerce or the Secretary of Health and Human Services, 
respectively. The Certificate shall not be issued to any member who is 
issued a Vice Presidential Certificate, or similar EOP Certificate, for the 
same period of service. Such assignment must be for a period of at least 
1 year, subsequent to January 21, 1989.’’; and 
(b) Amending section 2 to read as follows: 
‘‘Sec. 2. Presidential Service Badge. The Presidential Service Badge (Badge) 
is hereby continued, the design of which accompanies and is hereby 
made a part of this order. The Badge shall be awarded to those members 
of the United States Uniformed Services who have been granted the Certifi-
cate and shall be awarded in the same manner in which the Certificate 
has been given. The Badge shall be worn as a part of the uniform of 
those individuals under such regulations as their respective Secretaries 
may severally prescribe.’’. 
Sec. 2 . Amendments to Executive Order 11926, as Amended . Executive 
Order 11926 of July 19, 1976 (The Vice Presidential Service Badge), as 
amended by Executive Order 13286 and by Executive Order 13373 of March 
10, 2005 (Amendments to Executive Order 11926 Relating to the Vice Presi-
dential Service Badge), is further amended by: 
(a) Amending section 1 to read as follows: 
‘‘Section 1 . There is established a Vice Presidential Service Badge to 
be awarded in the name of the Vice President of the United States of 
America to members of the United States Uniformed Services who have 
been assigned to duty in the Office of the Vice President for a period 
of at least 1 year subsequent to December 19, 1974, or who have been 
VerDate Sep<11>2014 03:41 Dec 27, 2024 Jkt 265001 PO 00000 Frm 00001 Fmt 4790 Sfmt 4790 E:\FR\FM\27DEE1.SGM 27DEE1tkelley on LAP7H3WLY3PROD with EO
=== PDF page 2 of 3 ===
105378 Federal Register / Vol. 89, No. 248 / Friday, December 27, 2024 / Presidential Documents 
assigned to perform duties predominantly for the Vice President for a 
period of at least 1 year subsequent to January 20, 2001, in the implementa-
tion of Public Law 93–346, as amended, or in military units and support 
facilities to which section 1 of Executive Order 12793 of March 20, 1992, 
as amended, refers.’’; 
(b) Amending section 2 to read as follows: 
‘‘Sec. 2 . The Vice Presidential Service Badge may be awarded, upon rec-
ommendation of the Vice President’s designee (with the concurrence of 
the Director of the White House Military Office in the case of personnel 
in military units or support facilities to which section 1 of Executive 
Order 12793, as amended, refers), by the Secretary of the military depart-
ment concerned, or, when the Coast Guard is not operating as a service 
in the Navy, by the Secretary of Homeland Security, to military personnel 
of their respective services who have been assigned to duty in the Office 
of the Vice President and, in the case of members of the Commissioned 
Corps of the National Oceanic and Atmospheric Administration or the 
Commissioned Corps of the Public Health Service so assigned, by the 
Secretary of Commerce or the Secretary of Health and Human Services, 
respectively.’’; 
(c) Amending section 4 to read as follows: 
‘‘Sec. 4 . Upon award, the Vice Presidential Service Badge may be worn 
as a part of the uniform of an individual both during and after their 
assignment to duty in the Office of the Vice President.’’; and 
(d) Amending section 6 to read as follows: 
‘‘Sec. 6. Notwithstanding the provisions of sections 1 and 2 of this order, 
any member of the United States Uniformed Services, who has been 
assigned to duty in the Office of the Vice President, or who has been 
assigned to perform duties predominantly for the Vice President, in the 
implementation of Public Law 93–346, as amended, or in military units 
and support facilities to which section 1 of Executive Order 12793, as 
amended, refers, is authorized, unless otherwise directed by the Director 
of the White House Military Office in the case of personnel in military 
units and support facilities to which section 1 of Executive Order 12793, 
as amended, refers, to wear the Vice Presidential Service Badge on their 
uniform commencing on the first day of such duty and thereafter while 
assigned to such duty.’’. 
Sec. 3 . General Provisions . (a) Nothing in this order shall be construed 
to impair or otherwise affect: 
(i) the authority granted by law to an executive department or agency, 
or the head thereof; or 
(ii) the functions of the Director of the Office of Management and Budget 
relating to budgetary, administrative, or legislative proposals. 
(b) This order shall be implemented consistent with applicable law and 
subject to the availability of appropriations. 
VerDate Sep<11>2014 03:41 Dec 27, 2024 Jkt 265001 PO 00000 Frm 00002 Fmt 4790 Sfmt 4790 E:\FR\FM\27DEE1.SGM 27DEE1tkelley on LAP7H3WLY3PROD with EO
=== PDF page 3 of 3 ===
105379 Federal Register / Vol. 89, No. 248 / Friday, December 27, 2024 / Presidential Documents 
(c) This order is not intended to, and does not, create any right or benefit, 
substantive or procedural, enforceable at law or in equity by any party 
against the United States, its departments, agencies, or entities, its officers, 
employees, or agents, or any other person. 
THE WHITE HOUSE, 
December 20, 2024. 
[FR Doc. 2024–31355 
Filed 12–26–24; 8:45 am] 
Billing code 3395–F4–P 
VerDate Sep<11>2014 03:41 Dec 27, 2024 Jkt 265001 PO 00000 Frm 00003 Fmt 4790 Sfmt 4790 E:\FR\FM\27DEE1.SGM 27DEE1
BIDEN.EPS</GPH>
tkelley on LAP7H3WLY3PROD with EO
- **CLAUSES:EO:12793#sec1**; S36c1f245954f1176438ebcb0; {"char_end":2077,"char_start":956,"id":"CLAUSES:EO:12793#sec1","kind":"section","label":"Section 1 .","pdf_page":11,"scope_id":"EO:12793#sec1"}
  Text: [T1f161e57f49a0d32d2cf1557](#t1f161e57f49a0d32d2cf1557); absolute characters 956–2077
- **CLAUSES:EO:12793#sec2**; S36c1f245954f1176438ebcb0; {"char_end":2596,"char_start":2078,"id":"CLAUSES:EO:12793#sec2","kind":"section","label":"Sec. 2.","pdf_page":11,"scope_id":"EO:12793#sec2"}
  Text: [T1f161e57f49a0d32d2cf1557](#t1f161e57f49a0d32d2cf1557); absolute characters 2078–2596
- **CLAUSES:EO:12793#sec3**; S36c1f245954f1176438ebcb0; {"char_end":2658,"char_start":2597,"id":"CLAUSES:EO:12793#sec3","kind":"section","label":"Sec. 3.","pdf_page":11,"scope_id":"EO:12793#sec3"}
  Text: [T1f161e57f49a0d32d2cf1557](#t1f161e57f49a0d32d2cf1557); absolute characters 2597–2658
- **CLAUSES:EO:12793#sec4**; S36c1f245954f1176438ebcb0; {"char_end":2725,"char_start":2659,"id":"CLAUSES:EO:12793#sec4","kind":"section","label":"Sec. 4.","pdf_page":11,"scope_id":"EO:12793#sec4"}
  Text: [T1f161e57f49a0d32d2cf1557](#t1f161e57f49a0d32d2cf1557); absolute characters 2659–2725
- **CLAUSES:EO:12793#sec5**; S36c1f245954f1176438ebcb0; {"char_end":2848,"char_start":2726,"id":"CLAUSES:EO:12793#sec5","kind":"section","label":"Sec. 5.","pdf_page":11,"scope_id":"EO:12793#sec5"}
  Text: [T1f161e57f49a0d32d2cf1557](#t1f161e57f49a0d32d2cf1557); absolute characters 2726–2848
- **ORIGINAL:EO:12793**; S36c1f245954f1176438ebcb0; {"acceptable_as_original":true,"actor_id":"EO:12793","char_end":17080,"char_start":0,"grade":"original_representation_unverified","id":"ORIGINAL:EO:12793","location_confidence":"high","requires_page_check":false,"role":"original","signing_date":"1992-03-20"}
  Text: [T1f161e57f49a0d32d2cf1557](#t1f161e57f49a0d32d2cf1557); absolute characters 0–17080
- **TERM:EO:12793:7015a2a82582449f@7f0a7b05ae4d296e**; S9b3b45f29833e6fa2a935389; {"actor_id":"EO:12793","char_end":2077,"char_start":1986,"computed_end_candidate":null,"confidence":"medium","effective_date":null,"id":"TERM:EO:12793:7015a2a82582449f@7f0a7b05ae4d296e","instrument_id":"EO:12793","kind":"fixed_term","mechanism":"own_terms_fixed_term","note":"A report deadline never yields an end candidate; month-end anniversary ambiguity remains unresolved.","notes":"Machine wording lead; no cessation or occurrence inferred.","scope_id":"EO:12793#sec1","start_date":null,"stated_end_date":null}
  Text: [T1f161e57f49a0d32d2cf1557](#t1f161e57f49a0d32d2cf1557); absolute characters 1986–2077
- **TERM:EO:12793:d89a6daa64b549b5@6ef768f38f8da6dd**; S134d196bd44a7e2cf36d00f9; {"actor_id":"EO:12793","char_end":1399,"char_start":1309,"computed_end_candidate":null,"confidence":"medium","effective_date":"1989-01-21","id":"TERM:EO:12793:d89a6daa64b549b5@6ef768f38f8da6dd","instrument_id":"EO:12793","kind":"fixed_term","mechanism":"own_terms_fixed_term","note":"A report deadline never yields an end candidate; month-end anniversary ambiguity remains unresolved.","notes":"Machine wording lead; no cessation or occurrence inferred.","scope_id":"EO:12793#sec1","start_date":null,"stated_end_date":"1989-01-21"}
  Exact retained record text (unshared):
Such assignment must be for a period of at least one year, subsequent to January 21, 1989.
- **TERM:EO:12793:d89a6daa64b549b5@edbd6b17be579a26**; S786f3ec252835cd535dd2153; {"actor_id":"EO:12793","char_end":1293,"char_start":1203,"computed_end_candidate":null,"confidence":"medium","effective_date":"1989-01-21","id":"TERM:EO:12793:d89a6daa64b549b5@edbd6b17be579a26","instrument_id":"EO:12793","kind":"fixed_term","mechanism":"own_terms_fixed_term","note":"A report deadline never yields an end candidate; month-end anniversary ambiguity remains unresolved.","notes":"Machine wording lead; no cessation or occurrence inferred.","scope_id":"EO:12793#sec1","start_date":null,"stated_end_date":"1989-01-21"}

### Complete operative inventory

- EO:12793#sec1 → CLAUSES:EO:12793#sec1; characters 956–2077
- EO:12793#sec2 → CLAUSES:EO:12793#sec2; characters 2078–2596
- EO:12793#sec3 → CLAUSES:EO:12793#sec3; characters 2597–2658
- EO:12793#sec4 → CLAUSES:EO:12793#sec4; characters 2659–2725
- EO:12793#sec5 → CLAUSES:EO:12793#sec5; characters 2726–2848

### own_terms

["TERM:EO:12793:7015a2a82582449f@7f0a7b05ae4d296e","TERM:EO:12793:d89a6daa64b549b5@edbd6b17be579a26","TERM:EO:12793:d89a6daa64b549b5@6ef768f38f8da6dd"]

### actor_contexts

[{"actor_id":"EO:13286","overflow":"actor-texts/EO_13286.json","text_sha256":"57b106e01d54e1bcf61065a73a3591003b50eef2d8d0f65b0b54f98ea436e6df"},{"actor_id":"EO:13373","evidence_id":"ACTOR_TEXT:EO:13373"},{"actor_id":"EO:14131","evidence_id":"ACTOR_TEXT:EO:14131"}]

### actor_provisions

["ACT:EO:12793>EO:13286","ACT:EO:12793>EO:13286@1f07c88d0efe40c8","ACT:EO:12793>EO:13286@6c0146167ca9b5a6","ACT:EO:12793>EO:13373","ACT:EO:12793>EO:13373@da54484b7b236af5","ACT:EO:12793>EO:13373@05e0519a309fc70d","ACT:EO:12793>EO:13373@c9742b861a3c5c03","ACT:EO:12793>EO:14131","ACT:EO:12793>EO:14131@411e3f263bf46af2","ACT:EO:12793>EO:14131@83d93e72b9daa837","ACT:EO:12793>EO:14131@3ceb8647fb75d2ac","ACT:EO:12793>EO:14131@e7de9a30112bbd6d"]

### chain

{"confidence":"medium","events":[{"actor_id":"EO:13286","char_end":22077,"char_start":21816,"confidence":"medium","how_named":"direct","id":"CHAIN:EO:12793#1","notes":"Change wording lead; chronology does not decide legal effect.","provision_text":"Executive Order 12793 of March 20, 1992 (\"Continuing the Presidential Service Certificate and Presidential Service Badge\"), is amended by striking \"the Secretary of Transportation\" in section 1 and inserting \"the Secretary of Homeland Security\" in lieu thereof.","sections_touched":["section 1"],"signing_date":"2003-02-28","source":{"acceptable_as_original":false,"archival_id":"app:node/217113","filing_date":null,"grade":"mirror_transcription","instrument_id":"EO:13286","location_confidence":"medium","location_verified":false,"page_or_item":"Executive Order 13286—Amendment of Executive Orders, and Other Actions, in Connection With the Transfer of Certain Functions to the Secretary of Homeland Security; February 28, 2003; APP node 217113; common-crawl capture 2025-10-06T18:03:47Z","requires_page_check":true,"sha256":"c1a2aff53be0c95cb97e0871e389a3b185ae165f6dd9a539722ed1c45f135c34","signing_date":"2003-02-28","text_path":"jobs/app-executive-orders/output/texts/executive-order-13286-amendment-executive-orders-and-other-actions-connection-with-the.txt","text_sha256":"d24268c163cd19e82bda1102e745709657d237c65d627f55716beebc42ba94f0","url":"https://www.presidency.ucsb.edu/documents/executive-order-13286-amendment-executive-orders-and-other-actions-connection-with-the"},"verb":"amend"},{"actor_id":"EO:13373","char_end":3664,"char_start":920,"confidence":"medium","how_named":"direct","id":"CHAIN:EO:12793#2","notes":"Change wording lead; chronology does not decide legal effect.","provision_text":"Executive Order 11926 \nof July 19, 1976, as amended by Executive Order 13286 of February 28, \n2003, is further amended as follows: \n(a) in section 1, by striking ‘‘and Coast Guard’’ and inserting in lieu \nthereof ‘‘Coast Guard, commissioned corps of the National Oceanic and \nAtmospheric Administration, and commissioned corps of the Public Health \nService’’; \n(b) in section 1, by inserting ‘‘, or who have been assigned to perform \nduties predominantly for the Vice President for a period of at least one \nyear subsequent to January 20, 2001, in the implementation of Public Law \n93–346, as amended, or in military units and support facilities to which \nsection 1 of Executive Order 12793 of March 20, 1992, as amended, refers’’ \nimmediately preceding the period; \n(c) in section 2, by striking ‘‘Military Assistant to the Vice President’’ \nand inserting in lieu thereof ‘‘Vice President’s designee (with the concurrence \nof the Director of the White House Military Office in the case of personnel \nin military units or support facilities to which section 1 of Executive Order \n12793, as amended, refers)’’; \n(d) in section 2, by inserting ‘‘and, in the case of members of the commis-\nsioned corps of the National Oceanic and Atmospheric Administration or \nthe commissioned corps of the Public Health Service so assigned, by the \nSecretary of Commerce or the Secretary of Health and Human Services, \nrespectively’’ immediately preceding the period; \n(e) in section 5, by adding at the end of the section ‘‘No award shall \nbe made to an individual under this Order based on a period of service \nwith respect to which, in whole or in part, the individual was awarded \nthe Presidential Service Badge.’’; \n(f) in section 6, by striking ‘‘and Coast Guard,’’ and inserting in lieu \nthereof ‘‘Coast Guard, commissioned corps of the National Oceanic and \nAtmospheric Administration, and commissioned corps of the Public Health \nService,’’; \n(g) in section 6, by inserting ‘‘, or who has been assigned to perform \nduties predominantly for the Vice President, in the implementation of Public \nLaw 93–346, as amended, or in military units and support facilities to \nwhich section 1 of Executive Order 12793, as amended, refers,’’ after ‘‘Office \nof the Vice President’’; \n(h) in section 6, by inserting ‘‘, unless otherwise directed by the Director \nof the White House Military Office in the case of personnel in military \nunits or support facilities to which section 1 of Executive Order 12793, \nas amended, refers,’’ after ‘‘is authorized’’; \n(i) in section 6, by inserting ‘‘or her’’ after ‘‘his’’; and \n(j) in section 6, by striking ‘‘first day of duty in the Office of the Vice \nPresident’’ and inserting in lieu thereof ‘‘first day of such duty’’.","sections_touched":["section 1","section 1","section 1","section 2","section 1","section 2","section 5","section 6","section 6","section 1","section 6","section 1","section 6","section 6"],"signing_date":"2005-03-10","source":{"filing_date":null,"location_confidence":"high","location_verified":false,"page_or_item":"70 FR 12579, PDF pages 1-2","requires_page_check":false,"sha256":"4a783e7a5b00b9fd4ee8db2b8c13b5627b0df63f71ff06a8a52d610085491c4f","signing_date":"2005-03-10","text_path":"jobs/fr-originals/data/full_run/texts/EO_13373.txt","text_sha256":"b93d23e0bb50c539234a7ebb7febee5bd63e9a584274c71fd2d7a498bc163fe8","url":"https://www.govinfo.gov/content/pkg/FR-2005-03-14/pdf/05-5097.pdf"},"verb":"amend"},{"actor_id":"EO:14131","char_end":1426,"char_start":1012,"confidence":"medium","how_named":"direct","id":"CHAIN:EO:12793#3","notes":"Change wording lead; chronology does not decide legal effect.","provision_text":"Executive \nOrder 12793 of March 20, 1992 (Continuing the Presidential Service Certifi-\ncate and the Presidential Service Badge), as amended by Executive Order \n13286 of February 28, 2003 (Amendment of Executive Orders, and Other \nActions, in Connection With the Transfer of Certain Functions to the Sec-\nretary of Homeland Security), is further amended by: \n(a) Amending section 1 to read as follows: \n‘‘Section 1.","sections_touched":["section 1","Section 1"],"signing_date":"2024-12-20","source":{"filing_date":null,"location_confidence":"high","location_verified":false,"page_or_item":"89 FR 105377, PDF pages 1-3","requires_page_check":false,"sha256":"0cc709cf35c2ed46523e8c88e6d0d26596377ea945d7c3ed458c7dd3c48db88f","signing_date":"2024-12-20","text_path":"jobs/fr-originals/data/full_run/texts/EO_14131.txt","text_sha256":"40d6973a87db31e3fd2361307980b3248abd3b76dfcf1a74a34b57732042648c","url":"https://www.govinfo.gov/content/pkg/FR-2024-12-27/pdf/2024-31355.pdf"},"verb":"transfer"}],"generic_refs_excluded":221,"id":"CHAIN:EO:12793","notes":"Named, located change provisions only; missing provisions and unheld texts remain dossier gaps. Undated events sort last.","target_id":"EO:12793"}

### current_law_leads

[{"basis_code":"printed_eo_text","checked_through":"2026-10-09","currency_code":"usc_release_point","edition":"U.S. Code release point 119-121","evidence_gap":"No uniquely located attributed legal-text slice is held for this current-law pointer; serialized JSON/JSONL, snippets and absent cache artifacts are not legal-text evidence.","fragment_kind":"current_predicate_candidates","input_origin":"jobs/current-law/output/FRAGMENTS.jsonl","instrument_id":"EO:12793","legal_basis_candidate":"U.S. Code prints the order's text as a note, with no ending statement (10 U.S.C. subtitle A, pt. II, ch. 57 note)","machine_lead":true,"mention_id":"usc:4ae8fc75c675","snippet":"Ex. Ord. No. 12793. Presidential Service Certificate and Presidential Service Badge | Ex. Ord. No. 12793, Mar. 20, 1992, 57 F.R. 10281, as amended by Ex. Ord. No. 13286, § 31, Feb. 28, 2003, 68 F.R. 10625; Ex. Ord. No. 14131, § 1, Dec. 20, 2024, 89 F.R. 105377, provided:","source":{"page_or_item":"10 U.S.C. subtitle A, pt. II, ch. 57 note; note 'Ex. Ord. No. 12793. Presidential Service Certificate and Presidential Service Badge' [USLM note id ida8989a5a-3a6f-11f1-a58a-d8db54b14ab5]; usc10.xml (sha256 f6b1a4f0897cd19431abb8af52cf3aafb02cf6e1870f0f6b5d1992c37fe128b6) in xml_uscAll@119-121.zip","sha256":"c6122974e951003437ece5a998aa7c0b2cdc0f5703dfc78d6135e1fc9e729142","url":"https://uscode.house.gov/download/releasepoints/us/pl/119/121/xml_uscAll@119-121.zip"},"system":"usc","text_path":"USC_EO_NOTES.jsonl#note_id=ida8989a5a-3a6f-11f1-a58a-d8db54b14ab5","where":"USC 10 U.S.C. subtitle A, pt. II, ch. 57 note"},{"custody_records_in":["current-law"],"evidence_gap":"Current-law lead lacks an original-source sha256.","meta":{"basis_code":"printed_eo_text","caution":"a mention in current law is a LEAD, not by itself a legal basis; read the provision to see whether it keeps the order operating","currency_code":"usc_release_point","edition":"U.S. Code release point 119-121","from":"current-law@jobs/current-law/output","from_job":"current-law","mention_id":"usc:4ae8fc75c675","snippet":"Ex. Ord. No. 12793. Presidential Service Certificate and Presidential Service Badge | Ex. Ord. No. 12793, Mar. 20, 1992, 57 F.R. 10281, as amended by Ex. Ord. No. 13286, § 31, Feb. 28, 2003, 68 F.R. 10625; Ex. Ord. No. 14131, § 1, Dec. 20, 2024, 89 F.R. 105377, provided:","snippet_truncated":false,"system":"usc","text_path":"USC_EO_NOTES.jsonl#note_id=ida8989a5a-3a6f-11f1-a58a-d8db54b14ab5","where":"USC 10 U.S.C. subtitle A, pt. II, ch. 57 note"},"proposal":{"checked_through":"2026-10-09","legal_basis":"U.S. Code prints the order's text as a note, with no ending statement (10 U.S.C. subtitle A, pt. II, ch. 57 note)","source":{"page_or_item":"10 U.S.C. subtitle A, pt. II, ch. 57 note; note 'Ex. Ord. No. 12793. Presidential Service Certificate and Presidential Service Badge' [USLM note id ida8989a5a-3a6f-11f1-a58a-d8db54b14ab5]; usc10.xml (sha256 f6b1a4f0897cd19431abb8af52cf3aafb02cf6e1870f0f6b5d1992c37fe128b6) in xml_uscAll@119-121.zip","sha256":"c6122974e951003437ece5a998aa7c0b2cdc0f5703dfc78d6135e1fc9e729142","url":"https://uscode.house.gov/download/releasepoints/us/pl/119/121/xml_uscAll@119-121.zip"}}}]

### machine_searches

[{"complete":true,"entry":{"checked_on":"2026-10-17","query_or_scope":"every citation of this order by number (forms 'Executive Order', 'Ex. Ord.', 'E.O.') in the text and notes of the titles read; edition current through 2026-10-09 (laws enacted after that date and on or before 2026-10-14 are not reflected)","repository":"U.S. Code, Office of the Law Revision Counsel release point 119-121 (USLM XML, 58 title files), statute text and editorial notes","searched_by":"jobs/current-law (machine search)"},"machine_hits_for_this_order":3,"scope_note":"","search_id":"current-law:usc"},{"complete":true,"entry":{"checked_on":"2026-10-17","query_or_scope":"full-text search for 'Executive Order', 'Executive Orders', 'E.O.', 'Ex. Ord.', 'Exec. Order' and regulation text, authority and source citations naming this order","repository":"eCFR point-in-time search as of 2026-10-14 and GovInfo CFR bulk XML (49 titles read)","searched_by":"jobs/current-law (machine search)"},"machine_hits_for_this_order":3,"scope_note":"","search_id":"current-law:ecfr"},{"complete":true,"entry":{"checked_on":"2026-10-19","query_or_scope":"disposition notes of 6938 catalog records (1937 onward) naming this order as amended, revoked, superseded or otherwise affected, plus operative sentences in 17521 saved order texts","repository":"Federal Register executive-order catalog (federalregister.gov API v1, include_pre_1994_docs=true): Office of the Federal Register disposition notes","searched_by":"jobs/later-events (machine search)"},"machine_hits_for_this_order":2,"scope_note":"","search_id":"later-events:ofr_catalog"}]

### draft_gate_errors

["clause_0_state","clause_1_state","clause_2_state","clause_3_state","clause_4_state","clause_5_state","yes_without_continuing_clause","savings_residuals_evidence","bounded_later_search","unresolved_material_gaps","research_rationale"]

### conflicts

[]

### draft_material_gaps

["DRAFT: state_at_cutoff not decided for 6 clause(s); clause inventory completeness not confirmed","DRAFT: current legal basis not established","DRAFT: savings and residual effects not closed","DRAFT: later_source_search not recorded (machine searches are proposals only; paste them after judging them adequate and resolving every CONFLICT line)"]

### missing

["Current legal predicate and coverage through 2026-10-14 require judgment; a citation or 1989 snapshot cannot prove continuation.","Current-law lead lacks an original-source sha256.","Large actor context must be read at actor-texts/EO_13286.json before deciding scope/savings.","No uniquely located attributed legal-text slice is held for this current-law pointer; serialized JSON/JSONL, snippets and absent cache artifacts are not legal-text evidence."]

### status_history

{"event_count":2,"fingerprint":"718fb7b1a097fb877bf0ad0dbbc1d570b7ff3f35dd0a5df1ae7a20a8777370bc","flags":[],"history_path":"jobs/status-history/output/histories/EO_12793.json","history_sha256":"9b0604a75be7dc629fe1bea626d33257572035645b0eba355d6c8d07513942af","input_origin":"jobs/status-history/output/FRAGMENTS.jsonl","legal_cutoff":"2026-10-14","machine_lead":true,"notice":"Editorial leads, not an original, legal conclusion, provisional-status assignment or human certification.","observation_count":1}

### notice

"MACHINE LEADS ONLY. No segmentation, date, source grade, family or chain is a legal conclusion."

### Additional dossier metadata

{"lifecycle_obligations":[{"clause_sha256":"67cbf74d08b741c8913be350e06b46691573a188c3932042df786898e75ea4bf","established_ending":null,"human_certified":false,"instrument_id":"EO:12793","later_actor_evidence_ids":[],"own_term_evidence_ids":["TERM:EO:12793:7015a2a82582449f@7f0a7b05ae4d296e","TERM:EO:12793:d89a6daa64b549b5@edbd6b17be579a26","TERM:EO:12793:d89a6daa64b549b5@6ef768f38f8da6dd"],"questions":["Determine the first cessation or current predicate for this scope; check independent commands and surviving effects.","Distinguish the due date, demonstrated performance, and continuing duties. Establish occurrence from evidence and explain its effect on this clause.","Confirm the relevant event or operative sunset, scope, extensions and renewals; a detected date remains a candidate."],"schema":"eo-lifecycle-obligation/v1","scope_id":"EO:12793#sec1","state":"requires_clause_specific_research","wording_features":["actual_performance_lead","fixed_term"]},{"clause_sha256":"daf6de6c8be6210fd2cffc97fb449dbaad457032170c8ca3adf58afefceeda98","established_ending":null,"human_certified":false,"instrument_id":"EO:12793","later_actor_evidence_ids":[],"own_term_evidence_ids":[],"questions":["Determine the first cessation or current predicate for this scope; check independent commands and surviving effects."],"schema":"eo-lifecycle-obligation/v1","scope_id":"EO:12793#sec2","state":"requires_clause_specific_research","wording_features":[]},{"clause_sha256":"914a0a98f1d5db9aea82ad6eeb624941a5728d8e11aac60b92cd2c1783ee89b7","established_ending":null,"human_certified":false,"instrument_id":"EO:12793","later_actor_evidence_ids":[],"own_term_evidence_ids":[],"questions":["Determine the first cessation or current predicate for this scope; check independent commands and surviving effects."],"schema":"eo-lifecycle-obligation/v1","scope_id":"EO:12793#sec3","state":"requires_clause_specific_research","wording_features":[]},{"clause_sha256":"13489b332575fc180ea613eaefaaff55c25901c7c1158f4a1f0f6861f3f03f00","established_ending":null,"human_certified":false,"instrument_id":"EO:12793","later_actor_evidence_ids":[],"own_term_evidence_ids":[],"questions":["Determine the first cessation or current predicate for this scope; check independent commands and surviving effects."],"schema":"eo-lifecycle-obligation/v1","scope_id":"EO:12793#sec4","state":"requires_clause_specific_research","wording_features":[]},{"clause_sha256":"4fa62a149a927610285dd5409935d870769aaec0fb8e8fc3d3b9d5772b1f4cbf","established_ending":null,"human_certified":false,"instrument_id":"EO:12793","later_actor_evidence_ids":[],"own_term_evidence_ids":[],"questions":["Determine the first cessation or current predicate for this scope; check independent commands and surviving effects."],"schema":"eo-lifecycle-obligation/v1","scope_id":"EO:12793#sec5","state":"requires_clause_specific_research","wording_features":[]}]}

### Preflight

{"custody_validation":"required_from_actual_claim_checker","decisions_still_required":["complete original/inventory","earlier ending","partial scope and effective date","independent commands","savings/residuals","contrary evidence and cutoff predicate"],"evidence_preflight":"blocked_or_research","held_text_receipts":{"jobs/fr-originals/data/full_run/texts/EO_12793.txt":{"characters":17080,"raw_custody":"requires_actual_claim_checker","source_sha256":"177bb2a72d99588b007092bda114812034f8b8a95afc7d79ccb7992d0c1876f1","text_sha256":"7f0a7b05ae4d296e75eb23cc4c90e93ff9735a80adae5215dc5c54099bd32956"}},"instrument_id":"EO:12793","lifecycle_obligations":[{"clause_sha256":"67cbf74d08b741c8913be350e06b46691573a188c3932042df786898e75ea4bf","established_ending":null,"human_certified":false,"instrument_id":"EO:12793","later_actor_evidence_ids":[],"own_term_evidence_ids":["TERM:EO:12793:7015a2a82582449f@7f0a7b05ae4d296e","TERM:EO:12793:d89a6daa64b549b5@edbd6b17be579a26","TERM:EO:12793:d89a6daa64b549b5@6ef768f38f8da6dd"],"questions":["Determine the first cessation or current predicate for this scope; check independent commands and surviving effects.","Distinguish the due date, demonstrated performance, and continuing duties. Establish occurrence from evidence and explain its effect on this clause.","Confirm the relevant event or operative sunset, scope, extensions and renewals; a detected date remains a candidate."],"schema":"eo-lifecycle-obligation/v1","scope_id":"EO:12793#sec1","state":"requires_clause_specific_research","wording_features":["actual_performance_lead","fixed_term"]},{"clause_sha256":"daf6de6c8be6210fd2cffc97fb449dbaad457032170c8ca3adf58afefceeda98","established_ending":null,"human_certified":false,"instrument_id":"EO:12793","later_actor_evidence_ids":[],"own_term_evidence_ids":[],"questions":["Determine the first cessation or current predicate for this scope; check independent commands and surviving effects."],"schema":"eo-lifecycle-obligation/v1","scope_id":"EO:12793#sec2","state":"requires_clause_specific_research","wording_features":[]},{"clause_sha256":"914a0a98f1d5db9aea82ad6eeb624941a5728d8e11aac60b92cd2c1783ee89b7","established_ending":null,"human_certified":false,"instrument_id":"EO:12793","later_actor_evidence_ids":[],"own_term_evidence_ids":[],"questions":["Determine the first cessation or current predicate for this scope; check independent commands and surviving effects."],"schema":"eo-lifecycle-obligation/v1","scope_id":"EO:12793#sec3","state":"requires_clause_specific_research","wording_features":[]},{"clause_sha256":"13489b332575fc180ea613eaefaaff55c25901c7c1158f4a1f0f6861f3f03f00","established_ending":null,"human_certified":false,"instrument_id":"EO:12793","later_actor_evidence_ids":[],"own_term_evidence_ids":[],"questions":["Determine the first cessation or current predicate for this scope; check independent commands and surviving effects."],"schema":"eo-lifecycle-obligation/v1","scope_id":"EO:12793#sec4","state":"requires_clause_specific_research","wording_features":[]},{"clause_sha256":"4fa62a149a927610285dd5409935d870769aaec0fb8e8fc3d3b9d5772b1f4cbf","established_ending":null,"human_certified":false,"instrument_id":"EO:12793","later_actor_evidence_ids":[],"own_term_evidence_ids":[],"questions":["Determine the first cessation or current predicate for this scope; check independent commands and surviving effects."],"schema":"eo-lifecycle-obligation/v1","scope_id":"EO:12793#sec5","state":"requires_clause_specific_research","wording_features":[]}],"mechanical_tasks":[{"availability":"held_not_loaded","instrument_id":"EO:12793","kind":"load_actor_overflow","reason":"Read full overflow before scope/savings decision","shared_key":"EO:13286","task_id":"TASK:84afaf7b7ab986f33b60241f"},{"availability":"citation_or_pointer_only","instrument_id":"EO:12793","kind":"operative_current_law","reason":"No uniquely located attributed legal-text slice is held for this current-law pointer; serialized JSON/JSONL, snippets and absent cache artifacts are not legal-text evidence.","shared_key":"{\"basis_code\":\"printed_eo_text\",\"source\":{\"page_or_item\":\"10 U.S.C. subtitle A, pt. II, ch. 57 note; note 'Ex. Ord. No. 12793. Presidential Service Certificate and Presidential Service Badge' [USLM note id ida8989a5a-3a6f-11f1-a58a-d8db54b14ab5]; usc10.xml (sha256 f6b1a4f0897cd19431abb8af52cf3aafb02cf6e1870f0f6b5d1992c37fe128b6) in xml_uscAll@119-121.zip\",\"sha256\":\"c6122974e951003437ece5a998aa7c0b2cdc0f5703dfc78d6135e1fc9e729142\",\"url\":\"https://uscode.house.gov/download/releasepoints/us/pl/119/121/xml_uscAll@119-121.zip\"},\"text_path\":\"USC_EO_NOTES.jsonl#note_id=ida8989a5a-3a6f-11f1-a58a-d8db54b14ab5\"}","task_id":"TASK:2b1cf7f5a3769384cba42e6d"},{"availability":"citation_or_pointer_only","instrument_id":"EO:12793","kind":"operative_current_law","reason":"Current-law lead lacks an original-source sha256.","shared_key":"{}","task_id":"TASK:1b16444cae50780611b48e39"},{"availability":"absent_or_unreadable","instrument_id":"EO:12793","kind":"held_text_unavailable","reason":"[Errno 2] No such file or directory: '/workspace/scratch/a5be930883fa/eo-readiness/jobs/app-executive-orders/output/texts/executive-order-13286-amendment-executive-orders-and-other-actions-connection-with-the.txt'","shared_key":"jobs/app-executive-orders/output/texts/executive-order-13286-amendment-executive-orders-and-other-actions-connection-with-the.txt","task_id":"TASK:2f0d8690fd95d97958c0569d"},{"availability":"absent_or_unreadable","instrument_id":"EO:12793","kind":"held_text_unavailable","reason":"[Errno 2] No such file or directory: '/workspace/scratch/a5be930883fa/eo-readiness/jobs/clause-drafts/output/texts/cd-opus_zip-13286-1cc5a2464d.txt'","shared_key":"jobs/clause-drafts/output/texts/cd-opus_zip-13286-1cc5a2464d.txt","task_id":"TASK:148b093971bcc21847f4a446"},{"availability":"absent_or_unreadable","instrument_id":"EO:12793","kind":"held_text_unavailable","reason":"[Errno 2] No such file or directory: '/workspace/scratch/a5be930883fa/eo-readiness/jobs/fr-originals/data/full_run/texts/EO_13373.txt'","shared_key":"jobs/fr-originals/data/full_run/texts/EO_13373.txt","task_id":"TASK:3e5a92cde4e0af0f1c05e263"},{"availability":"absent_or_unreadable","instrument_id":"EO:12793","kind":"held_text_unavailable","reason":"[Errno 2] No such file or directory: '/workspace/scratch/a5be930883fa/eo-readiness/jobs/fr-originals/output/texts/EO_13373.txt'","shared_key":"jobs/fr-originals/output/texts/EO_13373.txt","task_id":"TASK:95983c812b4ac842ad331678"},{"availability":"absent_or_unreadable","instrument_id":"EO:12793","kind":"held_text_unavailable","reason":"[Errno 2] No such file or directory: '/workspace/scratch/a5be930883fa/eo-readiness/jobs/clause-drafts/output/texts/cd-stage21-13373-4a783e7a5b.txt'","shared_key":"jobs/clause-drafts/output/texts/cd-stage21-13373-4a783e7a5b.txt","task_id":"TASK:7f022240b54364a612e9a81a"},{"availability":"absent_or_unreadable","instrument_id":"EO:12793","kind":"held_text_unavailable","reason":"[Errno 2] No such file or directory: '/workspace/scratch/a5be930883fa/eo-readiness/jobs/fr-originals/data/full_run/texts/EO_14131.txt'","shared_key":"jobs/fr-originals/data/full_run/texts/EO_14131.txt","task_id":"TASK:a299d38b204c5036d9af8092"},{"availability":"absent_or_unreadable","instrument_id":"EO:12793","kind":"held_text_unavailable","reason":"[Errno 2] No such file or directory: '/workspace/scratch/a5be930883fa/eo-readiness/jobs/app-executive-orders/output/texts/executive-order-14131-amendments-executive-orders-relating-certain-certificates-and-badges.txt'","shared_key":"jobs/app-executive-orders/output/texts/executive-order-14131-amendments-executive-orders-relating-certain-certificates-and-badges.txt","task_id":"TASK:60bfda16d32c8f934a1eea6d"},{"availability":"absent_or_unreadable","instrument_id":"EO:12793","kind":"held_text_unavailable","reason":"[Errno 2] No such file or directory: '/workspace/scratch/a5be930883fa/eo-readiness/jobs/fr-originals/output/texts/EO_14131.txt'","shared_key":"jobs/fr-originals/output/texts/EO_14131.txt","task_id":"TASK:49229ca0bc86bc012450f1ff"},{"availability":"absent_or_unreadable","instrument_id":"EO:12793","kind":"held_text_unavailable","reason":"[Errno 2] No such file or directory: '/workspace/scratch/a5be930883fa/eo-readiness/jobs/clause-drafts/output/texts/cd-job-fr-originals-14131-0cc709cf35.txt'","shared_key":"jobs/clause-drafts/output/texts/cd-job-fr-originals-14131-0cc709cf35.txt","task_id":"TASK:83a5d95e72c78c36e6e4a148"},{"availability":"absent_or_unreadable","instrument_id":"EO:12793","kind":"held_text_unavailable","reason":"[Errno 2] No such file or directory: '/workspace/scratch/a5be930883fa/eo-readiness/jobs/fr-originals/output/texts/EO_12793.txt'","shared_key":"jobs/fr-originals/output/texts/EO_12793.txt","task_id":"TASK:a6fb1fe768eaebfc1e0761e6"},{"availability":"absent_or_unreadable","instrument_id":"EO:12793","kind":"held_text_unavailable","reason":"[Errno 2] No such file or directory: '/workspace/scratch/a5be930883fa/eo-readiness/jobs/clause-drafts/output/texts/cd-job-app-executive-orders-12793-3b461f28e9.txt'","shared_key":"jobs/clause-drafts/output/texts/cd-job-app-executive-orders-12793-3b461f28e9.txt","task_id":"TASK:5ed4d0da4ffe31e1448a9541"},{"availability":"absent_or_unreadable","instrument_id":"EO:12793","kind":"held_text_unavailable","reason":"[Errno 2] No such file or directory: '/workspace/scratch/a5be930883fa/eo-readiness/jobs/app-executive-orders/output/texts/executive-order-12793-continuing-the-presidential-service-certificate-and-the-presidential.txt'","shared_key":"jobs/app-executive-orders/output/texts/executive-order-12793-continuing-the-presidential-service-certificate-and-the-presidential.txt","task_id":"TASK:c0eff5eecc0a577a28f02db5"}],"notice":"No known gap is not a legal-readiness finding. Review may expose new facts."}

### Prior research and remaining delta

{"conflicting_versions":[],"current_rulings":[{"expected_sha256":null,"path":"research/readiness/owner_rulings/2026-10-29-tiered-delegation.md","sha256":"20a27c48ee4b86711151ed632bcbab14028197e4a3430ad1431c86c004629cd6","state":"unqualified"}],"full_context":"PACKET.json#/prior_research/orders/EO:12793","notice":"Prior producer/reviewer assertions, not new findings or automatic approval. Reuse only after checking the exact version, source, proposition and scope. Rejected versions and contradictory assertions remain visible; whole-case review is still required.","remaining_delta":{"current_reported_gaps":[],"dossier_fingerprint":"9f05eb3439017c1215a8a46f2e7982a426b11a10ca8328cb25dffcf42dc302c5","existing_lifecycle_questions":[{"clause_sha256":"67cbf74d08b741c8913be350e06b46691573a188c3932042df786898e75ea4bf","dossier_pointer":"/lifecycle_obligations/0","later_actor_evidence_ids":[],"own_term_evidence_ids":["TERM:EO:12793:7015a2a82582449f@7f0a7b05ae4d296e","TERM:EO:12793:d89a6daa64b549b5@edbd6b17be579a26","TERM:EO:12793:d89a6daa64b549b5@6ef768f38f8da6dd"],"questions":["Determine the first cessation or current predicate for this scope; check independent commands and surviving effects.","Distinguish the due date, demonstrated performance, and continuing duties. Establish occurrence from evidence and explain its effect on this clause.","Confirm the relevant event or operative sunset, scope, extensions and renewals; a detected date remains a candidate."],"scope_id":"EO:12793#sec1","state":"requires_clause_specific_research"},{"clause_sha256":"daf6de6c8be6210fd2cffc97fb449dbaad457032170c8ca3adf58afefceeda98","dossier_pointer":"/lifecycle_obligations/1","later_actor_evidence_ids":[],"own_term_evidence_ids":[],"questions":["Determine the first cessation or current predicate for this scope; check independent commands and surviving effects."],"scope_id":"EO:12793#sec2","state":"requires_clause_specific_research"},{"clause_sha256":"914a0a98f1d5db9aea82ad6eeb624941a5728d8e11aac60b92cd2c1783ee89b7","dossier_pointer":"/lifecycle_obligations/2","later_actor_evidence_ids":[],"own_term_evidence_ids":[],"questions":["Determine the first cessation or current predicate for this scope; check independent commands and surviving effects."],"scope_id":"EO:12793#sec3","state":"requires_clause_specific_research"},{"clause_sha256":"13489b332575fc180ea613eaefaaff55c25901c7c1158f4a1f0f6861f3f03f00","dossier_pointer":"/lifecycle_obligations/3","later_actor_evidence_ids":[],"own_term_evidence_ids":[],"questions":["Determine the first cessation or current predicate for this scope; check independent commands and surviving effects."],"scope_id":"EO:12793#sec4","state":"requires_clause_specific_research"},{"clause_sha256":"4fa62a149a927610285dd5409935d870769aaec0fb8e8fc3d3b9d5772b1f4cbf","dossier_pointer":"/lifecycle_obligations/4","later_actor_evidence_ids":[],"own_term_evidence_ids":[],"questions":["Determine the first cessation or current predicate for this scope; check independent commands and surviving effects."],"scope_id":"EO:12793#sec5","state":"requires_clause_specific_research"}],"existing_lifecycle_questions_notice":"Current dossier research prompts, not new gap findings or overrides of prior claim/review conclusions.","new_legal_gaps_invented":[],"prior_differences_require_scope_source_proposition_review":true},"selection_and_checkpoint_records":[],"state":"no_prior_research_located","status_holds":[],"status_research":[],"unattached_status_reviews":[],"unfinished_work":[],"versions":[]}

## Valla review leads and component attestations

Review lead only. Every case needs separate applicability, earlier-ending, scope, independent-command, savings and independent whole-case review.
Preparation attestations never approve legal conclusions or replace whole-case review.

## Shared tasks

[{"affected_orders":["EO:12312","EO:12830","EO:12985","EO:12793"],"availability":"held_not_loaded","kind":"load_actor_overflow","reasons":["Read full overflow before scope/savings decision","Read full overflow before scope/savings decision","Read full overflow before scope/savings decision","Read full overflow before scope/savings decision"],"shared_key":"EO:13286","task_id":"TASK:84afaf7b7ab986f33b60241f"},{"affected_orders":["EO:12312"],"availability":"citation_or_pointer_only","kind":"operative_current_law","reasons":["No uniquely located attributed legal-text slice is held for this current-law pointer; serialized JSON/JSONL, snippets and absent cache artifacts are not legal-text evidence."],"shared_key":"{\"basis_code\":\"amending_order_in_status_line\",\"source\":{\"page_or_item\":\"10 U.S.C. subtitle A, pt. II, ch. 57 note; note 'Ex. Ord. No. 11448. Meritorious Service Medal' [USLM note id ida8989a54-3a6f-11f1-a58a-d8db54b14ab5]; usc10.xml (sha256 f6b1a4f0897cd19431abb8af52cf3aafb02cf6e1870f0f6b5d1992c37fe128b6) in xml_uscAll@119-121.zip\",\"sha256\":\"c6122974e951003437ece5a998aa7c0b2cdc0f5703dfc78d6135e1fc9e729142\",\"url\":\"https://uscode.house.gov/download/releasepoints/us/pl/119/121/xml_uscAll@119-121.zip\"}}","task_id":"TASK:ed8b2928155d7c9542f32153"},{"affected_orders":["EO:12312","EO:12830","EO:12985","EO:12985","EO:12985","EO:12985","EO:12985","EO:12985","EO:12985","EO:12985","EO:12985","EO:12793"],"availability":"citation_or_pointer_only","kind":"operative_current_law","reasons":["Current-law lead lacks an original-source sha256.","Current-law lead lacks an original-source sha256.","Current-law lead lacks an original-source sha256.","Current-law lead lacks an original-source sha256.","Current-law lead lacks an original-source sha256.","Current-law lead lacks an original-source sha256.","Current-law lead lacks an original-source sha256.","Current-law lead lacks an original-source sha256.","Current-law lead lacks an original-source sha256.","Current-law lead lacks an original-source sha256.","Current-law lead lacks an original-source sha256.","Current-law lead lacks an original-source sha256."],"shared_key":"{}","task_id":"TASK:1b16444cae50780611b48e39"},{"affected_orders":["EO:12312","EO:12830","EO:12985","EO:12793"],"availability":"absent_or_unreadable","kind":"held_text_unavailable","reasons":["[Errno 2] No such file or directory: '/workspace/scratch/a5be930883fa/eo-readiness/jobs/app-executive-orders/output/texts/executive-order-13286-amendment-executive-orders-and-other-actions-connection-with-the.txt'","[Errno 2] No such file or directory: '/workspace/scratch/a5be930883fa/eo-readiness/jobs/app-executive-orders/output/texts/executive-order-13286-amendment-executive-orders-and-other-actions-connection-with-the.txt'","[Errno 2] No such file or directory: '/workspace/scratch/a5be930883fa/eo-readiness/jobs/app-executive-orders/output/texts/executive-order-13286-amendment-executive-orders-and-other-actions-connection-with-the.txt'","[Errno 2] No such file or directory: '/workspace/scratch/a5be930883fa/eo-readiness/jobs/app-executive-orders/output/texts/executive-order-13286-amendment-executive-orders-and-other-actions-connection-with-the.txt'"],"shared_key":"jobs/app-executive-orders/output/texts/executive-order-13286-amendment-executive-orders-and-other-actions-connection-with-the.txt","task_id":"TASK:2f0d8690fd95d97958c0569d"},{"affected_orders":["EO:12830"],"availability":"citation_or_pointer_only","kind":"operative_current_law","reasons":["No uniquely located attributed legal-text slice is held for this current-law pointer; serialized JSON/JSONL, snippets and absent cache artifacts are not legal-text evidence."],"shared_key":"{\"basis_code\":\"printed_eo_text\",\"source\":{\"page_or_item\":\"10 U.S.C. subtitle A, pt. II, ch. 57 note; note 'Ex. Ord. No. 12830. Military Outstanding Volunteer Service Medal' [USLM note id ida8989a5b-3a6f-11f1-a58a-d8db54b14ab5]; usc10.xml (sha256 f6b1a4f0897cd19431abb8af52cf3aafb02cf6e1870f0f6b5d1992c37fe128b6) in xml_uscAll@119-121.zip\",\"sha256\":\"c6122974e951003437ece5a998aa7c0b2cdc0f5703dfc78d6135e1fc9e729142\",\"url\":\"https://uscode.house.gov/download/releasepoints/us/pl/119/121/xml_uscAll@119-121.zip\"},\"text_path\":\"USC_EO_NOTES.jsonl#note_id=ida8989a5b-3a6f-11f1-a58a-d8db54b14ab5\"}","task_id":"TASK:bc3506ed72a0710f2f2557b4"},{"affected_orders":["EO:12830","EO:12985","EO:12793"],"availability":"absent_or_unreadable","kind":"held_text_unavailable","reasons":["[Errno 2] No such file or directory: '/workspace/scratch/a5be930883fa/eo-readiness/jobs/clause-drafts/output/texts/cd-opus_zip-13286-1cc5a2464d.txt'","[Errno 2] No such file or directory: '/workspace/scratch/a5be930883fa/eo-readiness/jobs/clause-drafts/output/texts/cd-opus_zip-13286-1cc5a2464d.txt'","[Errno 2] No such file or directory: '/workspace/scratch/a5be930883fa/eo-readiness/jobs/clause-drafts/output/texts/cd-opus_zip-13286-1cc5a2464d.txt'"],"shared_key":"jobs/clause-drafts/output/texts/cd-opus_zip-13286-1cc5a2464d.txt","task_id":"TASK:148b093971bcc21847f4a446"},{"affected_orders":["EO:12985"],"availability":"citation_or_pointer_only","kind":"operative_current_law","reasons":["No uniquely located attributed legal-text slice is held for this current-law pointer; serialized JSON/JSONL, snippets and absent cache artifacts are not legal-text evidence."],"shared_key":"{\"basis_code\":\"printed_eo_text\",\"source\":{\"page_or_item\":\"10 U.S.C. subtitle A, pt. II, ch. 57 note; note 'Ex. Ord. No. 12985. Establishing Armed Forces Service Medal' [USLM note id ida8989a5c-3a6f-11f1-a58a-d8db54b14ab5]; usc10.xml (sha256 f6b1a4f0897cd19431abb8af52cf3aafb02cf6e1870f0f6b5d1992c37fe128b6) in xml_uscAll@119-121.zip\",\"sha256\":\"c6122974e951003437ece5a998aa7c0b2cdc0f5703dfc78d6135e1fc9e729142\",\"url\":\"https://uscode.house.gov/download/releasepoints/us/pl/119/121/xml_uscAll@119-121.zip\"},\"text_path\":\"USC_EO_NOTES.jsonl#note_id=ida8989a5c-3a6f-11f1-a58a-d8db54b14ab5\"}","task_id":"TASK:4055b32ad55ebfaf70d81604"},{"affected_orders":["EO:12985"],"availability":"citation_or_pointer_only","kind":"operative_current_law","reasons":["No uniquely located attributed legal-text slice is held for this current-law pointer; serialized JSON/JSONL, snippets and absent cache artifacts are not legal-text evidence."],"shared_key":"{\"basis_code\":\"statutory_text_reference\",\"source\":{\"page_or_item\":\"38 U.S.C. 4212; usc38.xml (sha256 812bcb4dab911d8d4b503a86de786adf53c7e6815b2667fcfe1dad79b63658b6) in xml_uscAll@119-121.zip\",\"sha256\":\"c6122974e951003437ece5a998aa7c0b2cdc0f5703dfc78d6135e1fc9e729142\",\"url\":\"https://uscode.house.gov/download/releasepoints/us/pl/119/121/xml_uscAll@119-121.zip\"}}","task_id":"TASK:a32bfc0f773cdd2ade95169a"},{"affected_orders":["EO:12985"],"availability":"citation_or_pointer_only","kind":"operative_current_law","reasons":["No uniquely located attributed legal-text slice is held for this current-law pointer; serialized JSON/JSONL, snippets and absent cache artifacts are not legal-text evidence."],"shared_key":"{\"basis_code\":\"references_in_text_note\",\"source\":{\"page_or_item\":\"38 U.S.C. 4212 note; note 'References in Text' [USLM note id idf8cc606d-ac5f-11f1-867f-e0c61e4ce6af]; usc38.xml (sha256 812bcb4dab911d8d4b503a86de786adf53c7e6815b2667fcfe1dad79b63658b6) in xml_uscAll@119-121.zip\",\"sha256\":\"c6122974e951003437ece5a998aa7c0b2cdc0f5703dfc78d6135e1fc9e729142\",\"url\":\"https://uscode.house.gov/download/releasepoints/us/pl/119/121/xml_uscAll@119-121.zip\"}}","task_id":"TASK:22431ad056a4a936af28d39f"},{"affected_orders":["EO:12985"],"availability":"citation_or_pointer_only","kind":"operative_current_law","reasons":["No uniquely located attributed legal-text slice is held for this current-law pointer; serialized JSON/JSONL, snippets and absent cache artifacts are not legal-text evidence."],"shared_key":"{\"basis_code\":\"cfr_text_reference\",\"source\":{\"page_or_item\":\"41 CFR 60-300.2 (section_text; GovInfo eCFR XML title 41, amended through 2026-09-22; NODE 41:1.2.3.1.9.1.11.2)\",\"sha256\":\"f4463cdd577d7d092b31c47a32b67fbb47d628beffbbb689c52d26fbd1a012b3\",\"url\":\"https://www.govinfo.gov/bulkdata/ECFR/title-41/ECFR-title41.xml\"}}","task_id":"TASK:12a6f8b43fb8f502506ef91b"},{"affected_orders":["EO:12985"],"availability":"citation_or_pointer_only","kind":"operative_current_law","reasons":["No uniquely located attributed legal-text slice is held for this current-law pointer; serialized JSON/JSONL, snippets and absent cache artifacts are not legal-text evidence."],"shared_key":"{\"basis_code\":\"cfr_text_reference\",\"source\":{\"page_or_item\":\"41 CFR 61-300.2 (section_text; GovInfo eCFR XML title 41, amended through 2026-09-22; NODE 41:1.2.4.1.2.0.11.2)\",\"sha256\":\"f4463cdd577d7d092b31c47a32b67fbb47d628beffbbb689c52d26fbd1a012b3\",\"url\":\"https://www.govinfo.gov/bulkdata/ECFR/title-41/ECFR-title41.xml\"}}","task_id":"TASK:2389f196e0513b65cfb97e9c"},{"affected_orders":["EO:12985"],"availability":"citation_or_pointer_only","kind":"operative_current_law","reasons":["No uniquely located attributed legal-text slice is held for this current-law pointer; serialized JSON/JSONL, snippets and absent cache artifacts are not legal-text evidence."],"shared_key":"{\"basis_code\":\"cfr_text_reference\",\"source\":{\"page_or_item\":\"48 CFR 22.1301 (section_text; GovInfo eCFR XML title 48, amended through 2026-10-09; NODE 48:1.0.1.4.21.13.1.2)\",\"sha256\":\"acf22f7e7bcfa3dc6201a8383cc5d917175ba82a857bd770112df21d299181c6\",\"url\":\"https://www.govinfo.gov/bulkdata/ECFR/title-48/ECFR-title48.xml\"}}","task_id":"TASK:5b8cf9cca0a8511138092dd5"},{"affected_orders":["EO:12985"],"availability":"citation_or_pointer_only","kind":"operative_current_law","reasons":["No uniquely located attributed legal-text slice is held for this current-law pointer; serialized JSON/JSONL, snippets and absent cache artifacts are not legal-text evidence."],"shared_key":"{\"basis_code\":\"cfr_text_reference\",\"source\":{\"page_or_item\":\"5 CFR 307.102 (section_text; GovInfo eCFR XML title 5, amended through 2026-10-15; NODE 5:1.0.1.2.38.0.14.2)\",\"sha256\":\"d0b85cb99762ee3117c673c30a95c6847c5f15e9d4a9b1401616030827721c91\",\"url\":\"https://www.govinfo.gov/bulkdata/ECFR/title-5/ECFR-title5.xml\"}}","task_id":"TASK:1af560c59c98cb4ea63b04f1"},{"affected_orders":["EO:12985"],"availability":"citation_or_pointer_only","kind":"operative_current_law","reasons":["No uniquely located attributed legal-text slice is held for this current-law pointer; serialized JSON/JSONL, snippets and absent cache artifacts are not legal-text evidence."],"shared_key":"{\"basis_code\":\"cfr_appendix_text_reference\",\"source\":{\"page_or_item\":\"41 CFR part 60, Appendix B to Part 60-300 (appendix_text; GovInfo eCFR XML title 41, amended through 2026-09-22; NODE 41:1.2.3.1.9.5.11.7.3)\",\"sha256\":\"f4463cdd577d7d092b31c47a32b67fbb47d628beffbbb689c52d26fbd1a012b3\",\"url\":\"https://www.govinfo.gov/bulkdata/ECFR/title-41/ECFR-title41.xml\"}}","task_id":"TASK:f6393f0aef144c4adc893524"},{"affected_orders":["EO:12985"],"availability":"citation_or_pointer_only","kind":"operative_current_law","reasons":["No uniquely located attributed legal-text slice is held for this current-law pointer; serialized JSON/JSONL, snippets and absent cache artifacts are not legal-text evidence."],"shared_key":"{\"basis_code\":\"cfr_search_excerpt_reference\",\"source\":{\"page_or_item\":\"41 CFR part 60-300, Appendix B to Part 60-300 (eCFR search API result, query \\\"Executive Order\\\", date=2026-10-14, page 3)\",\"sha256\":\"6edecd5d7d179bd77a1c39561c12105cf4842032c11a19706bb4e0a40f39dd58\",\"url\":\"https://www.ecfr.gov/api/search/v1/results?query=%22Executive+Order%22&date=2026-10-14&per_page=1000&page=3\"}}","task_id":"TASK:925fbb7ba628d7b3fee68d06"},{"affected_orders":["EO:12985"],"availability":"held_not_loaded","kind":"read_citing_order","reasons":["cited by number, no change provision located: EO:13289"],"shared_key":"EO:13289","task_id":"TASK:27621c8342df74bec118ad72"},{"affected_orders":["EO:12985"],"availability":"held_not_loaded","kind":"locate_held_provision","reasons":["target provision not located: EO:13154"],"shared_key":"EO:13154","task_id":"TASK:e6616e06c5d98f11f800cbe5"},{"affected_orders":["EO:12985"],"availability":"absent_or_unreadable","kind":"held_text_unavailable","reasons":["[Errno 2] No such file or directory: '/workspace/scratch/a5be930883fa/eo-readiness/jobs/fr-originals/data/full_run/texts/EO_13154.txt'"],"shared_key":"jobs/fr-originals/data/full_run/texts/EO_13154.txt","task_id":"TASK:e54b76a8ea82b7d74e678e90"},{"affected_orders":["EO:12985"],"availability":"absent_or_unreadable","kind":"held_text_unavailable","reasons":["[Errno 2] No such file or directory: '/workspace/scratch/a5be930883fa/eo-readiness/jobs/fr-originals/data/full_run/texts/EO_13289.txt'"],"shared_key":"jobs/fr-originals/data/full_run/texts/EO_13289.txt","task_id":"TASK:8baa1743fe696661db7bd624"},{"affected_orders":["EO:12793"],"availability":"citation_or_pointer_only","kind":"operative_current_law","reasons":["No uniquely located attributed legal-text slice is held for this current-law pointer; serialized JSON/JSONL, snippets and absent cache artifacts are not legal-text evidence."],"shared_key":"{\"basis_code\":\"printed_eo_text\",\"source\":{\"page_or_item\":\"10 U.S.C. subtitle A, pt. II, ch. 57 note; note 'Ex. Ord. No. 12793. Presidential Service Certificate and Presidential Service Badge' [USLM note id ida8989a5a-3a6f-11f1-a58a-d8db54b14ab5]; usc10.xml (sha256 f6b1a4f0897cd19431abb8af52cf3aafb02cf6e1870f0f6b5d1992c37fe128b6) in xml_uscAll@119-121.zip\",\"sha256\":\"c6122974e951003437ece5a998aa7c0b2cdc0f5703dfc78d6135e1fc9e729142\",\"url\":\"https://uscode.house.gov/download/releasepoints/us/pl/119/121/xml_uscAll@119-121.zip\"},\"text_path\":\"USC_EO_NOTES.jsonl#note_id=ida8989a5a-3a6f-11f1-a58a-d8db54b14ab5\"}","task_id":"TASK:2b1cf7f5a3769384cba42e6d"},{"affected_orders":["EO:12793"],"availability":"absent_or_unreadable","kind":"held_text_unavailable","reasons":["[Errno 2] No such file or directory: '/workspace/scratch/a5be930883fa/eo-readiness/jobs/fr-originals/data/full_run/texts/EO_13373.txt'"],"shared_key":"jobs/fr-originals/data/full_run/texts/EO_13373.txt","task_id":"TASK:3e5a92cde4e0af0f1c05e263"},{"affected_orders":["EO:12793"],"availability":"absent_or_unreadable","kind":"held_text_unavailable","reasons":["[Errno 2] No such file or directory: '/workspace/scratch/a5be930883fa/eo-readiness/jobs/fr-originals/output/texts/EO_13373.txt'"],"shared_key":"jobs/fr-originals/output/texts/EO_13373.txt","task_id":"TASK:95983c812b4ac842ad331678"},{"affected_orders":["EO:12793"],"availability":"absent_or_unreadable","kind":"held_text_unavailable","reasons":["[Errno 2] No such file or directory: '/workspace/scratch/a5be930883fa/eo-readiness/jobs/clause-drafts/output/texts/cd-stage21-13373-4a783e7a5b.txt'"],"shared_key":"jobs/clause-drafts/output/texts/cd-stage21-13373-4a783e7a5b.txt","task_id":"TASK:7f022240b54364a612e9a81a"},{"affected_orders":["EO:12793"],"availability":"absent_or_unreadable","kind":"held_text_unavailable","reasons":["[Errno 2] No such file or directory: '/workspace/scratch/a5be930883fa/eo-readiness/jobs/fr-originals/data/full_run/texts/EO_14131.txt'"],"shared_key":"jobs/fr-originals/data/full_run/texts/EO_14131.txt","task_id":"TASK:a299d38b204c5036d9af8092"},{"affected_orders":["EO:12793"],"availability":"absent_or_unreadable","kind":"held_text_unavailable","reasons":["[Errno 2] No such file or directory: '/workspace/scratch/a5be930883fa/eo-readiness/jobs/app-executive-orders/output/texts/executive-order-14131-amendments-executive-orders-relating-certain-certificates-and-badges.txt'"],"shared_key":"jobs/app-executive-orders/output/texts/executive-order-14131-amendments-executive-orders-relating-certain-certificates-and-badges.txt","task_id":"TASK:60bfda16d32c8f934a1eea6d"},{"affected_orders":["EO:12793"],"availability":"absent_or_unreadable","kind":"held_text_unavailable","reasons":["[Errno 2] No such file or directory: '/workspace/scratch/a5be930883fa/eo-readiness/jobs/fr-originals/output/texts/EO_14131.txt'"],"shared_key":"jobs/fr-originals/output/texts/EO_14131.txt","task_id":"TASK:49229ca0bc86bc012450f1ff"},{"affected_orders":["EO:12793"],"availability":"absent_or_unreadable","kind":"held_text_unavailable","reasons":["[Errno 2] No such file or directory: '/workspace/scratch/a5be930883fa/eo-readiness/jobs/clause-drafts/output/texts/cd-job-fr-originals-14131-0cc709cf35.txt'"],"shared_key":"jobs/clause-drafts/output/texts/cd-job-fr-originals-14131-0cc709cf35.txt","task_id":"TASK:83a5d95e72c78c36e6e4a148"},{"affected_orders":["EO:12793"],"availability":"absent_or_unreadable","kind":"held_text_unavailable","reasons":["[Errno 2] No such file or directory: '/workspace/scratch/a5be930883fa/eo-readiness/jobs/fr-originals/output/texts/EO_12793.txt'"],"shared_key":"jobs/fr-originals/output/texts/EO_12793.txt","task_id":"TASK:a6fb1fe768eaebfc1e0761e6"},{"affected_orders":["EO:12793"],"availability":"absent_or_unreadable","kind":"held_text_unavailable","reasons":["[Errno 2] No such file or directory: '/workspace/scratch/a5be930883fa/eo-readiness/jobs/clause-drafts/output/texts/cd-job-app-executive-orders-12793-3b461f28e9.txt'"],"shared_key":"jobs/clause-drafts/output/texts/cd-job-app-executive-orders-12793-3b461f28e9.txt","task_id":"TASK:5ed4d0da4ffe31e1448a9541"},{"affected_orders":["EO:12793"],"availability":"absent_or_unreadable","kind":"held_text_unavailable","reasons":["[Errno 2] No such file or directory: '/workspace/scratch/a5be930883fa/eo-readiness/jobs/app-executive-orders/output/texts/executive-order-12793-continuing-the-presidential-service-certificate-and-the-presidential.txt'"],"shared_key":"jobs/app-executive-orders/output/texts/executive-order-12793-continuing-the-presidential-service-certificate-and-the-presidential.txt","task_id":"TASK:c0eff5eecc0a577a28f02db5"}]

## Explicit overflow and codec warnings

[{"kind":"held_source_not_loaded","path":"jobs/app-executive-orders/output/texts/executive-order-13286-amendment-executive-orders-and-other-actions-connection-with-the.txt","reason":"[Errno 2] No such file or directory: '/workspace/scratch/a5be930883fa/eo-readiness/jobs/app-executive-orders/output/texts/executive-order-13286-amendment-executive-orders-and-other-actions-connection-with-the.txt'"},{"kind":"text_not_compressed","path":"jobs/app-executive-orders/output/texts/executive-order-13286-amendment-executive-orders-and-other-actions-connection-with-the.txt","reason":"source hash/span not exactly verified; original value retained"},{"kind":"text_not_compressed","path":"jobs/app-executive-orders/output/texts/executive-order-13286-amendment-executive-orders-and-other-actions-connection-with-the.txt","reason":"source hash/span not exactly verified; original value retained"},{"kind":"text_not_compressed","path":"jobs/app-executive-orders/output/texts/executive-order-13286-amendment-executive-orders-and-other-actions-connection-with-the.txt","reason":"source hash/span not exactly verified; original value retained"},{"kind":"text_not_compressed","path":"jobs/app-executive-orders/output/texts/executive-order-13286-amendment-executive-orders-and-other-actions-connection-with-the.txt","reason":"source hash/span not exactly verified; original value retained"},{"kind":"text_not_compressed","path":"jobs/app-executive-orders/output/texts/executive-order-13286-amendment-executive-orders-and-other-actions-connection-with-the.txt","reason":"source hash/span not exactly verified; original value retained"},{"kind":"text_not_compressed","path":"jobs/app-executive-orders/output/texts/executive-order-13286-amendment-executive-orders-and-other-actions-connection-with-the.txt","reason":"source hash/span not exactly verified; original value retained"},{"kind":"text_not_compressed","path":"jobs/app-executive-orders/output/texts/executive-order-13286-amendment-executive-orders-and-other-actions-connection-with-the.txt","reason":"source hash/span not exactly verified; original value retained"},{"kind":"text_not_compressed","path":"jobs/app-executive-orders/output/texts/executive-order-13286-amendment-executive-orders-and-other-actions-connection-with-the.txt","reason":"source hash/span not exactly verified; original value retained"},{"kind":"held_source_not_loaded","path":"jobs/clause-drafts/output/texts/cd-opus_zip-13286-1cc5a2464d.txt","reason":"[Errno 2] No such file or directory: '/workspace/scratch/a5be930883fa/eo-readiness/jobs/clause-drafts/output/texts/cd-opus_zip-13286-1cc5a2464d.txt'"},{"kind":"text_not_compressed","path":"jobs/clause-drafts/output/texts/cd-opus_zip-13286-1cc5a2464d.txt","reason":"source hash/span not exactly verified; original value retained"},{"kind":"text_not_compressed","path":"jobs/app-executive-orders/output/texts/executive-order-13286-amendment-executive-orders-and-other-actions-connection-with-the.txt","reason":"source hash/span not exactly verified; original value retained"},{"kind":"text_not_compressed","path":"jobs/app-executive-orders/output/texts/executive-order-13286-amendment-executive-orders-and-other-actions-connection-with-the.txt","reason":"source hash/span not exactly verified; original value retained"},{"kind":"text_not_compressed","path":"jobs/app-executive-orders/output/texts/executive-order-13286-amendment-executive-orders-and-other-actions-connection-with-the.txt","reason":"source hash/span not exactly verified; original value retained"},{"kind":"text_not_compressed","path":"jobs/app-executive-orders/output/texts/executive-order-13286-amendment-executive-orders-and-other-actions-connection-with-the.txt","reason":"source hash/span not exactly verified; original value retained"},{"kind":"text_not_compressed","path":"jobs/app-executive-orders/output/texts/executive-order-13286-amendment-executive-orders-and-other-actions-connection-with-the.txt","reason":"source hash/span not exactly verified; original value retained"},{"kind":"text_not_compressed","path":"jobs/app-executive-orders/output/texts/executive-order-13286-amendment-executive-orders-and-other-actions-connection-with-the.txt","reason":"source hash/span not exactly verified; original value retained"},{"kind":"text_not_compressed","path":"jobs/clause-drafts/output/texts/cd-opus_zip-13286-1cc5a2464d.txt","reason":"source hash/span not exactly verified; original value retained"},{"kind":"held_source_not_loaded","path":"jobs/fr-originals/data/full_run/texts/EO_13154.txt","reason":"[Errno 2] No such file or directory: '/workspace/scratch/a5be930883fa/eo-readiness/jobs/fr-originals/data/full_run/texts/EO_13154.txt'"},{"kind":"text_not_compressed","path":"jobs/fr-originals/data/full_run/texts/EO_13154.txt","reason":"source hash/span not exactly verified; original value retained"},{"kind":"held_source_not_loaded","path":"jobs/fr-originals/data/full_run/texts/EO_13289.txt","reason":"[Errno 2] No such file or directory: '/workspace/scratch/a5be930883fa/eo-readiness/jobs/fr-originals/data/full_run/texts/EO_13289.txt'"},{"kind":"text_not_compressed","path":"jobs/fr-originals/data/full_run/texts/EO_13289.txt","reason":"source hash/span not exactly verified; original value retained"},{"kind":"text_not_compressed","path":"jobs/app-executive-orders/output/texts/executive-order-13286-amendment-executive-orders-and-other-actions-connection-with-the.txt","reason":"source hash/span not exactly verified; original value retained"},{"kind":"text_not_compressed","path":"jobs/app-executive-orders/output/texts/executive-order-13286-amendment-executive-orders-and-other-actions-connection-with-the.txt","reason":"source hash/span not exactly verified; original value retained"},{"kind":"text_not_compressed","path":"jobs/app-executive-orders/output/texts/executive-order-13286-amendment-executive-orders-and-other-actions-connection-with-the.txt","reason":"source hash/span not exactly verified; original value retained"},{"kind":"text_not_compressed","path":"jobs/app-executive-orders/output/texts/executive-order-13286-amendment-executive-orders-and-other-actions-connection-with-the.txt","reason":"source hash/span not exactly verified; original value retained"},{"kind":"text_not_compressed","path":"jobs/app-executive-orders/output/texts/executive-order-13286-amendment-executive-orders-and-other-actions-connection-with-the.txt","reason":"source hash/span not exactly verified; original value retained"},{"kind":"text_not_compressed","path":"jobs/clause-drafts/output/texts/cd-opus_zip-13286-1cc5a2464d.txt","reason":"source hash/span not exactly verified; original value retained"},{"kind":"held_source_not_loaded","path":"jobs/fr-originals/data/full_run/texts/EO_13373.txt","reason":"[Errno 2] No such file or directory: '/workspace/scratch/a5be930883fa/eo-readiness/jobs/fr-originals/data/full_run/texts/EO_13373.txt'"},{"kind":"text_not_compressed","path":"jobs/fr-originals/data/full_run/texts/EO_13373.txt","reason":"source hash/span not exactly verified; original value retained"},{"kind":"held_source_not_loaded","path":"jobs/fr-originals/output/texts/EO_13373.txt","reason":"[Errno 2] No such file or directory: '/workspace/scratch/a5be930883fa/eo-readiness/jobs/fr-originals/output/texts/EO_13373.txt'"},{"kind":"text_not_compressed","path":"jobs/fr-originals/output/texts/EO_13373.txt","reason":"source hash/span not exactly verified; original value retained"},{"kind":"held_source_not_loaded","path":"jobs/clause-drafts/output/texts/cd-stage21-13373-4a783e7a5b.txt","reason":"[Errno 2] No such file or directory: '/workspace/scratch/a5be930883fa/eo-readiness/jobs/clause-drafts/output/texts/cd-stage21-13373-4a783e7a5b.txt'"},{"kind":"text_not_compressed","path":"jobs/clause-drafts/output/texts/cd-stage21-13373-4a783e7a5b.txt","reason":"source hash/span not exactly verified; original value retained"},{"kind":"text_not_compressed","path":"jobs/fr-originals/data/full_run/texts/EO_13373.txt","reason":"source hash/span not exactly verified; original value retained"},{"kind":"held_source_not_loaded","path":"jobs/fr-originals/data/full_run/texts/EO_14131.txt","reason":"[Errno 2] No such file or directory: '/workspace/scratch/a5be930883fa/eo-readiness/jobs/fr-originals/data/full_run/texts/EO_14131.txt'"},{"kind":"text_not_compressed","path":"jobs/fr-originals/data/full_run/texts/EO_14131.txt","reason":"source hash/span not exactly verified; original value retained"},{"kind":"held_source_not_loaded","path":"jobs/app-executive-orders/output/texts/executive-order-14131-amendments-executive-orders-relating-certain-certificates-and-badges.txt","reason":"[Errno 2] No such file or directory: '/workspace/scratch/a5be930883fa/eo-readiness/jobs/app-executive-orders/output/texts/executive-order-14131-amendments-executive-orders-relating-certain-certificates-and-badges.txt'"},{"kind":"text_not_compressed","path":"jobs/app-executive-orders/output/texts/executive-order-14131-amendments-executive-orders-relating-certain-certificates-and-badges.txt","reason":"source hash/span not exactly verified; original value retained"},{"kind":"text_not_compressed","path":"jobs/fr-originals/data/full_run/texts/EO_14131.txt","reason":"source hash/span not exactly verified; original value retained"},{"kind":"held_source_not_loaded","path":"jobs/fr-originals/output/texts/EO_14131.txt","reason":"[Errno 2] No such file or directory: '/workspace/scratch/a5be930883fa/eo-readiness/jobs/fr-originals/output/texts/EO_14131.txt'"},{"kind":"text_not_compressed","path":"jobs/fr-originals/output/texts/EO_14131.txt","reason":"source hash/span not exactly verified; original value retained"},{"kind":"held_source_not_loaded","path":"jobs/clause-drafts/output/texts/cd-job-fr-originals-14131-0cc709cf35.txt","reason":"[Errno 2] No such file or directory: '/workspace/scratch/a5be930883fa/eo-readiness/jobs/clause-drafts/output/texts/cd-job-fr-originals-14131-0cc709cf35.txt'"},{"kind":"text_not_compressed","path":"jobs/clause-drafts/output/texts/cd-job-fr-originals-14131-0cc709cf35.txt","reason":"source hash/span not exactly verified; original value retained"},{"kind":"text_not_compressed","path":"jobs/fr-originals/data/full_run/texts/EO_13373.txt","reason":"source hash/span not exactly verified; original value retained"},{"kind":"text_not_compressed","path":"jobs/fr-originals/data/full_run/texts/EO_14131.txt","reason":"source hash/span not exactly verified; original value retained"},{"kind":"held_source_not_loaded","path":"jobs/fr-originals/output/texts/EO_12793.txt","reason":"[Errno 2] No such file or directory: '/workspace/scratch/a5be930883fa/eo-readiness/jobs/fr-originals/output/texts/EO_12793.txt'"},{"kind":"text_not_compressed","path":"jobs/fr-originals/output/texts/EO_12793.txt","reason":"source hash/span not exactly verified; original value retained"},{"kind":"held_source_not_loaded","path":"jobs/clause-drafts/output/texts/cd-job-app-executive-orders-12793-3b461f28e9.txt","reason":"[Errno 2] No such file or directory: '/workspace/scratch/a5be930883fa/eo-readiness/jobs/clause-drafts/output/texts/cd-job-app-executive-orders-12793-3b461f28e9.txt'"},{"kind":"text_not_compressed","path":"jobs/clause-drafts/output/texts/cd-job-app-executive-orders-12793-3b461f28e9.txt","reason":"source hash/span not exactly verified; original value retained"},{"kind":"held_source_not_loaded","path":"jobs/app-executive-orders/output/texts/executive-order-12793-continuing-the-presidential-service-certificate-and-the-presidential.txt","reason":"[Errno 2] No such file or directory: '/workspace/scratch/a5be930883fa/eo-readiness/jobs/app-executive-orders/output/texts/executive-order-12793-continuing-the-presidential-service-certificate-and-the-presidential.txt'"},{"kind":"text_not_compressed","path":"jobs/app-executive-orders/output/texts/executive-order-12793-continuing-the-presidential-service-certificate-and-the-presidential.txt","reason":"source hash/span not exactly verified; original value retained"}]
