"""Reviewer-owned bounded job wiring probe; no corpus or canonical output writes."""
import builtins,contextlib,hashlib,io,json,os,sys,types
from pathlib import Path
from unittest.mock import patch
source_dir=Path(sys.argv[1]).resolve(); report_path=Path(sys.argv[2]).resolve()
sys.path.insert(0,str(source_dir))
import checker,proquest_inputs
from test_proquest_inputs import ProQuestInputsTests
case=ProQuestInputsTests();case.setUp()
try:
    for n in range(8): case.add_source(f'EO:{100+n}',f'extra{n}')
    observations={}; real_import=builtins.__import__
    def checker_main(args):
        receipt=case.out/'PROQUEST_MATERIALIZATION.json'
        observations['receipt_exists_before_checker']=receipt.is_file()
        observations['checker_args']=args
        observations['checker_called']=True
    child_calls=[]
    def child_run(*args,**kwargs):
        child_calls.append({'args':args,'cwd':str(kwargs.get('cwd'))})
        return types.SimpleNamespace(returncode=0)
    def importer(name,*args,**kwargs):
        if name=='subprocess': return types.SimpleNamespace(run=child_run)
        if name=='checker': return types.SimpleNamespace(main=checker_main)
        return real_import(name,*args,**kwargs)
    env={**vars(builtins),'__import__':importer}
    job=source_dir/'job.py'; stdout=io.StringIO()
    with patch.dict(os.environ,{'REPO_ROOT':str(case.repo),'OUTPUT_DIR':str(case.out)}),patch.object(sys,'argv',[str(job)]),contextlib.redirect_stdout(stdout):
        exec(compile(job.read_bytes(),str(job),'exec'),{'__file__':str(job),'__name__':'__main__','__builtins__':env})
    emitted=json.loads(stdout.getvalue()); receipt=json.loads((case.out/'PROQUEST_MATERIALIZATION.json').read_text())
    checks={
      'one_child_test_process_requested':len(child_calls)==1,
      'eight_artifact_bound':receipt['artifacts_attempted']==8,
      'one_tail_artifact_deferred':sum(a['state']=='deferred_batch_bound' for a in receipt['artifacts'])==1,
      'selection_logged':emitted['selection_sha256']==receipt['selection_sha256'],
      'next_cursor_logged':emitted['next_cursor']==receipt['next_cursor'] and receipt['next_cursor']['next_index']==8,
      'deferred_logged':len(emitted['deferred'])==1,
      'checker_after_receipt':observations.get('checker_called') and observations.get('receipt_exists_before_checker'),
      'restored_bytes_remain_bound':receipt['bytes_read']<=proquest_inputs.MAX_TOTAL_BYTES,
    }
    report={'checks':checks,'all_checks_pass':all(checks.values()),'observations':observations,'emitted':emitted,'receipt':receipt,'job_sha256':hashlib.sha256(job.read_bytes()).hexdigest(),'scope':'Exact job source executed with synthetic Git objects and real materializer/source-field walker. Child test process and checker entrypoint stubbed to isolate sequencing/logging; not a full production checker run.'}
    report_path.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'checks':checks,'all_checks_pass':all(checks.values())}))
finally:
    case.doCleanups()
