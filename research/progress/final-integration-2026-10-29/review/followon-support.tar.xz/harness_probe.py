"""Exercise retained-rehearsal return handling without running corpus work."""
from pathlib import Path
import hashlib,json,tempfile,textwrap
source=Path('/workspace/scratch/21fe24d0bcf0/integration/research/progress/final-integration-2026-10-29/validate_native.py')
s=source.read_text();section=textwrap.dedent(s[s.index('    for record in (view, complete):'):s.index('    cruden =')]);checks={}
variants=[('completion_rc1_without_tally',1,'ordinary output',False,False),('completion_rc1_traceback',1,'Traceback (most recent call last):',False,False),('refusal_without_native_marker',2,'changed input',False,False),('native_unrelated_error',2,'claim-kit: missing file',False,False),('native_stale_refusal',2,'claim-kit: stale input',False,True),('valid_completion_success',0,'ordinary output',True,True),('valid_completion_exceptions',1,'ordinary output',True,True)]
for name,rc,log,tally,expected in variants:
 with tempfile.TemporaryDirectory() as td:
  out=Path(td);dest=out/'dest';dest.mkdir();(out/'retained-view.log').write_text('view output');(out/'retained-complete.log').write_text(log)
  if tally:(dest/'TALLY.json').write_text(json.dumps({'claims_published':0,'eligible':[]}))
  scope={'OUT':out,'dest':dest,'view':{'label':'retained-view','returncode':0},'complete':{'label':'retained-complete','returncode':rc},'json':json,'sha':lambda p:hashlib.sha256(p.read_bytes()).hexdigest()}
  try:exec(compile(section,str(source),'exec'),scope);accepted=True
  except (AssertionError,KeyError,ValueError):accepted=False
  checks[name]=accepted==expected
report={'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'checks':checks,'all_checks_pass':all(checks.values()),'scope':'Only exact extracted native return/tally validation block executed against temporary synthetic command outcomes.'}
Path('/workspace/scratch/21fe24d0bcf0/review/followon-support/harness-probe.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
