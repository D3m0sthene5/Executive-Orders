import sys,json
from pathlib import Path
sys.path.insert(0,'/workspace/scratch/21fe24d0bcf0/review/followon-support/source/jobs/claim-checker')
from test_proquest_inputs import ProQuestInputsTests
import proquest_inputs as p
checks={}
for name,raw in [('non_object',b'[]\n'),('invalid_utf8',b'\xff\n'),('malformed_json',b'{broken\n')]:
 case=ProQuestInputsTests();case.setUp()
 try:
  (case.repo/'research/readiness/claims/z.jsonl').write_bytes(raw);r=p.materialize(case.repo,case.out)
  checks[name]=bool(r['errors']) and not (case.repo/case.rel).exists() and not r['artifacts']
 finally:case.doCleanups()
for name,index in [('bool_cursor',True),('negative_cursor',-1),('out_of_range_cursor',2)]:
 case=ProQuestInputsTests();case.setUp()
 try:
  r=p.materialize(case.repo,case.out,max_total_bytes=1);cursor={**r['next_cursor'],'next_index':index};r=p.materialize(case.repo,case.out,resume=cursor)
  checks[name]=bool(r['errors']) and not (case.repo/case.rel).exists() and not r['artifacts']
 finally:case.doCleanups()
report={'checks':checks,'all_checks_pass':all(checks.values()),'scope':'Temporary synthetic Git fixtures; invalid metadata and cursor fail before restoration.'}
Path('/workspace/scratch/21fe24d0bcf0/review/followon-support/malformed-probe.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
