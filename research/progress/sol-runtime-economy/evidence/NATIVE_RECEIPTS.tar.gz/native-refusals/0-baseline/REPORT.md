# Claim checker report

Mechanical checks of every claim in `research/readiness/claims/`. A pass means the
sources are held, the quotations are word for word, the dates and order numbers are
possible, and the Stage 19 gate's structure is met. **It is not a legal conclusion.**

- Claims checked: 5 (parse errors: 1)
- Orders with a claim (latest claim per order): 2
- All checks passed: 2
- Mechanical checks passed: 2; with unverifiable items: 0; failed: 3
- Structural gate passed: 4

## Source references

- held_but_different_hash: 1
- held_bytes_verified: 152
- no_hash_in_reference: 1

## Quotations

- exact: 222
- not_found: 1
- other_copy_exact: 2

## Claims with problems (first 100)

| claim | order | problems |
|---|---|---|
| `/workspace/scratch/4816516465a6/refusal-claims.jsonl:3` | EO:13128 | source_held:held_but_different_hash@original_representation |
| `/workspace/scratch/4816516465a6/refusal-claims.jsonl:4` | EO:13274 | source_held:no_hash_in_reference@original_representation; structural_gate:original_representation_provenance@- |
| `/workspace/scratch/4816516465a6/refusal-claims.jsonl:5` | EO:13128 | quote_verbatim:not_found@operative_clauses[0].original_operative_text |
| `/workspace/scratch/4816516465a6/refusal-claims.jsonl:6` | None | parse:not_json_object |

## Source identity (is the cited original this order's?)

- recorded_for_this_order: 74

Details: `CLAIM_CHECKS.csv` (one row per check that did not pass; mode `non_pass_rows`). Per claim: `PER_CLAIM.json`.
