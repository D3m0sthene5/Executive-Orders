#!/usr/bin/env python3
"""Deterministic subtype classification and reproducible test selection for Stage 8 (retirement P2, NRA P2)."""
import json, re, hashlib, pathlib, collections
S = pathlib.Path('/home/claude/eo_work/stage7/inputs/split/EO_STAGE7_SPLIT')
W = pathlib.Path('/home/claude/eo_work/stage8/work')
done7 = {json.loads(l)['instrument_id'] for l in open('/home/claude/eo_work/stage7/package/OPUS_STAGE7_NIRA_RETIREMENT_STATUS_DELTA/OPUS_STATUS_DECISIONS.jsonl')}
h = lambda i, salt: hashlib.sha256((salt + '|' + i).encode()).hexdigest()
DATE = re.compile(r'until\s+(?:the\s+)?(?:[A-Z][a-z]{2,4}\.?\s+\d{1,2},\s+\d{4}|\w+\s+\d{4}|\d{4})', re.I)
def ret_type(t, d):
    tl = t.lower()
    if re.search(r'\b(all|employees of|persons|officers and employees|class|positions|any employee)\b', tl) and not re.search(r'^[A-Z][a-z]+ [A-Z]', t): return 'class_or_general'
    if 'further' in tl or 'extend' in tl: return 'extension'
    if DATE.search(t): return 'fixed_term'
    if re.search(r'such period|indefinite|until further|duration', tl): return 'open_ended'
    if int(d[:4]) >= 1945: return 'postwar_other'
    return 'undated_personal'
def nra_type(t):
    tl = t.lower()
    if re.search(r'contract|procure|purchas|bid|appropriat|allot|fund|loan|tariff|import|lease|land|license|agricultur|marketing agreement|employment|relief|public works|reemployment|president.s reemployment', tl): return 'C_mixed_candidate'
    if re.search(r'amend|modif|supplement|exemption|exempt|stay|extension|extend|interpret|cancel|revis|terminat|suspend', tl): return 'B_amendment_or_modification'
    if re.search(r'code of fair competition|approv', tl): return 'A_code_system_only'
    return 'C_mixed_candidate'
out = {}
for f, kind in [('OPUS_RETIREMENT_P2_284.jsonl', 'ret'), ('OPUS_NIRA_P2_87.jsonl', 'nra')]:
    rows = [json.loads(l) for l in open(S / f)]
    rows = [r for r in rows if r['instrument_id'] not in done7]
    for r in rows:
        r['subtype'] = ret_type(r['title'] or '', r['date'] or '1900') if kind == 'ret' else nra_type(r['title'] or '')
    out[kind] = rows
    print(f, len(rows), dict(collections.Counter(r['subtype'] for r in rows)))
# reproducible test selection, proportional across subtypes, at least 2 per subtype
def pick(rows, n, salt):
    by = collections.defaultdict(list)
    for r in rows: by[r['subtype']].append(r)
    for k in by: by[k].sort(key=lambda r: h(r['instrument_id'], salt))
    alloc = {k: max(2, round(n * len(v) / len(rows))) for k, v in by.items()}
    while sum(alloc.values()) > n: alloc[max(alloc, key=lambda k: alloc[k])] -= 1
    return [r for k in by for r in by[k][:min(alloc[k], len(by[k]))]]
tests = {'ret': pick(out['ret'], 20, 'S8-RET-TEST'), 'nra': pick(out['nra'], 15, 'S8-NRA-TEST')}
for k in out:
    with open(W / f'{k}_classified.jsonl', 'w') as fh:
        for r in out[k]: fh.write(json.dumps(r, ensure_ascii=False) + '\n')
json.dump({k: [r['instrument_id'] for r in v] for k, v in tests.items()} | {'method': 'sha256(salt|id) order within subtype; proportional allocation, min 2'}, open(W / 'TEST_SELECTION.json', 'w'), indent=1)
for k, v in tests.items():
    print(k, len(v), dict(collections.Counter(r['subtype'] for r in v)))
    for r in v[:6]: print('  ', r['instrument_id'], r['date'], r['subtype'], (r['title'] or '')[:95])
