#!/usr/bin/env python3
"""Deterministically build OPUS_STAGE7_NIRA_RETIREMENT_STATUS_DELTA from validated producer shards and reviewer records.
Acceptance rule: a status counts as accepted only with an independent review record whose verdict is 'accept'.
Reviewer values override producer values where they differ (recorded). Later reviews of the same ID (V_NRA2 after V_NRA) are not expected."""
import json, pathlib, hashlib, shutil, collections, subprocess, sys, datetime
R = pathlib.Path('/home/claude/eo_work/stage8'); W = R / 'work'
R7 = pathlib.Path('/home/claude/eo_work/stage7')
S = R7 / 'inputs/split/EO_STAGE7_SPLIT'
OUT = R / 'package/OPUS_STAGE8_STATUS_DELTA'
V1_ZIP = pathlib.Path('/home/claude/eo_work/preserved_v1/CLAUDE_CAUSE_V1_DELTA.zip')
S7_ZIP = pathlib.Path('/home/claude/eo_work/stage7/package/OPUS_STAGE7_NIRA_RETIREMENT_STATUS_DELTA.zip')
S7_EXPECTED = '7591b10a3aebfedfc26c6633664578e988e83cda3ddab825991dbaa5df7aec15'
V1_EXPECTED = 'ab0da856772a3e18019899483e1cfe9a3ceee80a98a48ec591d006a68c46acf8'
DENOM = 14973
def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def load(p): return [json.loads(l) for l in open(p, encoding='utf-8') if l.strip()] if pathlib.Path(p).exists() else []
def dump(n, rows):
    with open(OUT / n, 'w', encoding='utf-8') as f:
        for r in rows: f.write(json.dumps(r, ensure_ascii=False, sort_keys=True) + '\n')
v = subprocess.run([sys.executable, str(R7 / 'code/validate_status_shard.py'), '--all', str(W / 'shards')], capture_output=True, text=True)
v2 = subprocess.run([sys.executable, str(R7 / 'code/validate_status_shard.py'), '--all', str(W / 'reviews')], capture_output=True, text=True)
if v.returncode or v2.returncode: sys.exit('validator errors\n' + v.stdout + v2.stdout)
if OUT.exists(): shutil.rmtree(OUT)
(OUT / 'sources').mkdir(parents=True)
scope = {}
for f in ['OPUS_NIRA_P1_213.jsonl', 'OPUS_NIRA_P2_87.jsonl', 'OPUS_NIRA_P3_MIXED_16.jsonl', 'OPUS_RETIREMENT_P1_198.jsonl', 'OPUS_RETIREMENT_P2_284.jsonl']:
    for r in load(S / f): scope[r['instrument_id']] = r
astra = {r['instrument_id'] for f in ['ASTRA_CIVIL_P1_705.jsonl', 'ASTRA_CIVIL_P2_476.jsonl'] for r in load(S / f)}
import re
# Corrections named explicitly in reviewer reports (V_NRA: end-date term; V_NRA2: own time limits not recorded, later amending orders missed).
CORR_IDS = {'EO:6205C','EO:6209A','EO:6209B','EO:6221B','EO:6652','EO:6813','EO:6945A'}  # V8_NRA: end-date or reasoning corrections
CORR_IDS |= {json.loads(l)['instrument_id'] for l in open(W / 'shards/RB_retirement_p2_late/status_proposals.jsonl') if 'RET-R2' in (json.loads(l).get('rule_id') or '')}  # V8_RET: 'no later than' wording
REV_CORR = {'V8_RET': 'RB RET-R2 end basis must read no later than 1978-09-30', 'V8_NRA': 'sec. 4 agreements and wage-agreement approvals end 1936-04-01, not 1935-06-14'}
reviews = {}
for rd in sorted((W / 'reviews').iterdir()):
    for r in load(rd / 'reviews.jsonl'):
        assert r['instrument_id'] not in reviews, 'duplicate review ' + r['instrument_id']
        reviews[r['instrument_id']] = dict(r, reviewer=rd.name)
props, ev, rules, queue, conflicts = [], [], [], [], []
files = {}
def loc(tp, base):
    p = pathlib.Path(tp); p = (p if p.is_absolute() else base / tp).resolve()
    if str(p) in files: return files[str(p)]
    if p.exists() and str(p).startswith(str(W)):
        rel = p.relative_to(W); d = OUT / 'sources' / rel; d.parent.mkdir(parents=True, exist_ok=True); shutil.copy2(p, d)
        files[str(p)] = {'package_path': 'sources/' + str(rel), 'sha256': sha(p)}
    else:
        files[str(p)] = {'external_path': str(p), 'sha256': sha(p) if p.exists() else None}
    return files[str(p)]
for kind in ('shards', 'reviews'):
    for sd in sorted((W / kind).iterdir()):
        ns = lambda i, s=sd.name: f'{s}/{i}'
        for e in load(sd / 'evidence.jsonl'):
            ev.append(dict(e, evidence_id=ns(e['evidence_id']), shard_id=sd.name, text_locator=loc(e['text_path'], sd)))
        for r in load(sd / 'rules.jsonl'): rules.append(dict(r, shard_rule_id=ns(r['rule_id']), shard_id=sd.name))
        for q in load(sd / 'queue.jsonl'): queue.append(dict(q, shard_id=sd.name))
        for c in load(sd / 'conflicts.jsonl'): conflicts.append(dict(c, shard_id=sd.name))
        if kind == 'shards':
            for x in load(sd / 'status_proposals.jsonl'):
                x = dict(x)
                for k in ('evidence_ids', 'controlling_authority_evidence_ids'): x[k] = [ns(i) for i in x.get(k, [])]
                for fp in x.get('operative_footprint', []): fp['evidence_ids'] = [ns(i) for i in fp.get('evidence_ids', [])]
                x['rule_id'] = ns(x['rule_id']) if x.get('rule_id') else None
                props.append(x)
for sd in (W / 'shards').iterdir():
    if (sd / 'SHARD_REPORT.md').exists():
        (OUT / 'reports').mkdir(exist_ok=True); shutil.copy2(sd / 'SHARD_REPORT.md', OUT / 'reports' / f'{sd.name}_SHARD_REPORT.md')
for rd in (W / 'reviews').iterdir():
    for n in ('REVIEW_REPORT.md', 'rule_review.md'):
        if (rd / n).exists(): (OUT / 'reports').mkdir(exist_ok=True); shutil.copy2(rd / n, OUT / 'reports' / f'{rd.name}_{n}')
for f in (W / 'shared_cache').glob('*'):
    if f.is_file(): loc(str(f), W)
for f in ['STATUS_WORKER_PROTOCOL.md', 'STAGE8_JOB_REGISTRY.json', 'TEST_SELECTION.json', 'ret_classified.jsonl', 'nra_classified.jsonl', 'NEXT_FAMILY_CANDIDATES.json']: shutil.copy2(W / f, OUT / f)
(OUT / 'code').mkdir(); [shutil.copy2(f, OUT / 'code' / f.name) for f in (R / 'code').glob('*.py')]; shutil.copy2(R7 / 'code/validate_status_shard.py', OUT / 'code/validate_status_shard.py')
decisions = []
for x in sorted(props, key=lambda x: x['instrument_id']):
    i = x['instrument_id']; rv = reviews.get(i); sc = scope[i]
    verdict = rv['verdict'] if rv else 'unreviewed'
    rs, ra = (rv or {}).get('reviewer_substantive_effect'), (rv or {}).get('reviewer_any_operative_effect')
    acc = verdict == 'accept'
    d = {'instrument_id': i, 'stage6_decision_id': sc['stage6_decision_id'], 'family': sc['family'], 'priority': sc['priority'],
         'title': sc['title'], 'date': sc['date'],
         'stage6_baseline': {'substantive_effect': sc['baseline_substantive_effect'], 'any_operative_EO_effect': sc['baseline_any_operative_EO_effect']},
         'producer_proposal': x, 'review': rv, 'review_verdict': verdict,
         'accepted_substantive_effect': (rs or x['proposed_substantive_effect']) if acc else None,
         'accepted_any_operative_effect': (ra or x['proposed_any_operative_effect']) if acc else None,
         'status_state': ('independently_accepted' + ('_with_reviewer_correction' if acc and i in CORR_IDS else '')) if acc else verdict,
         'reviewer_note': (rv or {}).get('problems'),
         'reviewer_differs_from_producer': bool(rv) and ((rs and rs != x['proposed_substantive_effect']) or (ra and ra != x['proposed_any_operative_effect']))}
    if verdict == 'reject' and rs in ('yes', 'no'): d['status_state'] = 'reviewer_determination_pending_confirmation'
    d['shard_id'] = x.get('shard_id')
    d['new_determinate_substantive'] = acc and d['accepted_substantive_effect'] in ('yes', 'no')
    decisions.append(d)
dec_ids = [d['instrument_id'] for d in decisions]
checks = {
    'all_decisions_in_opus_scope': all(i in scope for i in dec_ids),
    'no_overlap_with_astra_civil_1181': not (set(dec_ids) & astra), 'astra_reserved_count': len(astra),
    'no_duplicate_decisions': len(dec_ids) == len(set(dec_ids)),
    'all_baselines_stage6_indeterminate': all(scope[i]['baseline_substantive_effect'] == 'indeterminate' for i in dec_ids),
    'every_review_matches_a_proposal': set(reviews) <= set(dec_ids),
    'split_package_sha256': sha(R7 / 'inputs/EO_Stage7_Astra_Opus_Split_2026-10-15.zip'),
    'split_manifest_hashes_verified': subprocess.run([sys.executable, '-I', str(S / 'VERIFY_SCOPES.py')], capture_output=True).returncode == 0,
    'stage6_release_verified': False,
    'stage6_note': 'Stage 8 again received no Stage 6 archive or ledger. The Stage 6 release archive (sha256 9a9a3f1b… per SCOPE_ACCOUNTING.json) and ledger (e3386a07…) were not supplied to this session. Baseline values come from the hash-verified split package. Astra must confirm at integration that no listed ID was accepted after Stage 6.',
    'v1_causal_archive_sha256': sha(V1_ZIP), 'v1_causal_archive_unchanged': sha(V1_ZIP) == V1_EXPECTED,
    'stage7_delta_sha256': sha(S7_ZIP), 'stage7_delta_unchanged': sha(S7_ZIP) == S7_EXPECTED,
    'no_overlap_with_stage7_opus_decisions': not (set(dec_ids) & {json.loads(l)['instrument_id'] for l in open(R7 / 'package/OPUS_STAGE7_NIRA_RETIREMENT_STATUS_DELTA/OPUS_STATUS_DECISIONS.jsonl')}),
    'no_overlap_with_v1_scope': not (set(dec_ids) & {l.strip() for l in open('/home/claude/eo_work/claude_v1/out/CLAUDE_SCOPE_V1_IDS.txt')}),
    'no_overlap_with_v5_opus': not (set(dec_ids) & {json.loads(l)['instrument_id'] for l in open(R7 / 'package/OPUS_STAGE7_NIRA_RETIREMENT_STATUS_DELTA/CLAUDE_NEW_NO_V5_OPUS.jsonl')}),
    'v2_v3_v4_v5_astra_lists_available': False,
    'v_lists_note': 'V2-V4 and V5_ASTRA membership files were not supplied. All Stage 8 IDs were Stage 6 indeterminate per the split package, so they cannot be in any earlier substantive-NO cohort; Astra should confirm against its V2-V5 files at merge.',
    'stage8_writes_outside_stage8_dir': False}
assert all(checks[k] for k in ['all_decisions_in_opus_scope', 'no_overlap_with_astra_civil_1181', 'no_duplicate_decisions', 'all_baselines_stage6_indeterminate', 'every_review_matches_a_proposal', 'split_manifest_hashes_verified', 'v1_causal_archive_unchanged', 'stage7_delta_unchanged', 'no_overlap_with_stage7_opus_decisions', 'no_overlap_with_v1_scope', 'no_overlap_with_v5_opus'])
C = collections.Counter
acc = [d for d in decisions if d['review_verdict'] == 'accept']
newdet = [d for d in decisions if d['new_determinate_substantive']]
by_fam = {}
for fam in ('nira_fair_competition_codes', 'retirement_exemptions'):
    ds = [d for d in decisions if d['family'] == fam]
    by_fam[fam] = {'proposals': len(ds), 'by_priority': dict(C(d['priority'] for d in ds)),
                   'texts_obtained': sum(bool(d['producer_proposal'].get('text_obtained')) for d in ds),
                   'footprints_complete': sum(bool(d['producer_proposal'].get('footprint_complete')) for d in ds),
                   'review_verdicts': dict(C(d['review_verdict'] for d in ds)),
                   'accepted_substantive': dict(C(d['accepted_substantive_effect'] for d in ds if d['review_verdict'] == 'accept')),
                   'accepted_any_effect': dict(C(d['accepted_any_operative_effect'] for d in ds if d['review_verdict'] == 'accept')),
                   'new_determinate_substantive': sum(d['new_determinate_substantive'] for d in ds),
                   'accepted_with_reviewer_correction': sum(d['status_state'].endswith('correction') for d in ds)}
eff = json.load(open(W / 'EFFICIENCY_INPUTS.json'))
for fam, e in eff['families'].items():
    n = by_fam[fam]['new_determinate_substantive']; hrs = e['family_clock_minutes'] / 60; mt = sum(e['subagent_tokens'].values()) / 1e6
    e.update({'accepted_new_determinate': n, 'accepted_per_hour': round(n / hrs, 1), 'accepted_per_million_subagent_tokens': round(n / mt, 1),
              'subagent_tokens_total': sum(e['subagent_tokens'].values())})
by_shard = {sd: dict(C(d['status_state'] for d in decisions if d['shard_id'] == sd)) for sd in sorted({d['shard_id'] for d in decisions})}
results = {'by_shard': by_shard, 'denominator': DENOM, 'stage6_substantive_determinate': 1478, 'stage7_combined_provisional_determinate': 1889,
           'new_accepted_determinate_substantive': len(newdet),
           'new_accepted_no_no': sum(1 for d in newdet if d['accepted_substantive_effect'] == 'no' and d['accepted_any_operative_effect'] == 'no'),
           'new_accepted_yes': sum(1 for d in newdet if d['accepted_substantive_effect'] == 'yes'),
           'coverage_before_pct': round(100 * 1889 / DENOM, 4), 'coverage_after_pct_if_integrated': round(100 * (1889 + len(newdet)) / DENOM, 4),
           'gain_percentage_points': round(100 * len(newdet) / DENOM, 4),
           'by_family': by_fam, 'efficiency': eff, 'integrity_checks': checks,
           'queue_items': len(queue), 'conflicts': len(conflicts)}
dump('OPUS_STATUS_DECISIONS.jsonl', decisions)
dump('OPUS_STATUS_REVIEWS.jsonl', [reviews[i] for i in sorted(reviews)])
dump('OPUS_STATUS_EVIDENCE.jsonl', ev); dump('OPUS_STATUS_RULES.jsonl', rules)
dump('OPUS_STATUS_QUEUE.jsonl', queue + [{'instrument_id': d['instrument_id'], 'blocker': (d['review'] or {}).get('problems'), 'review_verdict': d['review_verdict'], 'shard_id': 'review'} for d in decisions if d['review_verdict'] in ('hold', 'reject')])
dump('OPUS_STATUS_CONFLICTS.jsonl', conflicts)
dump('CLAUDE_NEW_NO_V6_OPUS_PROVISIONAL.jsonl', [{'instrument_id': d['instrument_id'], 'stage6_decision_id': d['stage6_decision_id'], 'family': d['family'],
      'accepted_substantive_effect': 'no', 'accepted_any_operative_effect': d['accepted_any_operative_effect'], 'status_state': d['status_state'],
      'causal_research_state': 'not_started', 'cohort': 'V6_OPUS_PROVISIONAL_pending_V5_merge'} for d in newdet if d['accepted_substantive_effect'] == 'no'])
json.dump(results, open(OUT / 'OPUS_STAGE8_RESULTS.json', 'w'), indent=1)
json.dump(checks, open(OUT / 'INTEGRITY_AND_NONOVERLAP.json', 'w'), indent=1)
man = [{'path': str(p.relative_to(OUT)), 'sha256': sha(p), 'bytes': p.stat().st_size} for p in sorted(OUT.rglob('*')) if p.is_file()]
json.dump({'package': OUT.name, 'built_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'files': man}, open(OUT / 'MANIFEST.json', 'w'), indent=1)
print(json.dumps({k: v for k, v in results.items() if k not in ('integrity_checks',)}, indent=1))
