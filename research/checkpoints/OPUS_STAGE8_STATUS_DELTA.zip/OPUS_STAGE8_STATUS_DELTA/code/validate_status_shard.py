#!/usr/bin/env python3
"""Validate an Opus Stage 7 status shard (status_proposals.jsonl) or a review directory (reviews.jsonl).
Usage: python3 validate_status_shard.py <dir>   |   python3 validate_status_shard.py --all <shards_root>"""
import json, pathlib, re, sys
VAL = {"yes", "no", "indeterminate"}
GRADES = {"primary_operative_text", "hosted_transcript", "official_compilation", "index_only"}
CONF = {"high", "medium", "low"}
RULE_FIELDS = ["rule_id", "sources", "legal_authority", "covered_ids", "applicability_predicates", "exceptions",
               "savings_or_surviving_effects", "what_evidence_proves", "what_remains_inferential", "substantive_result", "any_effect_result"]
def norm(s): return re.sub(r"\s+", " ", s).strip()
def load(p):
    if not p.exists(): return []
    out = []
    for i, l in enumerate(p.open(encoding="utf-8")):
        if l.strip():
            try: out.append(json.loads(l))
            except json.JSONDecodeError as e: raise SystemExit(f"{p}:{i+1}: invalid JSON: {e}")
    return out
def check_evidence(sd, ev, errs, warns):
    for e in ev.values():
        q, tp = e.get("quote"), e.get("text_path")
        if not q or not tp: errs.append(f"evidence {e.get('evidence_id')}: missing quote/text_path"); continue
        p = pathlib.Path(tp); p = p if p.is_absolute() else sd / tp
        if not p.exists(): errs.append(f"evidence {e.get('evidence_id')}: file not found {tp}"); continue
        t = p.read_text(encoding="utf-8", errors="replace")
        if q in t: continue
        if norm(q) in norm(t): warns.append(f"evidence {e.get('evidence_id')}: whitespace-normalized match only"); continue
        errs.append(f"evidence {e.get('evidence_id')}: quote not verbatim in {tp}")
def validate(sd):
    sd = pathlib.Path(sd); errs, warns = [], []
    packet = {r["instrument_id"] for r in load(sd / "packet.jsonl")}
    ev = {e.get("evidence_id"): e for e in load(sd / "evidence.jsonl")}
    rules = {r.get("rule_id"): r for r in load(sd / "rules.jsonl")}
    check_evidence(sd, ev, errs, warns)
    for r in rules.values():
        miss = [f for f in RULE_FIELDS if f not in r]
        if miss: errs.append(f"rule {r.get('rule_id')}: missing {miss}")
    props = load(sd / "status_proposals.jsonl"); seen = set()
    for x in props:
        i = x.get("instrument_id")
        if i in seen: errs.append(f"{i}: duplicate")
        seen.add(i)
        if i not in packet: errs.append(f"{i}: not in packet")
        s, a = x.get("proposed_substantive_effect"), x.get("proposed_any_operative_effect")
        if s not in VAL or a not in VAL: errs.append(f"{i}: bad proposed values"); continue
        if s == "yes" and a == "no": errs.append(f"{i}: substantive yes with any-effect no is impossible")
        if a == "no" and s != "no": errs.append(f"{i}: any-effect no requires substantive no")
        if x.get("confidence") not in CONF: errs.append(f"{i}: confidence")
        if x.get("text_source_grade") not in GRADES: errs.append(f"{i}: text_source_grade")
        for e in x.get("evidence_ids", []) + x.get("controlling_authority_evidence_ids", []):
            if e not in ev: errs.append(f"{i}: evidence {e} missing")
        for fp in x.get("operative_footprint", []):
            for e in fp.get("evidence_ids", []):
                if e not in ev: errs.append(f"{i}: footprint evidence {e} missing")
        if "indeterminate" in (s, a) and not x.get("hold_reason"): errs.append(f"{i}: indeterminate needs hold_reason")
        if s != "indeterminate":
            if not x.get("text_obtained") or not x.get("footprint_complete"): errs.append(f"{i}: determinate status needs text_obtained and footprint_complete")
            if x.get("text_source_grade") == "index_only": errs.append(f"{i}: determinate status cannot rest on index_only")
            if not x.get("operative_footprint") or not x.get("evidence_ids"): errs.append(f"{i}: determinate status needs footprint and evidence")
            if not (x.get("subsequent_change_check") or {}).get("searched"): errs.append(f"{i}: subsequent_change_check.searched required")
        if x.get("rule_id"):
            if x["rule_id"] not in rules: errs.append(f"{i}: rule {x['rule_id']} not in rules.jsonl")
            elif i not in rules[x["rule_id"]].get("covered_ids", []): errs.append(f"{i}: not in covered_ids of {x['rule_id']}")
    missing = packet - seen
    if missing and props: errs.append(f"{len(missing)} packet IDs without proposal: {sorted(missing)[:8]}")
    revs = load(sd / "reviews.jsonl")
    for r in revs:
        if r.get("verdict") not in {"accept", "hold", "reject"}: errs.append(f"review {r.get('instrument_id')}: verdict")
        for e in r.get("reviewer_evidence_ids", []):
            if e not in ev: errs.append(f"review {r.get('instrument_id')}: evidence {e} missing")
    return errs, warns, len(props) + len(revs)
if __name__ == "__main__":
    if sys.argv[1] == "--all":
        bad = 0
        for sd in sorted(pathlib.Path(sys.argv[2]).iterdir()):
            if sd.is_dir():
                e, w, n = validate(sd); print(f"{sd.name}: {n} records, {len(e)} errors, {len(w)} warnings"); bad += bool(e)
        sys.exit(1 if bad else 0)
    e, w, n = validate(sys.argv[1])
    for x in e: print("ERROR", x)
    for x in w: print("WARN ", x)
    print(f"{n} records; {len(e)} errors; {len(w)} warnings"); sys.exit(1 if e else 0)
