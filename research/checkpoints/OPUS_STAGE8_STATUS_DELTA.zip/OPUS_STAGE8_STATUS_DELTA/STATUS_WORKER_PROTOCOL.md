# Opus Stage 7 status-research protocol (NRA codes and compulsory-retirement exemptions)

Project: The Afterlife of Executive Orders. Historical cutoff: October 14, 2026, America/New_York. Codebook 2.0.0. This is present-status research, delegated to Opus for the exact IDs in your packet only. It is separate from the earlier Claude V1 causal work: never read from or write to /home/claude/eo_work/claude_v1 or /home/claude/eo_work/preserved_v1.

## Question for each instrument

As of the cutoff, does the order still have (a) a substantive legal effect, and (b) any operative legal effect of its own? Each answer is `yes`, `no`, or `indeterminate`. Every packet instrument is `indeterminate` in the accepted Stage 6 ledger; your record is a proposal that an independent reviewer must accept before it counts.

Codebook rules that bind you:
- **Full original footprint.** Identify every operative provision of the order from its own text: who is commanded or permitted to do what, under which authority, for how long. A title, an index entry or Lord's 1944 summary is not the operative text and cannot support a `no`.
- **Substantive `no`** only if every substantive provision has ended. **Any-effect `no`** only if every provision, including residual ones, has ended. Historical consequences and acts already completed under the order are not continuing effects (TC04, TC07), but a continuing status, right or duty created by the order is.
- **Subsequent-change check.** Before a `no`, look for later orders, statutes or proclamations that extended, revived, amended or saved the provision, and record exactly what you checked (disposition tables, Federal Register listing metadata in the local Stage 1 `modern` sources, later orders naming the same person or code).
- **Deadlines and dates.** A historical date in a title is not proof; confirm it in the operative text. Do not infer an ending from a person's presumed death or age, or from the age of the order.
- **Mixed instruments.** If an order did anything besides the family's core function (for NRA: anything besides approving a code; for retirement: anything besides exempting named persons), decide that provision separately. If its scope or ending cannot be established, propose `indeterminate` with a hold reason.
- **Conflicts.** If evidence contradicts an accepted Stage 6 status or an Astra-owned record, write a conflict record; never edit inherited files.

## Sources

Packet rows list local sources (`local_sources`, mostly Lord 1944 list entries and Federal Register listing metadata). Shared framework texts and rule specifications are in /home/claude/eo_work/stage7/work/shared_cache/ (Stage 7, read-only) and /home/claude/eo_work/stage8/work/shared_cache/ (Stage 8); read every `*_RULE_SPEC.md` in both before your first decision and reuse cached files rather than refetching. The shell cannot reach the internet; use WebFetch on direct official URLs (govinfo.gov Federal Register document PDFs, federalregister.gov, presidency.ucsb.edu document pages, archives.gov disposition tables, HathiTrust or Library of Congress pages for NRA code volumes). WebSearch may be unavailable or limited; do not depend on it. Save each fetched source to your shard's `cache/<source_id>.txt` with a first header line giving the URL, retrieval time (UTC) and "WebFetch rendering; original bytes not stored". Quotations must be exact substrings of a saved file.

Retrieve each shared source once. When several orders share a chain (the same person or office), retrieve and check the chain once.

## Output files (JSON Lines in your shard directory)

`status_proposals.jsonl`, exactly one per packet instrument:
```
{"instrument_id": "EO:5881", "stage6_decision_id": "decision:v2:EO:5881", "shard_id": "...", "family": "retirement_exemptions",
 "proposal_id": "opus:s7:status:EO:5881",
 "proposed_substantive_effect": "no|yes|indeterminate",
 "proposed_any_operative_effect": "no|yes|indeterminate",
 "operative_footprint": [{"provision": "exempts W. L. Hill from compulsory retirement until Aug. 1, 1932", "authority": "...", "end": {"date": "1932-08-01", "basis": "..."}, "evidence_ids": [...]}],
 "footprint_complete": true,
 "text_obtained": true,
 "text_source_grade": "primary_operative_text|hosted_transcript|official_compilation|index_only",
 "controlling_authority_evidence_ids": [...],
 "subsequent_change_check": {"searched": ["..."], "findings": "..."},
 "chain": {"group_id": "...", "related_orders": [...], "final_end_date": "..."},
 "residual_effects_considered": "...",
 "rule_id": "<rule id or null>",
 "evidence_ids": [...],
 "confidence": "high|medium|low",
 "hold_reason": null,
 "producer_state": "producer_supported_pending_independent_review"}
```
`proposed_* = indeterminate` requires `hold_reason` naming the missing fact and the source that would settle it. `no` requires `text_obtained: true`, `footprint_complete: true` and a text grade other than `index_only`.

`evidence.jsonl`: `{"evidence_id", "source_id", "source_title", "source_url", "source_date", "text_path", "quote", "locator", "retrieval_method": "local_cache|webfetch", "evidence_grade", "supports"}`.

`rules.jsonl`: one record per shared rule: `rule_id, sources, legal_authority, covered_ids, applicability_predicates, exceptions, savings_or_surviving_effects, what_evidence_proves, what_remains_inferential, substantive_result, any_effect_result`. Every covered instrument must meet the predicates individually.

`conflicts.jsonl`, `queue.jsonl` (`{"instrument_id", "blocker", "source_that_would_settle_it", "priority"}`), and `SHARD_REPORT.md` (counts by proposed status, texts obtained, footprints completed, retrieval failures, elapsed time from your first to last action).

Write records as you finish each instrument or chain, so completed work survives an interruption. Run `python3 /home/claude/eo_work/stage7/code/validate_status_shard.py <your shard dir>` (the Stage 7 validator, reused unchanged) until it reports 0 errors. Do not launch agents. Final reply: at most 8 lines.
