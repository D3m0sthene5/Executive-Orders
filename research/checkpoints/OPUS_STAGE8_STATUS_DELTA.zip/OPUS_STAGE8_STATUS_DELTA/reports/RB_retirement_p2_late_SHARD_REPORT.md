# SHARD_REPORT: RB_retirement_p2_late (producer RB, Opus Stage 8)

Cutoff Oct. 14, 2026; codebook 2.0.0. Start 2026-10-15T21:31:33Z; end 2026-10-15T21:56:36Z (UTC); elapsed about 26 minutes. Validator (`stage7/code/validate_status_shard.py`): 131 records, 0 errors, 0 warnings.

## Results

| Proposed status (substantive / any effect) | Count | Rule |
|---|---|---|
| no / no | 103 | RET-R1 |
| no / no (from 1978-09-30) | 13 | RET-R2: EO 8887, 9238, 10021, 10094, 10146, 10151, 10198, 10239, 10315, 10330, 10333, 10364, 10405 |
| no / no | 1 | none (decided individually): EO 8997, a class exemption of Post Office field employees reaching the age in Dec. 1941, ending Dec. 31, 1942 for every member |
| indeterminate / indeterminate | 14 | none |

Operative text was obtained for 122 of the 131 orders, all as APP hosted transcripts: 117 fetched by this shard and 5 reused from RT's cache (EO 8804, 8844, 11642, 11704, 12000). Every saved capture shows the beneficiary, the authority clause and the period. All 77 orders with undated titles state a period in their text except EO 8887 (conditional) and EO 9238 (none). Footprints are complete for those 122 orders.

The RET-R1 dates were confirmed in each order's text. Chains whose later orders are all dated and were read: Harper, Edwards (EO 8844 amends EO 8827 to Oct. 31, 1942), Mayer (EO 10569 amends EO 10334 to Dec. 31, 1954), MacIntyre, Gillilland, Sauer, Flemming (ends June 30, 1978) and Minetti (five orders, ends Aug. 31, 1978). EO 12031 (Kuykendall) ends Sept. 30, 1978. Medium confidence applies to EO 11378 (Quill), whose "three years" is counted from the order date and which has a clause preserving the Civil Service Commission's authority, and to EO 10569, an amending order. RET-R2 confidence is medium throughout. For Cone and Pyke (Collectors of Customs), the Q3 reading that this position is not a "customs and border protection officer" is flagged. For EO 8887 the Civil Service Commission register and physical-capacity conditions were treated as term-limiting clauses.

## Holds (14)

- **Operative text not obtained (9): EO 9780, 9895, 9954, 9956, 9963, 9966, 9973A, 9983, 10002 (1946-1948).** APP has no transcript of any of them. For two of the group, EO 9954 (13 FR 2283) and EO 9780 (11 FR 10645), the Federal Register printed only a heading and a filing or summary note. The Truman Library lists EO 9954 as "not published". The signed original or file copy (NARA RG 11 or the Truman Library), or 3 CFR 1943-1948 Comp., would settle these holds.
- **Chain held with an undated later order (2): EO 8904 (Latta → EO 9238) and EO 10225 (Pyke → EO 10333).** The V_RET reconciled P4 holds these orders. If the RET-R2 proposals for EO 9238 and EO 10333 are accepted, both orders become no/no under either reading.
- **EO 10073 (Eugene Black, Tax Court judge).** The exemption is limited to his present term of office, and no saved source gives the date that term expired. Q3 is also unestablished because the Tax Court retirement system (26 U.S.C. 7447) was not retrieved.
- **EO 11154 (J. Edgar Hoover, FBI Director).** Q3 is unestablished because 8335(b) kept mandatory separation for law enforcement officers, and no saved source shows whether the Director's position falls in that category. The order also contains a clause preserving the Civil Service Commission's exemption authority (the "non-limitation clause"). No inference was drawn from Hoover's death.
- **EO 11619 (Rose A. Conway).** The order is open-ended and has the same non-limitation clause. RET-R2 excludes orders with a second operative provision, so a reviewer must rule on whether this clause counts as one.

## Subsequent-change checks

The checks used:

- Stage 3 ledger titles, matched by surname and first initial, plus the officers that the FR note names in EO 9780.
- APP "compulsory retirement" search, 1939-1979, pages 1-2, reusing RT's page 0.
- APP "mandatory retirement" search, 1971-1978.
- NARA disposition-table See, Amends and Amended-by fields from the local Stage 1 sources.
- The Pub. L. 95-256 and 5 U.S.C. 8335 and 3323 notes in shared_cache.

No statute was refetched. EO 8420 was excluded from the Harper chain, following RT's conflict record. Two conflicts were recorded, and no inherited file was edited:

- EO 8969 (Hefty) is dated 1941 at APP, but the ledger and packet give 1946-12-11.
- EO 10151 (Hassett) is dated Aug. 11, 1950 at APP, but the ledger and NARA give Aug. 1, 1950.

## Fetches

There were 129 WebFetch calls in total:

- 117 were APP order texts.
- 8 were APP searches. Five of these succeeded. Two returned a server error and one was a refused retry; both failed searches are logged in `cache/fetch_failures.log`.
- 4 tried for the 1946-1948 texts (govinfo link service, govinfo FR issues for 1948-04-28 and 1946-09-21, and the Truman Library). None of these returned operative text.
