# SHARD_REPORT — NX_nra_p2_rest

The shard holds 72 NIRA-family orders. Seventy-one are proposed substantive **no** and any-effect **no**; one, the bituminous coal order EO 6299, is proposed **indeterminate** on both questions and held. Fifty-nine orders rest on rule `NRA-R1@NX` (`rules.jsonl`), which applies NRA-R1 with the reviewer's amended predicates. Twelve orders were decided on their own legal basis outside the rule. Confidence is high for 59 orders, medium for 12 and low for 1 (EO 6299). No conflicts were found; the queue holds EO 6299.

## Counts

- **Texts obtained:** 72 of 72, all American Presidency Project transcripts (grade `hosted_transcript`), each read through the signature and date line. The EO 6955-A text (an amendment of EO 6877) was also obtained for the subsequent-change check.
- **Footprints completed:** 72 of 72.
- **Proposals:** 71 no/no; 1 indeterminate/indeterminate.
- **Holds by reason:** 1, coal. EO 6299 approves the revised Bituminous Coal code and conditions the National Bituminous Coal Labor Board. The amended NRA-R1 keeps coal outside the rule until the operative text of the Bituminous Coal Conservation Act of 1935 (49 Stat. 991) is checked for adoption of the NRA coal code, its rates or its labor boards by reference. Only the Act's opening is cached, and the coal statute was not researched.
- **Fetches:** 94 WebFetch calls: 72 first text requests; 12 repeat requests after the extractor returned a summary instead of the text (6205C, 6209B, 6242D, 6296, 6320, 6329, 6767 once each, 6529 twice, 6284A three times); 1 request for the statement printed after the first signature of EO 6606-E; 1 for EO 6955-A; and 8 APP searches (5 date searches for orders missing from the Stage 7 listings, plus "Plastering and Lathing", "Work Assignment Board" and "basing point"). No slug guess failed. No framework source was refetched.
- **Time (UTC):** first action 2026-10-15T21:31:41Z; last action 2026-10-15T22:06Z (about 35 minutes).

## Corrected A/B/C assignments

The final assignment is A = 8, B = 55, C = 9 (pre-sort A = 11, B = 51, C = 10).

- **A to B:** 6242D (exemption denial), 6640 (Construction code Chapter III), 6871 (stay of code amendments and NIRB committees), 6925A (cancellation of a code approval).
- **A to C:** 6749 (allocation of an appropriation to the Secretary of the Interior), 6877 (direction to the Textile Labor Relations Board to appoint a work assignment board).
- **B to A:** 6606A (rule of construction for all codes on cooperatives).
- **B to C:** 6284A (Petroleum code modifications giving functions to a Federal Agency designated by the President), 6299 (coal; labor board condition), 6652 (Investment Bankers amendments including a NIRA sec. 4(a) agreement), 6730 (direction to the Federal Trade Commission), 6955 (Automobile code amendment confirming the March 1934 labor-settlement machinery).
- **C to B:** 6331A (exemption denial), 6606D and 7025A (Construction code chapters), 6794, 6903 and 7016 (Alcoholic Beverages Importing amendments; no import or sec. 3(e) provision).
- **C to A:** 6813 and 6945A (regional wage agreements approved under the Construction code, as EO 6949-A in the NT shard).
- **C confirmed:** 6296A, 6767.
- The four interim NIRA sec. 4 agreements (6205C, 6209A, 6209B, 6221B) stay A but were decided outside the rule because their core is an agreement rather than a sec. 3 code approval.

## Decisions outside the rule

- **Sec. 4 interim agreements (6205C, 6209A, 6209B, 6221B):** each bound an industry to code provisions pending its own code and was cancellable at any time. The silk, underwear and hosiery codes were later approved (EO 6330; Sept. 18, 1933 per EO 6347; EO 6258-C). The adopted provisions had force only as code standards (ended June 14, 1935), and Title I ended April 1, 1936. NIRA sec. 4(a) is not in the shared cache.
- **6284A (petroleum):** all provisions are code terms or code-body provisions. The order cites the NIRA generally, not sec. 9. Force ended June 14, 1935, and the Connally Act does not mention codes. Read in full on the fourth request.
- **6296A and 6749 (funding):** a one-time 1933 allocation for pre-June 1933 government contractors, and a fiscal-1935 petroleum appropriation allocated to Interior. Payments are completed; their objects ended by April 1, 1936. Account closure is reasoned from general appropriations law, not fetched.
- **6652:** the Art. X sec. 4(a) agreement and the Administrator's modification power ended by April 1, 1936 (Pub. Res. 26 proviso; sec. 2(c)).
- **6730:** the joint FTC-NRA basing-point study was a one-time task due within six months for code revision; the employee-election undertaking was carried out by EO 6751, whose later continuations (EO 7085, 7091) are separate instruments.
- **6767 (procurement):** relaxes code price-filing rules for public bids and modifies EO 6646 only to that extent; Pub. Res. 65 substituted the Acts of Congress for code provisions in bids. EO 6646 itself was not read.
- **6877 (labor board):** the work assignment board administered a code paragraph; EO 6955-A extended its charge to 30 days after its report; no later order names it.
- **6955:** every item is a code amendment; the confirmed March 1934 labor machinery was not created by this order.

## Notes

- **Own time limits recorded:** 6320 (30-day stock sale), 6510 (three-month learner rule to Mar. 11, 1934), 6513K (code expiration Sept. 4, 1934), 6620B (deletion effective on signing), 6861 (stay to Oct. 15, 1934; report Oct. 10), 6871 (stay to Dec. 1, 1934; reports Nov. 15, Dec. 1, 1934 and Jan. 15, 1935), 6767 (report within six months), 6730 (study within six months), 6877 (Feb. 1, 1935, extended by EO 6955-A), 6955 (code expiration June 16, 1935), 7025A (60-day NIRB review).
- **Alcohol orders (24 under the rule):** the Federal Alcohol Control Administration is treated as a Title I body, as the reviewer's amended P4 provides; the FAA Act of 1935 abolished it and adopts no code by reference.
- **Code text not on the APP page:** 6221B wage table (image), 6299 Schedule A (images), 6323 attached amendments, 6730 exhibits, 6964B Schedule A. These are code text and are noted in the records.
- **Extra fields:** each proposal also carries `abc_assignment` and `abc_assignment_note`.
