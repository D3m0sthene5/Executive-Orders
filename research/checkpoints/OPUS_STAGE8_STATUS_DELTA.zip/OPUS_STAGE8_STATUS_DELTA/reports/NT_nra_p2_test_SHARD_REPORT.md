# SHARD_REPORT — NT_nra_p2_test

The shard holds 15 NIRA-family test orders. All 15 are proposed substantive **no** and any-effect **no**, and none is held. Thirteen rest on rule `NRA-R1@NT` (`rules.jsonl`), which applies NRA-R1 with the reviewer's amended predicates. EO 6260A and EO 6497 fail P5 and were decided on their own legal basis outside the rule. Confidence is high for 13 orders and medium for 2 (EO 6260A and EO 6949A). No conflicts were found, and the queue is empty.

## Counts

- **Texts obtained:** 15 of 15, all American Presidency Project transcripts (grade `hosted_transcript`). Each was read through the signature and date line, and the extractor reported no truncation for any of them. EO 6467 drew an extractor summary on the first request; a second request returned every sentence verbatim.
- **Footprints completed:** 15 of 15.
- **Determinate proposals:** 15, all no/no. There are 0 holds.
- **Fetches:** 24 WebFetch calls, made up of 16 order texts (15 packet orders plus EO 7081), 1 retry, and 7 APP searches. Two of the searches returned no results. No slug guess failed: the guessed slugs for 6870A, 6876, 6895 and 6988A all resolved. No framework source was refetched.
- **Time (UTC):** first action 2026-10-15T21:14:29Z, last action 2026-10-15T21:26Z, about 12 minutes.

## Corrected A/B/C assignments

The final assignment is A = 1, B = 12, C = 2.

- **EO 6743** moves from A to B. It modifies the Baking code's effective date and its order of approval.
- **EO 6260A** moves from A to C. It delegates Title I powers and petroleum-code powers to the Secretary of the Interior.
- **EO 6497** moves from B to C. It amends EO 6247, which set the regulations on the preparation and style of executive orders and is not a Title I instrument.
- **EO 6988A** moves from C to B. It approves Subchapter II-C of the Construction code. Its only other provision lets the National Industrial Recovery Board (NIRB) review and stay a section of the code.
- **EO 6949A** moves from C to A. It approves a regional mason wage agreement made "pursuant to said Code", and its proviso lets the NIRB grant exemptions.
- The remaining 10 B orders are confirmed as B: 6467, 6876, 6837, 6895, 6945, 6487, 6870A, 6242C, 6242E and 6403. The three exemption denials (6242C, 6242E, 6403) are sec. 3(a) exemption decisions on an approved code.

## Decisions outside the rule

- **EO 6497.** Its only provision added paragraph 6 to EO 6247, exempting code-approval orders from those regulations. EO 7081 (June 20, 1935), fetched and read in full, revoked EO 6497 in terms. Lord 1944 shows that EO 7298 (Feb. 18, 1936) later replaced the EO 6247 regulations. The proposal is no/no with high confidence.
- **EO 6260A.** The order rests on NIRA title I sec. 2(b) and the Petroleum code. Its functions that depended on the code ended on June 14, 1935, and its title I delegation ended when Title I ceased on April 1, 1936. After 1935, the only presidential petroleum orders found rest on the Connally Act: EO 7129-A and EOs 7756–7759, known by title only. EO 7756 is a new delegation under that Act. The reviewer found that the Connally Act does not mention codes, the NIRA or executive orders. The outcome does not depend on reading the petroleum statutes further. Confidence is medium for two reasons: reading "such act" as reaching only Title I powers is an inference, and the text of sec. 2(b) is not in the shared cache.

## Notes

- **Own time limits.** Where an order fixed its own end date, the footprint records it. EO 6743 stayed the code until July 9, 1934 and gave the code authority until Nov. 15, 1934 to report. EO 6467 deferred a section to July 1, 1934, subject to a 10-day show-cause period. EO 6837 set the Automobile code's expiration at Nov. 5, 1934, and EO 6895 replaced that date with Feb. 1, 1935; a later amendment, EO 6955 (Jan. 31, 1935), is known by title only. EO 6988A gave the NIRB 60 days to review the subchapter.
- **Directions to Title I bodies.** These provisions end on April 1, 1936. They cover the NIRB in 6870A, 6949A and 6988A, the Puerto Rican Needlework Commission in 6870A, and the code authority in 6743.
- **EO 6870A.** The host order, EO 6756-B, is truncated on the APP page in its condition 5. EO 6870A revises only condition 4, which is complete in the host transcript and is quoted in full in EO 6870A, so the truncation does not affect P1 for EO 6870A.
- **EO 6949A.** NIRA sec. 7(b) was not fetched, so its role is inferential. If it applied, it was part of Title I and ceased on April 1, 1936.
- **No coal orders.** The shard contains no coal order, and no alcohol or petroleum statute was researched beyond the reviewer's caches.
- **Reused Stage 7 caches.** The shard reused cached texts of EO 6725A, 6578, 6684E, 6487B, 6756B and 7252, together with the N1 and N2 APP listings.
- **Extra fields.** Each proposal also carries `abc_assignment` and `abc_assignment_note`.
