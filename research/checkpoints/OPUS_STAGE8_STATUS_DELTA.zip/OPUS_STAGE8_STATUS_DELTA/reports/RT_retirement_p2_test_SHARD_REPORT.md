# SHARD_REPORT: RT_retirement_p2_test (producer RT, Opus Stage 8)

Cutoff Oct. 14, 2026; codebook 2.0.0. Start 2026-10-15T21:14:22Z; end 2026-10-15T21:31Z (UTC); elapsed about 17 minutes. Validator (`stage7/code/validate_status_shard.py`): 19 records, 0 errors, 0 warnings.

## Results

| Proposed status (substantive / any effect) | Count | Rule | Orders |
|---|---|---|---|
| no / no | 15 | RET-R1 | EO 8075, 8139, 8422, 8142, 8207, 8213, 8453, 8827, 8968, 9131, 8754, 9530, 10320, 11568, 11924 |
| no / no (from 1978-09-30) | 2 | RET-R2 | EO 11024 (Waterman, "indefinite period"), EO 10034 (J. M. Johnson, term-limited) |
| indeterminate / indeterminate | 2 | none | EO 5951, EO 7788 |

Texts were obtained for all 19 packet orders and for 5 chain orders (EO 8804, 8844, 11642, 11704, 12000), all as APP hosted transcripts. Each saved capture shows the authority clause. The 19 footprints are complete. Eleven of the 12 orders whose titles give no end date state one in their text. Glenn S. Smith, Hawkins, Booker, Barnes and McIntire each have a single dated grant. Harper, Jaggar and Bowerman have dated chains. In the Edwards chain, EO 8844 amends EO 8827 to Oct. 31, 1942. Sterling's order has an outer limit of Aug. 31, 1946.

Confidence is high for 13 RET-R1 orders. It is medium for EO 9530 (Hawley) and for both RET-R2 orders. The order for Hawley, a Foreign Service officer, runs "not to exceed the duration of the present emergency". Proclamation 2974 (saved) ended the 1939 and 1941 emergencies on Apr. 28, 1952. Its saving clause continues the 1939 emergency only for property held under the Act of Oct. 14, 1940. Reading "the present emergency" as those emergencies is inferential, but every plausible reading ends before the cutoff.

## Holds

- **EO 5951 (George R. Wales, 1932).** The exemption has no end date, names no position, and exempts Wales "from the provisions of that section" as a whole. That wording reaches sec. 204's reemployment bar, which is still in force at 5 U.S.C. 3323(a). RET-R2 therefore does not apply. A personnel record of Wales's position and separation, or an authoritative reading of exemptions in this form, would settle the hold.
- **EO 7788 (Joseph J. McGuigan, 1938).** The order rests on the Canal Zone Code, title 2, sec. 92, and continues McGuigan "until May 17, 1939, and thereafter until his successor is appointed and qualified." No saved source shows when a successor qualified. Canal Zone and Panama employment kept mandatory separation after 1978, so RET-R2 does not apply. The Senate Executive Journal, a Canal Zone annual report, or Pub. L. 96-70 would settle the hold.

## Statutes (Task 1; `shared_cache/RETIREMENT_R2_RULE_SPEC.md`, sources in `shared_cache/retirement_r2_sources/`)

The complete text of sec. 204 was read at 47 Stat. 404 through govinfo's link service (`govinfo.gov/link/statute/47/404`). The section has three parts:

1. a continuance bar, with the President's exemption power;
2. a bar on reappointing persons separated for age;
3. an exception for persons that an Act of Congress names for continuance.

None of these contains a saving clause. The margin note "Post, p. 1515" is unresolved, because 47 Stat. 1515 shows nothing on sec. 204.

The compulsory-retirement rule the orders relaxed changed over time. From 1932 to 1956 the exemptions relaxed sec. 204 together with the age rule of the 1930 Retirement Act. From 1956 to 1966 the source was CSRA sec. 5 (5 U.S.C. 2255; the orders cite 2255, not 2256). From 1966 to 1978 it was 5 U.S.C. 8335(a), with exemptions granted under 8335(c); sec. 204 was restated as 3323(a).

Pub. L. 95-256 (Apr. 6, 1978) struck 8335(a)-(e), effective Sept. 30, 1978. The Code note numbers the provision sec. 5(c); the Statutes rendering labels it 6(c). Mandatory separation remained for air traffic controllers and for law enforcement officers and firefighters, and the Act added a provision for the Alaska Railroad and the Isthmus of Panama, which was struck in 2000. Later amendments extended mandatory separation to nuclear materials couriers, CBP officers, and the Capitol and Supreme Court Police. The President's exemption power survives only for these categories.

RET-R2 is supported for the general workforce. It is not supported for the Foreign Service, the Canal Zone, or orders that exempt from sec. 204 as a whole.

## Subsequent-change checks

The checks used these sources:

- Stage 3 ledger titles containing "retire", searched by surname and spelling variant.
- APP full-text search for "compulsory retirement", 1939 to 1979, all three result pages (240 records).
- Targeted APP searches for Flemming, McGuigan, Wales, May 28, 1940, and Apr. 28, 1952.
- NARA disposition-table See, Amends and Amended-by fields.
- The amendment notes for 5 U.S.C. 3323 and 8335.

One conflict was recorded. The ledger and the NARA table give EO 8420 a James E. Harper title, but APP lists EO 8420 as Frank B. Bourn's exemption. The inherited files were not edited.

## Fetches

There were 44 WebFetch calls. Ten were for statutes. Four of those failed: govinfo STATUTE-47-Pg382 rendered only p. 382; STATUTE-47-Pg404 does not exist; the uscode.house.gov page for 8335 returned a maintenance notice; and loc.gov returned an error. The other 34 were APP calls: 24 order texts, 9 searches and Proclamation 2974. Two APP searches returned 0 results: one of the nine, and an APP search for the sec. 204 wording counted among the statute calls. Stage 7 statute files were reused without refetching.
