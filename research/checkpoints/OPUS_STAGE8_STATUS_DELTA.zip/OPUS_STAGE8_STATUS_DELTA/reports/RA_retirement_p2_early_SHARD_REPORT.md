# SHARD_REPORT: RA_retirement_p2_early (producer RA, Opus Stage 8)

Cutoff Oct. 14, 2026; codebook 2.0.0. Start 2026-10-15T21:31:26Z; end about 2026-10-15T21:58Z (UTC); elapsed about 27 minutes. Validator (`stage7/code/validate_status_shard.py`): 131 records, 0 errors, 0 warnings.

## Results

| Proposed status (substantive / any effect) | Count | Rule |
|---|---|---|
| no / no | 122 | RET-R1 (V_RET reconciled predicates) |
| indeterminate / indeterminate | 9 | none (holds below) |

No order met RET-R2: every open-ended order in the packet is a Hoover-form exemption from sec. 204 as a whole, which RET-R2 excludes by Q4.

APP texts were obtained for all 131 packet orders and for 24 later chain or class orders (EO 8747, 8778, 8805, 8810, 8828, 8866, 8887, 8896, 8904, 8905, 8917, 8919, 8967, 8969, 8995, 8997, 9002, 9009, 9016, 9030, 9031, 9037, 9118, 9238). The Edwards orders EO 8827 and 8844 were reused from the RT test cache and not refetched. Every capture shows the authority clause, and all 131 footprints are complete. Although no packet title gives an end date, the texts of 124 of the 131 orders state one: a stated end date, or an outer limit for EO 7155, 8041, 8328 and 8676. The seven orders without one are the Hoover orders listed below.

All 36 multi-order chains end on a dated order before 1944, with one exception, Latta. In the Edwards chain, EO 8844 amends EO 8827 to Oct. 31, 1942. Confidence is high for all 122 RET-R1 proposals. The latest chain end is Weddell's outer limit, Apr. 30, 1946 (EO 8676). EO 8413 reads "ending June 30, 1041", which is a slip for 1941; both readings fall before the cutoff.

## Holds (9)

- **Open Hoover-form exemptions (7): EO 5896 (22 persons), 5912 (McDowell), 5917 (Albert D. Davis), 5921, 5946, 5988 and 6004 (Maxam).** Each order exempts the named persons "from the provisions of that section" and states no period. The phrase "during the current month" in EO 5921, 5946, 5988 and 6004 describes when the persons reach retirement age; it is not a term. RET-R1 fails P3. RET-R2 is excluded by Q4 because the reemployment bar survives in 5 U.S.C. 3323(a). EO 5896, 5921, 5946 and 5988 also name no positions. The search found no later order and no revocation of any of these orders. Personnel records of each beneficiary's separation, or an authoritative construction of Hoover-form exemptions, would settle these holds.
- **Latta chain (2): EO 8256 and 8497.** EO 9238 (Sept. 3, 1942; text read) "further exempted" Latta with no end date. Under the reconciled P4, the earlier orders are held with it. An accepted decision on EO 9238 (RET-R2 may reach it as of 1978-09-30) or Latta's separation record would settle these holds.

## Subsequent-change checks

The checks used these sources:

- Stage 3 ledger titles containing "retire" (602 titles), searched by surname and spelling variant.
- APP "compulsory retirement" searches covering 1939 to 1947.
- APP "retirement" date searches for the 1932-33, 1935, 1937 and 1938 orders.
- NARA disposition tables for 1939 to 1942 (local copies), See/Amends/Amended by/Revoked by fields.
- The class orders EO 8887 and 8997, which were read. EO 8887 names no beneficiary in this packet. EO 8997 covers only Post Office field employees and ends Dec. 31, 1942.

EO 9780 (1946) and EO 9895 (1947), "Certain Officers of the Executive Branch", are not on APP and were not read (11 FR 10645; 12 FR 6493). A reviewer should confirm that they name no beneficiary in this packet.

Three conflicts were recorded (`conflicts.jsonl`):

- EO 8420: the packet title names Harper, but the text names Frank B. Bourn.
- EO 8308: the packet groups it with Jaggar (RG-EO:8142), but the text names Gerrit S. Miller, Jr.
- EO 8094: the NARA table gives "Amended by: EO 8293", but EO 8293 concerns the eight-hour law. The actual successor is EO 8392.

Name variants that do not affect identity: Lord gives "Weaver" (APP "Wilver", EO 5921) and "Van Vlack" (APP "Van Vleck", EO 5988). The APP body text of EO 8349 reads "MeBiree".

## Fetches

There were 168 WebFetch calls, listed in `fetchlog.tsv` with approximate times. Per-fetch clock times were not recorded, so the times are interpolated.

- **APP order pages:** 157 calls. 155 returned the order text. Two failed with a client error on the listed slug for EO 8369, which was then read through the alternate slug `...-louis-simon-...`.
- **APP searches:** 10 calls. Eight returned listings and two returned server errors.
- **trumanlibrary.gov:** 1 call for EO 9780, which returned no text.

One further call was refused by the tool without fetching. No statute was refetched; the shared-cache files for sec. 204, 5 U.S.C. 3323 and the Act of 1930 were reused.
