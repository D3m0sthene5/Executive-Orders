# Opus Stage 8: retirement and NRA priority-2 status delta

Project: The Afterlife of Executive Orders. Cutoff October 14, 2026, America/New_York. Codebook 2.0.0, unchanged.

This delta adds 340 independently reviewed new determinate substantive statuses, all substantive no and any-operative-effect no: 256 retirement exemptions and 84 NRA orders. Every order in both priority-2 assignments was produced and reviewed (281 retirement, 87 NRA). Integrated with the 1,889 combined provisional Stage 7 statuses, validated coverage rises from 12.62 to 14.89 percent of 14,973, a gain of 2.27 percentage points. No substantive yes was found, and no prior accepted status is contradicted.

## Exact accepted gains

| Assignment | Orders | Accepted new no/no | Accepted as indeterminate | Held | Reviewer determination awaiting confirmation |
|---|---:|---:|---:|---:|---:|
| Retirement P2 (test 19 + expansion 262) | 281 | 256 | 20 | 0 | 5 |
| NRA P2 (test 15 + expansion 72) | 87 | 84 | 1 (EO 6299, coal) | 2 (EO 6296A, 6749) | 0 |
| Any other family | 0 | 0 | 0 | 0 | 0 |

The five retirement orders in the last column (EO 8256, 8497, 8904, 10225, 11619) were proposed indeterminate by their producers. The reviewer found them no/no, because their successor orders were accepted or because a savings clause had no effect of its own. These are the reviewer's own determinations without a second check, so they are not counted. A short confirmation pass would add them.

## Legal rules

Three rules carried most of the work.
- **RET-R1:** an order whose text exempts named persons from compulsory retirement until a stated date that has passed, with no later extension, is no/no. It was carried over from Stage 7.
- **RET-R2:** new in this stage, and approved by an independent reviewer with amended predicates. Pub. L. 95-256 removed the general age-70 compulsory retirement rule in 5 U.S.C. 8335 effective September 30, 1978. An open-ended exemption for a position in the general workforce has had nothing to operate on since then, and its end is recorded as "no later than 1978-09-30". The rule excludes orders that permit reappointing someone already separated for age, orders naming no position, positions under surviving age regimes (Foreign Service, Canal Zone, Alaska Railroad, law enforcement, firefighters, air traffic controllers and others), and exemptions from all of Economy Act § 204, whose reappointment bar survives in 5 U.S.C. 3323(a).
- **NRA-R1:** carried over from Stage 7 with its amendments. It covers approvals and amendments operating only within the code system, which lost legal force by June 14, 1935.

Twelve NRA orders were decided outside the rule on their own legal basis, and the reviewer accepted ten. Five agreements under § 4 of the National Industrial Recovery Act, and two wage-agreement approvals, end April 1, 1936, when Title I expired. Public Resolution 26 did not repeal § 4(a). The reviewer corrected the reasoning in those records without changing the status.

Seven Hoover-era orders exempt people "from the provisions of that section" with no period, so they fall under RET-R2's § 204 exclusion and stay indeterminate. Of the RB orders accepted as indeterminate, nine are 1946–1948 orders whose text is not on the American Presidency Project and was printed only as a heading in the Federal Register. EO 10073 needs the Tax Court retirement statute. EO 11154 (Hoover, as FBI Director) depends on whether the Director falls in the law-enforcement category that kept mandatory retirement.

## Efficiency and the selected family

| | Retirement P2 | NRA P2 |
|---|---:|---:|
| Accepted new determinate | 256 | 84 |
| Family clock (test, expansion, review) | 54.7 min | 58.2 min |
| Accepted per hour | 281 | 87 |
| Reported subagent tokens | 1.36 M | 1.02 M |
| Accepted per million tokens | 189 | 83 |
| Percentage-point gain | 1.71 | 0.56 |

Retirement was the stronger family by both measures, so it received two of the three expansion producers. In the test, 11 of 12 retirement orders with undated titles turned out to state an end date in their text, which kept RET-R1 applicable. NRA cost more per acceptance because its queue was smaller and contained more outside-rule orders, each needing its own analysis. Seven delegated workers ran across three waves, never more than four at once: two test producers, one test reviewer, three expansion producers and two expansion reviewers. Every reviewer was separate from the work it reviewed. Coordinator tokens are not exposed and are excluded.

## Evidence and fidelity

All texts are American Presidency Project transcripts (`hosted_transcript`), quoted with the authority clause shown in the saved text, a correction the Stage 7 review required. Reviewers refetched 26 orders in full across the three reviews. All matched the producers' captures, except one missing "and" in EO 6730, which changes nothing. One systematic defect remains in some source files: several cache headers carry placeholder retrieval times. Record conflicts that do not affect status, such as wrong names or dates in inherited titles (EO 8420, 8308, 8969, 10151), are in `OPUS_STATUS_CONFLICTS.jsonl`.

## Integrity, baseline and handoff

`INTEGRITY_AND_NONOVERLAP.json` shows the following:
- Every decision is within the Opus scope.
- No decision overlaps Astra's 1,181 civil-service IDs, the 411 Stage 7 Opus decisions, the V5_OPUS cohort or the 952-member V1 scope.
- There are no duplicates.
- Every baseline is Stage 6 indeterminate.
- The Stage 7 delta (`7591b10a…`) and the V1 causal archive (`ab0da856…`) are unchanged.

**The Stage 6 archive was again not supplied**, and neither were the V2–V4 and V5_ASTRA membership files. Baselines therefore come from the hash-verified Stage 7 split package. Every Stage 8 ID was Stage 6 indeterminate, so none can belong to an earlier substantive-NO cohort, but Astra should confirm that against its files at merge.

`CLAUDE_NEW_NO_V6_OPUS_PROVISIONAL.jsonl` lists the 340 new substantive-NO instruments as a provisional causal handoff, pending finalization of the V5 merge. Their causes have not been researched.

## Stopping point

Both assigned families are exhausted, and the remaining items are specific holds listed in `OPUS_STATUS_QUEUE.jsonl`. A code scan for another family (`NEXT_FAMILY_CANDIDATES.json`) found the best candidate to be 43 emergency-board orders that were not determinate at Stage 3. The National Mediation Board table and the board-completion rule are already in hand for them. Stage 5 reported accepting emergency-board decisions, however, and without the Stage 6 ledger their remaining eligibility cannot be confirmed, so no research was started. The 16 NRA P3 orders remain an untouched fallback.
